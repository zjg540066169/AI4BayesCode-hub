# Data-generating process for the nn_rbm1bJ100 benchmark model.
# Bayesian neural network with J = 100 hidden units.
# Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data, for
#            coverage / recovery checks.
#
# NOTE: this model has hidden-unit sign/permutation symmetry; chains
# from different starts will land in posterior modes that are
# label-permutations of each other. Direct per-element coverage on
# alpha, beta, alpha1, beta1 is not meaningful without relabeling.
# sigma2_alpha and sigma2_beta are label-invariant.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 60L
    M <- 12L
    K <- 4L
    J <- 100L
    x <- matrix(rnorm(N * M), nrow = N, ncol = M)
    sigma2_alpha <- 1 / rgamma(1, shape = 0.25, rate = 0.25 * (0.05 / M^(1 / 0.5))^2)
    sigma2_beta  <- 1 / rgamma(1, shape = 0.25, rate = 0.25 * (0.05 / J^(1 / 0.5))^2)
    alpha  <- matrix(rnorm(M * J,        0, sqrt(sigma2_alpha)), nrow = M, ncol = J)
    beta   <- matrix(rnorm(J * (K - 1L), 0, sqrt(sigma2_beta)),  nrow = J, ncol = K - 1L)
    alpha1 <- rnorm(J)
    beta1  <- rnorm(K - 1L)
    x1     <- cbind(1, x)
    hidden <- tanh(x1 %*% rbind(alpha1, alpha))
    logits <- cbind(1, cbind(1, hidden) %*% rbind(beta1, beta))
    y      <- integer(N)
    for (n in seq_len(N)) {
        p <- exp(logits[n, ] - max(logits[n, ]))
        p <- p / sum(p)
        y[n] <- sample.int(K, 1, prob = p)
    }
    list(
        data = list(N = N, M = M, x = x, K = K, y = as.integer(y)),
        truth = list(
            sigma2_alpha = sigma2_alpha,
            sigma2_beta  = sigma2_beta,
            alpha        = alpha,
            beta         = beta,
            alpha1       = matrix(alpha1, nrow = 1L),
            beta1        = matrix(beta1,  nrow = 1L)
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("nn_rbm1bJ100.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
