# Data-generating process for the logearn_logheight_male benchmark model.
# Extracted from sim1_logearn_logheight_male.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 50L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    height <- runif(N_DATA, 55, 75)
    log_height <- log(height)
    male   <- rbinom(N_DATA, 1L, 0.5)
    beta1_true <- runif(1, -5, 5)
    beta2_true <- runif(1, 1.0, 4.0)        # log-log slope (income elasticity-like)
    beta3_true <- runif(1, 0.05, 0.40)
    sigma_true <- runif(1, 0.35, 0.95)
    log_earn <- beta1_true + beta2_true * log_height + beta3_true * male +
                rnorm(N_DATA, 0, sigma_true)
    earn <- exp(log_earn)

    list(
        data = list(
            N          = N_DATA,
            height     = height,
            log_height = log_height,
            male       = as.numeric(male),
            log_earn   = log_earn,    # for AI
            earn       = earn         # for Stan
        ),
        truth = list(
            beta  = matrix(c(beta1_true, beta2_true, beta3_true), nrow = 1L),
            sigma = sigma_true
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("logearn_logheight_male.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
