# Data-generating process for the kidscore_interaction benchmark model.
# Extracted from sim1_kidscore_interaction.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 50L
P_DIM  <- 4L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    mom_hs <- rbinom(N_DATA, 1L, 0.7)
    mom_iq <- pmin(pmax(rnorm(N_DATA, 100, 15), 50), 195)
    inter  <- mom_hs * mom_iq
    beta1_true <- runif(1, -10, 10)
    beta2_true <- runif(1, 30, 70)
    beta3_true <- runif(1, 0.5, 1.0)
    beta4_true <- runif(1, -0.5, -0.2)
    sigma_true <- runif(1, 15, 22)
    mu <- beta1_true + beta2_true * mom_hs + beta3_true * mom_iq + beta4_true * inter
    kid_score <- mu + rnorm(N_DATA, 0, sigma_true)
    list(
        data = list(N = N_DATA, kid_score = kid_score, mom_iq = mom_iq,
                    mom_hs = as.numeric(mom_hs)),
        truth = list(beta = matrix(c(beta1_true, beta2_true, beta3_true, beta4_true), nrow = 1L),
                     sigma = sigma_true)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("kidscore_interaction.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
