# Data-generating process for the hierarchical_gp benchmark model.
# Extracted from sim1_hierarchical_gp.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    # cpp HARDCODES N_regions = 10 (errors otherwise). For tractability
    # we use minimum-size DGP: 1 state per region (N_states = N_regions =
    # 10), 4 observed years, 8-year GP grid. This keeps the model
    # identifiable but cuts per-iter cost ~5x vs the (20, 8, 12) setting.
    # AI per-rep wall drops from ~14h to ~3h at 20k+20k.
    N_states         <- 10L
    N_regions        <- 10L
    N_years_obs      <- 4L
    N_years          <- 8L
    state_region_ind <- seq_len(N_regions)        # 1 state per region
    N                <- N_states * N_years_obs
    state_ind        <- rep(seq_len(N_states), each = N_years_obs)
    region_ind       <- state_region_ind[state_ind]
    year_ind         <- rep(seq_len(N_years_obs), times = N_states)
    years            <- 1:N_years

    tot_var      <- rgamma(1, 3, 3)
    prop_var_raw <- rgamma(17, 2, 1)
    prop_var     <- prop_var_raw / sum(prop_var_raw)
    vars         <- 17 * prop_var * tot_var

    # vars layout: [1]=year, [2]=region, [3..12]=10 per-region state SDs,
    # [13..16]=GP scales, [17]=residual.
    sigma_year   <- sqrt(vars[1])
    sigma_region <- sqrt(vars[2])
    sigma_state  <- sqrt(vars[3:(2 + N_regions)])  # length 10
    sigma_GP_region_long  <- sqrt(vars[13])
    sigma_GP_state_long   <- sqrt(vars[14])
    sigma_GP_region_short <- sqrt(vars[15])
    sigma_GP_state_short  <- sqrt(vars[16])
    sigma_error           <- sqrt(vars[17])

    mu <- rnorm(1, 0.5, 0.5)

    year_std   <- rnorm(N_years_obs)
    region_std <- rnorm(N_regions)
    state_std  <- rnorm(N_states)
    year_re    <- sigma_year   * year_std
    region_re  <- sigma_region * region_std
    state_re   <- sigma_state[state_region_ind] * state_std

    length_GP_region_long  <- rweibull(1, 30, 8)
    length_GP_region_short <- rweibull(1, 30, 3)
    length_GP_state_long   <- rweibull(1, 30, 8)
    length_GP_state_short  <- rweibull(1, 30, 3)

    d2       <- outer(years, years, function(a, b) (a - b)^2)
    K_region <- sigma_GP_region_long^2  * exp(-d2 / (2 * length_GP_region_long^2)) +
                sigma_GP_region_short^2 * exp(-d2 / (2 * length_GP_region_short^2))
    K_state  <- sigma_GP_state_long^2   * exp(-d2 / (2 * length_GP_state_long^2)) +
                sigma_GP_state_short^2  * exp(-d2 / (2 * length_GP_state_short^2))
    diag(K_region) <- diag(K_region) + 1e-6
    diag(K_state)  <- diag(K_state)  + 1e-6
    L_region <- chol(K_region)
    L_state  <- chol(K_state)

    GP_region_std <- matrix(rnorm(N_years * N_regions),
                            nrow = N_years, ncol = N_regions)
    GP_state_std  <- matrix(rnorm(N_years * N_states),
                            nrow = N_years, ncol = N_states)
    # crossprod-equivalent: t(L) %*% Z where chol returns upper.
    GP_region <- t(L_region) %*% GP_region_std
    GP_state  <- t(L_state)  %*% GP_state_std

    obs_mu <- numeric(N)
    for (n in seq_len(N)) {
        obs_mu[n] <- mu +
            year_re[year_ind[n]] +
            state_re[state_ind[n]] +
            region_re[region_ind[n]] +
            GP_region[year_ind[n], region_ind[n]] +
            GP_state [year_ind[n], state_ind[n]]
    }
    y <- pmin(pmax(rnorm(N, obs_mu, sigma_error), 0), 1)

    list(
        data = list(
            N                = N,
            N_states         = N_states,
            N_regions        = N_regions,
            N_years_obs      = N_years_obs,
            N_years          = N_years,
            state_region_ind = as.integer(state_region_ind),
            state_ind        = as.integer(state_ind),
            region_ind       = as.integer(region_ind),
            year_ind         = as.integer(year_ind),
            year_grid        = as.numeric(years),
            y                = y),
        truth = list(
            mu                     = mu,
            tot_var                = tot_var,
            prop_var               = matrix(prop_var, nrow = 1L),
            length_GP_region_long  = length_GP_region_long,
            length_GP_state_long   = length_GP_state_long,
            length_GP_region_short = length_GP_region_short,
            length_GP_state_short  = length_GP_state_short,
            year_re                = matrix(year_re,   nrow = 1L),
            region_re              = matrix(region_re, nrow = 1L),
            state_re               = matrix(state_re,  nrow = 1L),
            GP_region              = matrix(as.numeric(GP_region),
                                            nrow = 1L),
            GP_state               = matrix(as.numeric(GP_state),
                                            nrow = 1L)))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("hierarchical_gp.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
