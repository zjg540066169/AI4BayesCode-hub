# Data-generating process for the GLMM1_model benchmark model.
# Extracted from sim1_GLMM1_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

NSITE <- 6L
NOBS  <- 24L
NMIS  <- 4L
NYEAR <- 5L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    mu_alpha_true <- rnorm(1, 0, 2)
    sd_alpha_true <- runif(1, 0.3, 2)
    alpha_true    <- rnorm(NSITE, mu_alpha_true, sd_alpha_true)
    obssite  <- sample.int(NSITE, NOBS, replace = TRUE)
    obsyear  <- sample.int(NYEAR, NOBS, replace = TRUE)
    obs      <- rpois(NOBS, exp(alpha_true[obssite]))
    missite  <- sample.int(NSITE, NMIS, replace = TRUE)
    misyear  <- sample.int(NYEAR, NMIS, replace = TRUE)
    list(
        data  = list(nobs = NOBS, nmis = NMIS, nyear = NYEAR, nsite = NSITE,
                     obs = as.integer(obs),
                     obsyear  = as.integer(obsyear),
                     obssite  = as.integer(obssite),
                     misyear  = as.integer(misyear),
                     missite  = as.integer(missite)),
        truth = list(alpha    = matrix(alpha_true, nrow = 1L),
                     mu_alpha = mu_alpha_true,
                     sd_alpha = sd_alpha_true)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("GLMM1_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
