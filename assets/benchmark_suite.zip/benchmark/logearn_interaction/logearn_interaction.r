# Data-generating process for the logearn_interaction benchmark model.
# Extracted from sim1_logearn_interaction.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 50L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    height <- rnorm(N_DATA, 65, 4)
    male   <- rbinom(N_DATA, 1L, 0.5)
    inter  <- height * male
    beta1_true <- runif(1, 6.0, 10.0)
    beta2_true <- runif(1, 0.01, 0.06)
    beta3_true <- runif(1, -0.5, 0.5)
    beta4_true <- runif(1, -0.02, 0.02)
    sigma_true <- runif(1, 0.35, 0.95)
    log_earn <- beta1_true + beta2_true * height + beta3_true * male +
                beta4_true * inter + rnorm(N_DATA, 0, sigma_true)
    earn <- exp(log_earn)

    list(
        data = list(
            N = N_DATA, earn = earn, height = height, male = as.numeric(male)
        ),
        truth = list(
            beta  = matrix(c(beta1_true, beta2_true, beta3_true, beta4_true), nrow = 1L),
            sigma = sigma_true
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("logearn_interaction.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
