# Data-generating process for the low_dim_gauss_mix_collapse benchmark model.
# Extracted from sim1_low_dim_gauss_mix_collapse.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 150L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    mu_raw    <- c(rnorm(1, -1.5, 0.4), rnorm(1, 1.5, 0.4))
    sigma_raw <- abs(rnorm(2, 0, 0.8)) + 0.3
    theta_raw <- rbeta(1, 5, 5)

    # Sort by mu ascending (matches relabel convention); flip theta if swap
    ord <- order(mu_raw)
    mu_true    <- mu_raw[ord]
    sigma_true <- sigma_raw[ord]
    theta_true <- if (ord[1] == 1L) theta_raw else (1 - theta_raw)

    z <- rbinom(N_DATA, 1L, 1 - theta_true) + 1L
    y_obs <- rnorm(N_DATA, mu_true[z], sigma_true[z])

    list(
        data = list(N = N_DATA, y = y_obs),
        truth = list(
            mu    = matrix(mu_true,    nrow = 1L),
            sigma = matrix(sigma_true, nrow = 1L),
            theta = theta_true
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("low_dim_gauss_mix_collapse.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
