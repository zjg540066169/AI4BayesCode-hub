# Data-generating process for the Mt_model benchmark model.
# Extracted from sim1_Mt_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

T_TRUE <- 5L
N_TRUE <- 50L  # true population
M_AUG  <- 100L # augmented size

simulate_data <- function(seed = 123) {
    set.seed(seed)
    p_true     <- runif(T_TRUE, 0.20, 0.65)
    omega_true <- N_TRUE / M_AUG  # by construction

    # Generate true capture histories for N_TRUE individuals
    y_true <- matrix(0L, N_TRUE, T_TRUE)
    for (i in seq_len(N_TRUE)) y_true[i, ] <- rbinom(T_TRUE, 1L, p_true)
    # Keep observed (rowSum > 0) — others "never seen" but exist in truth
    # For the data-augmentation model, total provided is M (with C observed)
    obs_idx <- which(rowSums(y_true) > 0)
    C <- length(obs_idx)
    y_full <- matrix(0L, M_AUG, T_TRUE)
    y_full[seq_len(C), ] <- y_true[obs_idx, , drop = FALSE]
    # rest is augmented zeros (rows C+1..M_AUG)

    list(
        data = list(M = M_AUG, T = T_TRUE, y = y_full),
        truth = list(
            omega = omega_true,
            p     = matrix(p_true, nrow = 1L)
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("Mt_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
