# Data-generating process for the kidscore_momhs benchmark model.
# Extracted from sim1_kidscore_momhs.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_OBS <- 80L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    mom_hs <- rbinom(N_OBS, 1L, 0.6)
    # Benign DGP: draw beta from prior Normal(0, 1), sigma from a tight
    # range so kid_score = beta_1 + beta_2 * mom_hs + N(0, sigma) doesn't
    # need any clamp. Stan's lower=0/upper=200 bound was dropped (see
    # kidscore_momhs.stan -- it is just an input check, not part of the
    # likelihood). The model fits an un-truncated Normal regression, so
    # both implementations target the same posterior given the same y.
    sigma <- runif(1, 0.3, 1.5)
    beta  <- rnorm(2, 0, 1)
    mu    <- beta[1] + beta[2] * mom_hs
    kid_score <- rnorm(N_OBS, mu, sigma)
    X <- cbind(1, mom_hs)

    list(
        data = list(N = N_OBS, kid_score = as.numeric(kid_score),
                    mom_hs = as.numeric(mom_hs), X = X),
        truth = list(beta = matrix(beta, nrow = 1L), sigma = sigma))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("kidscore_momhs.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
