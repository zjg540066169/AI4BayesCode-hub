# Data-generating process for the rats_model benchmark model.
# Extracted from sim1_rats_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N        <- 10L
    x_vals   <- c(8, 15, 22, 29, 36)
    Npts     <- N * length(x_vals)
    rat      <- rep(seq_len(N), each = length(x_vals))
    x        <- rep(x_vals, times = N)
    xbar     <- mean(x)
    mu_alpha    <- rnorm(1, 0, 100)
    mu_beta     <- rnorm(1, 0, 100)
    sigma_y     <- runif(1, 0.5, 5)
    sigma_alpha <- runif(1, 0.5, 5)
    sigma_beta  <- runif(1, 0.1, 2)
    alpha    <- rnorm(N, mu_alpha, sigma_alpha)
    beta     <- rnorm(N, mu_beta,  sigma_beta)
    y <- numeric(Npts)
    for (n in seq_len(Npts)) {
        y[n] <- rnorm(1,
                      alpha[rat[n]] + beta[rat[n]] * (x[n] - xbar),
                      sigma_y)
    }
    list(
        data = list(N    = N,
                    Npts = Npts,
                    rat  = as.integer(rat),
                    x    = x,
                    y    = y,
                    xbar = xbar),
        truth = list(mu_alpha    = mu_alpha,
                     mu_beta     = mu_beta,
                     sigma_y     = sigma_y,
                     sigma_alpha = sigma_alpha,
                     sigma_beta  = sigma_beta,
                     alpha       = alpha,
                     beta        = beta)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("rats_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
