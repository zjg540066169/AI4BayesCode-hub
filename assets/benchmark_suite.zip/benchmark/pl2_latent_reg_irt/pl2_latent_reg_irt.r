# Data-generating process for the pl2_latent_reg_irt benchmark model.
# Extracted from sim1_pl2_latent_reg_irt.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

I_N <- 6L   # items
J_N <- 30L  # persons
K_N <- 2L   # covariates
N_OBS <- I_N * J_N  # full design

# 1-based item/person indices (same every replicate)
II_OBS <- as.integer(rep(seq_len(I_N), each = J_N))
JJ_OBS <- as.integer(rep(seq_len(J_N), times = I_N))

simulate_data <- function(seed = 123) {
    set.seed(seed)

    alpha_true     <- exp(rnorm(I_N, mean = 1.0, sd = 0.5))   # LogNormal(1,1) prior
    beta_free_true <- rnorm(I_N - 1L, mean = 0.0, sd = 0.5)
    beta_true      <- c(beta_free_true, -sum(beta_free_true))
    lambda_true    <- rnorm(K_N, mean = 0.0, sd = 0.5)

    W_full  <- matrix(rnorm(J_N * K_N), J_N, K_N)
    W_means <- colMeans(W_full)
    W_sds   <- apply(W_full, 2L, sd); W_sds[W_sds == 0] <- 1
    W_adj   <- sweep(sweep(W_full, 2L, W_means, "-"), 2L, W_sds, "/")
    theta_true <- as.numeric(W_adj %*% lambda_true) + rnorm(J_N, 0, 1)

    y_obs <- integer(N_OBS)
    for (n in seq_len(N_OBS)) {
        eta      <- alpha_true[II_OBS[n]] * theta_true[JJ_OBS[n]] - beta_true[II_OBS[n]]
        y_obs[n] <- as.integer(runif(1L) < 1 / (1 + exp(-eta)))
    }

    list(
        data = list(
            y_dbl  = as.numeric(y_obs),     # AI takes NumericVector
            y_int  = as.integer(y_obs),     # Stan takes int array
            ii     = II_OBS,
            jj     = JJ_OBS,
            W_full = W_full,
            I_n    = I_N, J_n = J_N, K_n = K_N, N_obs = N_OBS
        ),
        truth = list(
            alpha     = matrix(alpha_true,     nrow = 1L),
            beta_free = matrix(beta_free_true, nrow = 1L),
            theta     = matrix(theta_true,     nrow = 1L)
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("pl2_latent_reg_irt.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
