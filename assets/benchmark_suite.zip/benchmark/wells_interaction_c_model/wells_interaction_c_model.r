# Data-generating process for the wells_interaction_c_model benchmark model.
# Extracted from sim1_wells_interaction_c_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 80L
    dist <- runif(N, 0, 300); arsenic <- runif(N, 0, 10)
    alpha <- rnorm(1, 0, 1)
    beta  <- rnorm(3, 0, 1)
    dist100 <- dist / 100
    c_dist100 <- dist100 - mean(dist100)
    c_arsenic <- arsenic - mean(arsenic)
    eta <- alpha + beta[1]*c_dist100 + beta[2]*c_arsenic + beta[3]*(c_dist100*c_arsenic)
    switched <- rbinom(N, 1, plogis(eta))
    list(
        data = list(N = N, switched = as.integer(switched), dist = dist, arsenic = arsenic),
        truth = list(beta = matrix(c(alpha, beta), nrow = 1L))   # AI's beta is 4-vec [alpha,...]
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("wells_interaction_c_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
