# Data-generating process for the probit_BART_model benchmark model.
# Extracted from sim1_probit_BART_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 120L
    D <- 3L
    X <- matrix(runif(N * D, -1, 1), nrow = N, ncol = D)
    f <- 1.2 * sin(pi * X[, 1]) + 0.8 * X[, 2] * X[, 3]
    p <- pnorm(f)
    y <- rbinom(N, size = 1L, prob = p)

    list(
        data = list(N = N, D = D, X = X, y = as.integer(y)),
        truth = list(
            # cpp registers latent f under key "f_bart" (bart_block name);
            # BART::pbart returns the same quantity as $yhat.train.
            f_bart = matrix(f, nrow = 1L)))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference BART::pbart model:
# library(BART)
# fit <- BART::pbart(x.train = sim$data$X, y.train = sim$data$y,
#                    ntree = 50, nskip = 1000, ndpost = 1000)
