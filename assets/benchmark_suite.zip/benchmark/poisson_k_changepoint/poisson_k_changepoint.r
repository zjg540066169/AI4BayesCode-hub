# Data-generating process for the poisson_k_changepoint benchmark model.
# Extracted from sim1_poisson_k_changepoint.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

# Segments identified by temporal order (s[1] < s[2]), no label switching.
# Truth: lambda (K_cp+1 rates ordered by segment), s (K_cp positions in 2..T-1).
simulate_data <- function(seed = 123) {
    set.seed(seed)
    T    <- 20L
    K_cp <- 2L
    r    <- rep(1.0, K_cp + 1L)
    # Sample ordered changepoints: s[1] in {2..T-K_cp}, s[2] in {s[1]+1..T-1}
    s1 <- sample.int(T - K_cp - 1L, 1L) + 1L      # s[1] in {2..T-2}
    s2 <- sample.int(T - s1 - 1L, 1L) + s1         # s[2] in {s[1]+1..T-1}
    s  <- c(s1, s2)
    # Lambda per segment drawn from Exp(r[j])
    lambda <- rexp(K_cp + 1L, rate = r)
    # Generate data: segment of time t is determined by how many s[j] <= t
    seg <- function(t) sum(t >= s) + 1L
    D   <- sapply(seq_len(T), function(t) rpois(1L, lambda[seg(t)]))
    list(
        data  = list(T = T, K_cp = K_cp, r = r, D = D),
        truth = list(lambda = lambda, s = s)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("poisson_k_changepoint.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
