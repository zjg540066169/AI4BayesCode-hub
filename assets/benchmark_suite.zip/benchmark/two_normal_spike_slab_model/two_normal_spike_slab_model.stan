// Stan reference for two-Normal spike-slab regression. Matches the cpp
// (which marginalizes gamma in the beta NUTS lambda); Stan also
// marginalizes (Stan can't sample discrete) and re-samples gamma in
// generated quantities so cross-impl rhat / coverage on gamma is
// well-defined.
//
// Fixed hyperparameters: sigma_spike, sigma_slab (user-supplied).
// Sampled: beta, sigma, pi, gamma.
// Priors: pi ~ Beta(1, 1) ; sigma ~ Jeffreys p(sigma) oc 1/sigma ;
//         beta_j ~ (1 - pi) N(0, sigma_spike) + pi N(0, sigma_slab).
// Likelihood: y_n ~ Normal(X_n . beta, sigma).
data {
  int<lower=1> N;
  int<lower=1> p;
  matrix[N, p]               X;
  vector[N]                  y;
  real<lower=0>              sigma_spike;
  real<lower=0>              sigma_slab;
}
parameters {
  real<lower=0>              sigma;
  real<lower=0, upper=1>     pi;
  vector[p]                  beta;
}
model {
  // sigma ~ Jeffreys (improper). Stan handles improper priors via target +=.
  target += -log(sigma);
  // pi ~ Beta(1, 1) is uniform; no contribution needed (target += 0).

  // beta_j prior: 2-Normal mixture (gamma marginalized).
  for (j in 1:p) {
    target += log_sum_exp(
      log1m(pi) + normal_lpdf(beta[j] | 0, sigma_spike),
      log(pi)   + normal_lpdf(beta[j] | 0, sigma_slab));
  }

  // Gaussian likelihood.
  y ~ normal(X * beta, sigma);
}
generated quantities {
  // Sample gamma | beta, pi by computing the mixture posterior weight.
  array[p] int<lower=0, upper=1> gamma;
  for (j in 1:p) {
    real lp_spike = log1m(pi) + normal_lpdf(beta[j] | 0, sigma_spike);
    real lp_slab  = log(pi)   + normal_lpdf(beta[j] | 0, sigma_slab);
    real p_slab   = exp(lp_slab - log_sum_exp(lp_spike, lp_slab));
    gamma[j]      = bernoulli_rng(p_slab);
  }
}
