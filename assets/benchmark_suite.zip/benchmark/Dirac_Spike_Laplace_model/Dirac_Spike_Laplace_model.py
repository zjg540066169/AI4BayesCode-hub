"""
Dirac-spike, Laplace-slab variable-selection prior for a linear-regression
likelihood, implemented in PyMC.

Prior:
    pi          ~ Beta(1, 1)
    sigma       ~ Jeffreys,  p(sigma) prop 1/sigma     (improper)
    b           ~ Jeffreys,  p(b)     prop 1/b         (improper)
    gamma_j     ~ Bernoulli(pi)                              j = 1, ..., p
    beta_j | gamma_j = 0                = 0
    beta_j | gamma_j = 1, sigma, b      ~ Laplace(0, b * sigma)

Equivalently:

    beta_j ~ (1 - gamma_j) * delta_0 + gamma_j * Laplace(0, b * sigma)

Likelihood:

    y_i ~ Normal(x_i^T beta, sigma),    i = 1, ..., N

The Dirac spike yields exact sparsity (beta_j is literally 0 when
gamma_j = 0); the Laplace slab gives heavier-than-Gaussian tails for
included coefficients.

PyMC encoding (no reversible jump)
----------------------------------
PyMC's gradient-based samplers (NUTS, HMC) require a fixed-dimension
continuous parameter space, so we cannot literally implement an RJ
birth/death move. The standard fixed-dim equivalent introduces a latent
slab draw beta_slab_j ~ Laplace(0, b * sigma) for every j (whether or
not gamma_j = 1) and defines

    beta_j  :=  gamma_j * beta_slab_j           (deterministic mask)

so that beta_j == 0 exactly when gamma_j = 0 (Dirac spike) and
beta_j == beta_slab_j ~ Laplace(0, b * sigma) when gamma_j = 1 (slab).
The marginal posterior of beta_j is the desired Dirac-Laplace mixture.

Improper priors p(sigma) prop 1/sigma and p(b) prop 1/b are encoded via
pm.Flat on log_sigma / log_b: pm.Flat is improper uniform on the
unconstrained scale, and the auto-Jacobian d sigma / d log_sigma = sigma
yields the implied Jeffreys p(sigma) prop 1/sigma on the natural scale.
The posterior is proper given the likelihood.

Compound step:

    BinaryGibbsMetropolis ->  gamma                            (discrete)
    NUTS                  ->  pi, log_sigma, log_b, beta_slab  (continuous)

Inference is reported on the deterministic `beta`, NOT `beta_slab`:
when gamma_j = 0, beta_slab_j is updated by NUTS but receives no
likelihood signal, so its draws come from its Laplace prior. Diagnostics
on beta_slab_j are not posterior-meaningful in that regime; the
deterministic beta_j is exactly 0 and that is what matters.

Run:
    pip install pymc arviz numpy
    python Dirac_Spike_Laplace_model.py
"""

from __future__ import annotations

import numpy as np
import pymc as pm
import pytensor.tensor as pt
import arviz as az


# DGP fixed values for the residual + slab scales. The fit_spike_laplace
# model treats sigma and b as free parameters with improper Jeffreys
# priors (pm.Flat on the log scale), but the data-generating values are
# held CONSTANT across replicates so coverage on these two scalars is a
# meaningful frequentist point-coverage diagnostic.
SIGMA_DGP = 1.0
B_DGP     = 1.0


# ----------------------------------------------------------------------------
# Synthetic data: linear regression with sparse coefficients.
# Samples (pi, gamma, beta_slab) from the same joint prior the model uses
# (with sigma and b held fixed at SIGMA_DGP / B_DGP), then y from the
# likelihood.
# ----------------------------------------------------------------------------
def simulate_data(n: int = 200, p: int = 12,
                  seed: int = 2026
                  ) -> tuple[np.ndarray, np.ndarray, dict]:
    """
    Returns (y, X, truth) where truth is a dict of the latent parameters
    used to simulate the data:
        truth["pi"]        scalar, drawn from Beta(1, 1)
        truth["sigma"]     scalar = SIGMA_DGP (held fixed across replicates)
        truth["b"]         scalar = B_DGP     (held fixed across replicates)
        truth["gamma"]     (p,) 0/1, rejection-sampled to ensure sum(gamma) >= 1
        truth["beta_slab"] (p,) drawn from Laplace(0, b * sigma) per coordinate
        truth["beta"]      (p,) = gamma * beta_slab
    """
    rng = np.random.default_rng(seed)

    # X: standard normal columns then column-standardized.
    X = rng.standard_normal((n, p))
    X = (X - X.mean(0)) / X.std(0, ddof=0)

    # sigma and b are held FIXED at the DGP values. pi is drawn from its
    # Beta(1, 1) prior; gamma | pi is rejection-sampled to ensure at least
    # one inclusion (sum(gamma) >= 1) so b is always likelihood-identifiable.
    sigma = SIGMA_DGP
    b     = B_DGP
    pi    = rng.beta(1.0, 1.0)

    for _ in range(10_000):
        gamma = rng.binomial(1, pi, size=p)
        if int(gamma.sum()) >= 1:
            break
    else:
        gamma[rng.integers(0, p)] = 1

    # Slab scale = b * sigma per the prompt:
    #   beta_j | gamma_j = 1, sigma, b ~ Laplace(0, b * sigma).
    beta_slab = rng.laplace(loc=0.0, scale=b * sigma, size=p)
    beta      = gamma * beta_slab

    y = X @ beta + rng.normal(0.0, sigma, size=n)

    truth = dict(pi=pi, sigma=sigma, b=b,
                 gamma=gamma, beta_slab=beta_slab, beta=beta)
    return y, X, truth


# ----------------------------------------------------------------------------
# Model: y = X beta + eps,
#        beta_j ~ (1 - gamma_j) delta_0 + gamma_j Laplace(0, b * sigma)
# ----------------------------------------------------------------------------
def fit_spike_laplace(y: np.ndarray, X: np.ndarray,
                      draws: int = 2000,
                      tune: int = 2000,
                      chains: int = 4,
                      cores: int = 4,
                      seed: int = 42) -> az.InferenceData:
    """
    Fit a linear-regression model with a Dirac-spike Laplace-slab prior on
    the coefficient vector beta. Hyperparameters pi, sigma, b are sampled
    from their priors (Beta(1,1), Jeffreys, Jeffreys respectively).
    """
    n, p = X.shape

    with pm.Model() as model:

        # ----- hyperpriors -----
        # pi ~ Beta(1, 1)
        pi = pm.Beta("pi", alpha=1.0, beta=1.0)

        # sigma, b ~ improper Jeffreys p(.) prop 1/. via pm.Flat on the log
        # scale. pm.Flat is improper uniform on the unconstrained scale;
        # the auto-Jacobian d sigma / d log_sigma = sigma yields the implied
        # Jeffreys p(sigma) prop 1/sigma on the natural scale. The posterior
        # is proper given the likelihood.
        log_sigma = pm.Flat("log_sigma")
        sigma     = pm.Deterministic("sigma", pt.exp(log_sigma))

        log_b = pm.Flat("log_b")
        b     = pm.Deterministic("b", pt.exp(log_b))

        # ----- prior on inclusion indicators -----
        gamma = pm.Bernoulli("gamma", p=pi, shape=p)

        # ----- prior on slab values -----
        # PyMC's pm.Laplace(mu, b_scale) has density
        #   (1 / (2 b_scale)) * exp(-|x - mu| / b_scale).
        # Slab scale = b * sigma per the prompt.
        beta_slab = pm.Laplace("beta_slab", mu=0.0, b=b * sigma, shape=p)

        # ----- mixture form of the prior -----
        # beta_j = gamma_j * beta_slab_j
        #   beta_j == 0           when gamma_j = 0  (delta_0)
        #   beta_j == beta_slab_j when gamma_j = 1  (Laplace slab)
        beta = pm.Deterministic("beta", gamma * beta_slab)

        # ----- likelihood -----
        pm.Normal("y_obs", mu=pt.dot(X, beta), sigma=sigma, observed=y)

        # ----- compound step -----
        # gamma is the only discrete block; everything continuous goes to
        # NUTS so PyMC samples it together by default. Naming the steps
        # explicitly is just for clarity.
        step_disc = pm.BinaryGibbsMetropolis([gamma])
        step_cont = pm.NUTS([pi, log_sigma, log_b, beta_slab])

        idata = pm.sample(
            draws=draws,
            tune=tune,
            chains=chains,
            cores=cores,
            step=[step_disc, step_cont],
            random_seed=seed,
            progressbar=False,
            return_inferencedata=True,
        )

    return idata


if __name__ == "__main__":
    # Example: draw one DGP replicate.
    y, X, truth = simulate_data(n=200, p=12, seed=2026)
    print(f"y shape: {y.shape}, X shape: {X.shape}, "
          f"k_true = {int(truth['gamma'].sum())}")
    print(f"truth: pi={truth['pi']:.3f}, sigma={truth['sigma']:.3f}, b={truth['b']:.3f}")

    # To fit the reference PyMC model:
    # idata = fit_spike_laplace(y, X, draws=2000, tune=2000, chains=4, cores=4, seed=42)
