# Data-generating process for the bym2_offset_only benchmark model.
# Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data, for
#            coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N       <- 12L
    node1   <- 1:(N - 1L)
    node2   <- 2:N
    N_edges <- length(node1)
    E       <- rgamma(N, shape = 5, rate = 1)
    scaling_factor <- 1
    beta0   <- rnorm(1, 0, 1)
    sigma   <- abs(rnorm(1, 0, 1))
    rho     <- rbeta(1, 0.5, 0.5)
    theta   <- rnorm(N)
    phi     <- cumsum(rnorm(N, 0, 0.2))
    phi     <- phi - mean(phi)
    convolved_re <- sqrt(1 - rho) * theta + sqrt(rho / scaling_factor) * phi
    y <- rpois(N, lambda = exp(log(E) + beta0 + convolved_re * sigma))
    list(
        data = list(
            N       = N,
            N_edges = N_edges,
            node1   = as.integer(node1),
            node2   = as.integer(node2),
            y       = as.integer(y),
            E       = E,
            scaling_factor = scaling_factor
        ),
        truth = list(
            beta0 = beta0,
            sigma = sigma,
            rho   = rho,
            theta = matrix(theta, nrow = 1L),
            phi   = matrix(phi,   nrow = 1L)
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("bym2_offset_only.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
