# Data-generating process for the logistic_BART_model benchmark model.
# Extracted from sim1_logistic_BART_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 120L
    D <- 3L
    X <- matrix(runif(N * D, -1, 1), nrow = N, ncol = D)
    f <- 1.0 * sin(pi * X[, 1]) + X[, 2]^2 - 0.75 * X[, 3]
    p <- plogis(f)
    y <- rbinom(N, size = 1L, prob = p)

    list(
        data = list(N = N, D = D, X = X, y = as.integer(y)),
        truth = list(
            # AI's "r" history key is the latent f on the logit scale.
            # truth_f is the per-obs vector. Stored as a 1 x N matrix to
            # match the alignment convention.
            r = matrix(f, nrow = 1L)))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)
