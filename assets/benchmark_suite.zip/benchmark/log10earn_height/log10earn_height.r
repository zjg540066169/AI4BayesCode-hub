# Data-generating process for the log10earn_height benchmark model.
# Extracted from sim1_log10earn_height.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 50L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    height <- rnorm(N_DATA, 65, 4)              # height in inches, plausible range
    beta1_true <- runif(1, 2.5, 4.5)            # log10(earn) intercept
    beta2_true <- runif(1, 0.005, 0.03)         # slope per inch
    sigma_true <- runif(1, 0.15, 0.40)
    log10_earn <- beta1_true + beta2_true * height + rnorm(N_DATA, 0, sigma_true)
    earn <- 10^log10_earn

    list(
        data = list(
            N           = N_DATA,
            height      = height,
            log10_earn  = log10_earn,   # for AI
            earn        = earn          # for Stan
        ),
        truth = list(
            beta  = matrix(c(beta1_true, beta2_true), nrow = 1L),
            sigma = sigma_true
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("log10earn_height.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
