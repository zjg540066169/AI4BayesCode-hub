"""
Truncated Dirichlet-process Gaussian mixture benchmark model.

Prior (with stick-breaking truncation at K + 1 components):
    alpha    ~ Gamma(1, 1)
    V_k      ~ Beta(1, alpha)         for k = 1, ..., K
    V_{K+1}  = 1                       (truncation)
    pi_k     = V_k * prod_{j < k} (1 - V_j)
    mu_k     ~ Normal(0, sd = 5)      for k = 1, ..., K + 1
    sigma_k  ~ HalfNormal(scale = 1)  for k = 1, ..., K + 1
    z_i      ~ Categorical(pi_1, ..., pi_{K + 1})

Likelihood:
    y_i | z_i, mu, sigma ~ Normal(mu_{z_i}, sigma_{z_i}),  i = 1, ..., N

Returns (data, truth):
    data  : dict {N, K, y}
    truth : dict {alpha, w, mu, sigma, z} — the prior draws used to
            simulate y.

NOTE: the mixture likelihood is invariant to permutations of the
K + 1 component labels, so per-component coverage on (w, mu, sigma, z)
is not directly meaningful — chains can land in any permutation of
the same posterior mode. Python does not have a standard relabeling
package (R has `label.switching`); the practical alternative is to
compare on label-invariant summaries, e.g.

    alpha                                        (scalar, identifiable)
    f(y) = sum_k w_k * N(y; mu_k, sigma_k)       (predictive density,
                                                  invariant under
                                                  permutation of k)

The DGP draws from the prior + likelihood verbatim, but rejects
degenerate realisations so cross-impl comparisons aren't dominated by
label-switching / mixing artefacts. Each accepted draw is still a valid
prior + likelihood sample, only restricted to a benign subset of
prior-space:
    - K_active in {2, 3}                       (K_active = |unique(z)|)
    - sigma_k >= 0.30 for every active k
    - |mu_k|   <= 5.0  for every active k
    - min pairwise |mu_i - mu_j| >= 1.5 over active components
"""

import numpy as np

N_DEFAULT = 200
K_DEFAULT = 9   # truncation level (K_trunc = K + 1 components)


def simulate_data(n=N_DEFAULT, K=K_DEFAULT, seed=1, max_tries=20000):
    rng = np.random.default_rng(seed)
    for _ in range(max_tries):
        alpha     = float(rng.gamma(1.0, 1.0))
        V_free    = rng.beta(1.0, alpha, size=K)
        V         = np.append(V_free, 1.0)
        one_minus = np.append([1.0], np.cumprod(1.0 - V_free))
        w         = V * one_minus
        w         = w / w.sum()
        mu        = rng.normal(0.0, 5.0, size=K + 1)
        sigma     = np.abs(rng.normal(0.0, 1.0, size=K + 1))
        z         = rng.choice(K + 1, size=n, p=w)
        y         = rng.normal(mu[z], sigma[z]).astype(np.float64)

        active = np.unique(z)
        if not (2 <= active.size <= 3):
            continue
        if np.any(sigma[active] < 0.3):
            continue
        if np.any(np.abs(mu[active]) > 5.0):
            continue
        if active.size >= 2:
            mu_a = np.sort(mu[active])
            if np.any(np.diff(mu_a) < 1.5):
                continue

        data  = {"N": n, "K": K, "y": y}
        truth = {"alpha": alpha, "w": w, "mu": mu, "sigma": sigma, "z": z}
        return data, truth
    raise RuntimeError(f"DGP rejection failed after {max_tries} tries (seed={seed})")


# Example usage:
data, truth = simulate_data(seed=1)
print(f"y shape: {data['y'].shape}, "
      f"K_active = {len(np.unique(truth['z']))}, "
      f"alpha = {truth['alpha']:.3f}")

# To fit the reference PyMC model:
# import pymc as pm
# with pm.Model() as model:
#     alpha = pm.Gamma("alpha", alpha=1.0, beta=1.0)
#     w     = pm.StickBreakingWeights("w", alpha=alpha, K=data["K"])
#     mu    = pm.Normal("mu",        mu=0.0, sigma=5.0, shape=data["K"] + 1)
#     sigma = pm.HalfNormal("sigma", sigma=1.0,        shape=data["K"] + 1)
#     obs   = pm.NormalMixture("obs", w=w, mu=mu, sigma=sigma, observed=data["y"])
#     idata = pm.sample(draws=1000, tune=1000, chains=4,
#                       target_accept=0.9, random_seed=123)
# print(idata.posterior["alpha"].mean().item())
