# Data-generating process for the surgical_model benchmark model.
# Extracted from sim1_surgical_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 12L
    n <- rpois(N, lambda = 20) + 5L
    mu <- rnorm(1, 0, 1000)
    sigma <- abs(rnorm(1, 0, 1))   # HalfNormal(0, 1)
    sigmasq <- sigma^2
    b <- rnorm(N, mu, sigma)
    r <- rbinom(N, size = n, prob = plogis(b))
    list(
        data = list(N = N, r = as.integer(r), n = as.integer(n)),
        truth = list(mu = mu, sigma = sigma, b = matrix(b, nrow = 1L))
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("surgical_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
