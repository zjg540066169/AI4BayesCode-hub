# Data-generating process for the hex_ising_seg_0 benchmark model.
# Extracted from sim1_hex_ising_seg_0.R. Returns a list with:
#   $data  : inputs to the fitted model (N, beta FIXED, y, edges, grid dims)
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.
#
# Hexagonal 6-NN adjacency via odd-r offset coordinates; planted centred disk
# = class 1, background = class 0; Gaussian noise with per-class sigma_k.

simulate_data <- function(seed = 1) {
    set.seed(seed)
    R     <- 24L                       # rows
    C     <- 24L                       # cols
    mu    <- c(0.0, 2.0)               # class means
    sigma <- c(1.3, 1.3)               # per-class emission sd (truth)
    beta  <- 0.8                       # FIXED Ising coupling
    N     <- R * C

    # Hexagonal neighbours (odd-r offset): one entry per undirected edge (i < j).
    ei <- integer(0); ej <- integer(0)
    for (r in 1:R) for (c in 1:C) {
        i  <- (r - 1L) * C + c
        nb <- list()
        if (c < C) nb[[length(nb) + 1L]] <- c(r, c + 1L)
        if (r %% 2L == 1L) {                              # odd row
            if (r > 1)          nb[[length(nb) + 1L]] <- c(r - 1L, c)
            if (r > 1 && c > 1) nb[[length(nb) + 1L]] <- c(r - 1L, c - 1L)
            if (r < R)          nb[[length(nb) + 1L]] <- c(r + 1L, c)
            if (r < R && c > 1) nb[[length(nb) + 1L]] <- c(r + 1L, c - 1L)
        } else {                                          # even row
            if (r > 1)          nb[[length(nb) + 1L]] <- c(r - 1L, c)
            if (r > 1 && c < C) nb[[length(nb) + 1L]] <- c(r - 1L, c + 1L)
            if (r < R)          nb[[length(nb) + 1L]] <- c(r + 1L, c)
            if (r < R && c < C) nb[[length(nb) + 1L]] <- c(r + 1L, c + 1L)
        }
        for (p in nb) {
            j <- (p[1] - 1L) * C + p[2]
            if (i < j) { ei <- c(ei, i); ej <- c(ej, j) }
        }
    }

    # Planted ground truth: centred disk = class 1, background = class 0.
    rc  <- expand.grid(r = 1:R, c = 1:C)
    cx  <- (R + 1) / 2; cy <- (C + 1) / 2; rad <- min(R, C) / 4
    x_true <- as.integer(((rc$r - cx)^2 + (rc$c - cy)^2) <= rad^2)
    y      <- rnorm(N, mu[x_true + 1L], sigma[x_true + 1L])

    list(
        data = list(
            N       = N,
            beta    = beta,
            y       = y,
            edges_i = as.integer(ei),
            edges_j = as.integer(ej),
            R_rows  = R,
            C_cols  = C),
        truth = list(
            mu_0    = mu[1],
            mu_1    = mu[2],
            sigma_0 = sigma[1],
            sigma_1 = sigma[2],
            x       = matrix(x_true, nrow = 1L)))
}

# Example usage:
sim <- simulate_data(seed = 1)
str(sim)

# To fit the reference bayesImageS::mcmcPotts model:
# library(bayesImageS)
# # Build (N x max_deg) neighbours matrix and blocks via greedy graph colouring
# # (for chequerboard updates) from sim$data$edges_i / sim$data$edges_j --
# # see sim1_hex_ising_seg_0.R `build_bayesimages_inputs` for the helper.
# priors <- list(k = 2, mu = c(0, 2), mu.sd = rep(5, 2),
#                sigma = rep(1, 2), sigma.nu = rep(2, 2),
#                beta  = rep(sim$data$beta, 2))   # rep => FIX beta
# mh     <- list(algorithm = "ex", bandwidth = 1, adaptive = NA, auxiliary = 1)
# fit    <- bayesImageS::mcmcPotts(sim$data$y, neigh, blocks, priors, mh,
#                                   niter = 2000, nburn = 1000)
