# Data-generating process for the nes_logit_model benchmark model.
# Extracted from sim1_nes_logit_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N      <- 40L
    income <- rnorm(N)
    alpha  <- rnorm(1, 0, 2)
    beta   <- rnorm(1, 0, 2)
    vote   <- rbinom(N, 1, plogis(alpha + beta * income))
    list(
        data  = list(N = N, income = income, vote = as.integer(vote)),
        truth = list(alpha = alpha, beta = beta)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("nes_logit_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
