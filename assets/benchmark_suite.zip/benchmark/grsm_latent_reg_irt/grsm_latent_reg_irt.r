# Data-generating process for the grsm_latent_reg_irt benchmark model.
# Extracted from sim1_grsm_latent_reg_irt.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)

    sample_rsm <- function(theta_eff, beta_i, kappa) {
        unsummed <- c(0, theta_eff - beta_i - kappa)
        probs <- exp(cumsum(unsummed))
        probs <- probs / sum(probs)
        sample.int(length(probs), 1, prob = probs) - 1L
    }

    I <- 5L
    J <- 30L
    K <- 3L
    m <- 3L            # SHARED max category across items
    N <- I * J
    ii <- rep(seq_len(I), each = J)
    jj <- rep(seq_len(J), times = I)
    W <- cbind(1, matrix(rnorm(J * (K - 1L)), nrow = J, ncol = K - 1L))

    # W centering + scaling per .txt — first column unchanged; others
    # binary-aware: (W - mean)/(max-min) if binary, else (W - mean)/(2*sd).
    adj <- matrix(0, nrow = 2, ncol = K)
    adj[1, 1] <- 0; adj[2, 1] <- 1
    if (K > 1L) {
        for (k in 2:K) {
            adj[1, k] <- mean(W[, k])
            adj[2, k] <- 2 * sd(W[, k])
            if (adj[2, k] == 0) adj[2, k] <- 1
        }
    }
    W_adj <- W
    for (k in seq_len(K)) W_adj[, k] <- (W[, k] - adj[1, k]) / adj[2, k]

    alpha       <- rlnorm(I, 1, 1)
    beta_free   <- rnorm(I - 1L, 0, 3)
    beta        <- c(beta_free, -sum(beta_free))
    kappa_free  <- rnorm(m - 1L, 0, 3)
    kappa       <- c(kappa_free, -sum(kappa_free))
    lambda_adj  <- rt(K, df = 3)
    theta       <- rnorm(J, as.numeric(W_adj %*% lambda_adj), 1)
    y <- integer(N)
    for (n in seq_len(N)) {
        y[n] <- sample_rsm(theta[jj[n]] * alpha[ii[n]],
                           beta[ii[n]], kappa)
    }

    list(
        data = list(
            I  = I,
            J  = J,
            K  = K,
            N  = N,
            m  = m,
            ii = as.integer(ii),
            jj = as.integer(jj),
            W  = W,                 # raw W for Stan (Stan does its own adjustment? — actually Stan model uses W as-is; check)
            W_adj = W_adj,           # adjusted W for AI cpp
            y  = as.integer(y)),
        truth = list(
            alpha      = alpha,
            beta_free  = beta_free,
            kappa_free = kappa_free,
            theta      = theta,
            lambda     = lambda_adj))   # AI key 'lambda' = adjusted scale
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("grsm_latent_reg_irt.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
