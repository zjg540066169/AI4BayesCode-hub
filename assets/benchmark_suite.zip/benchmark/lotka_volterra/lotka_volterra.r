# Data-generating process for the lotka_volterra benchmark model.
# Extracted from sim1_lotka_volterra.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_OBS <- 10L
TS    <- seq(1.0, 10.0, by = 1.0)

# RK4 forward solver (matches the runner's solve_lv_R)
lv_rhs <- function(z, th) {
    u <- z[1]; v <- z[2]
    c((th[1] - th[2] * v) * u, (-th[3] + th[4] * u) * v)
}
solve_lv <- function(theta, z0, ts, n_sub = 200L) {
    N <- length(ts)
    out <- matrix(NA_real_, N, 2L)
    z <- as.numeric(z0); t_prev <- 0.0
    for (n in seq_len(N)) {
        target <- ts[n]; dt <- (target - t_prev) / n_sub
        for (i in seq_len(n_sub)) {
            k1 <- lv_rhs(z, theta)
            k2 <- lv_rhs(z + 0.5 * dt * k1, theta)
            k3 <- lv_rhs(z + 0.5 * dt * k2, theta)
            k4 <- lv_rhs(z + dt * k3, theta)
            z  <- z + (dt / 6) * (k1 + 2*k2 + 2*k3 + k4)
        }
        out[n, ] <- z; t_prev <- target
    }
    out
}

simulate_data <- function(seed = 123) {
    set.seed(seed)
    # Tight DGP around runner's defaults to ensure stable LV cycles
    alpha_t <- abs(rnorm(1, 1.0, 0.15))
    gamma_t <- abs(rnorm(1, 1.0, 0.15))
    beta_t  <- abs(rnorm(1, 0.05, 0.01)) + 0.005
    delta_t <- abs(rnorm(1, 0.05, 0.01)) + 0.005
    z_init_t <- c(abs(rnorm(1, 30, 5)) + 5,
                  abs(rnorm(1, 10, 2)) + 2)
    sigma_t  <- c(runif(1, 0.10, 0.30), runif(1, 0.10, 0.30))

    theta_t <- c(alpha_t, beta_t, gamma_t, delta_t)
    z_at_ts <- solve_lv(theta_t, z_init_t, TS, n_sub = 200L)
    # Floor to avoid log(0) in lognormal noise
    z_at_ts <- pmax(z_at_ts, 1e-3)

    y <- matrix(NA_real_, N_OBS, 2L)
    for (k in 1:2) y[, k] <- z_at_ts[, k] * exp(rnorm(N_OBS, 0, sigma_t[k]))
    y_init <- z_init_t * exp(rnorm(2, 0, sigma_t))
    y      <- pmax(y, 1e-3)
    y_init <- pmax(y_init, 1e-3)

    list(
        data = list(N = N_OBS, ts = TS, y = y, y_init = y_init),
        truth = list(
            theta_dyn = matrix(theta_t,  nrow = 1L),
            z_init    = matrix(z_init_t, nrow = 1L),
            sigma     = matrix(sigma_t,  nrow = 1L)
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("lotka_volterra.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
