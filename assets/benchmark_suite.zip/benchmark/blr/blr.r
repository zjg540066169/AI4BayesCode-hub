# Data-generating process for the blr benchmark model.
# Extracted from sim1_blr.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 30L
D_DATA <- 3L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    X    <- matrix(rnorm(N_DATA * D_DATA), nrow = N_DATA, ncol = D_DATA)
    beta <- rnorm(D_DATA, 0, 10)
    sigma <- abs(rnorm(1, 0, 10))
    y <- as.numeric(X %*% beta) + rnorm(N_DATA, 0, sigma)
    list(
        data  = list(N = N_DATA, D = D_DATA, X = X, y = y),
        truth = list(beta = matrix(beta, nrow = 1L), sigma = sigma)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("blr.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
