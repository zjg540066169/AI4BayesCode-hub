# Data-generating process for the dogs_log benchmark model.
# Extracted from sim1_dogs_log.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DOGS   <- 8L
N_TRIALS <- 12L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    beta_1 <- runif(1, -1, 0)
    beta_2 <- runif(1,  0,  1)
    N <- N_DOGS * N_TRIALS
    y_mat  <- matrix(0L, N_DOGS, N_TRIALS)
    y_flat <- numeric(N)
    A_flat <- numeric(N)
    S_flat <- numeric(N)
    for (j in seq_len(N_DOGS)) {
        cum_a <- 0L; cum_s <- 0L
        for (t in seq_len(N_TRIALS)) {
            idx <- (j - 1L) * N_TRIALS + t
            A_flat[idx] <- cum_a
            S_flat[idx] <- cum_s
            p <- plogis(beta_1 * cum_a + beta_2 * cum_s)
            y_mat[j, t] <- rbinom(1L, 1L, p)
            y_flat[idx] <- as.numeric(y_mat[j, t])
            if (y_mat[j, t] == 1L) cum_s <- cum_s + 1L else cum_a <- cum_a + 1L
        }
    }
    list(
        data  = list(n_dogs = N_DOGS, n_trials = N_TRIALS,
                     y = y_mat,
                     y_flat = y_flat, A_flat = A_flat, S_flat = S_flat),
        truth = list(beta1 = matrix(beta_1, nrow = 1L),
                     beta2 = matrix(beta_2, nrow = 1L))
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("dogs_log.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
