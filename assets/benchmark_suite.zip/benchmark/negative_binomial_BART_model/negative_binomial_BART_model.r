# Data-generating process for the negative_binomial_BART_model benchmark model.
# Extracted from sim1_negative_binomial_BART_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 120L
    D <- 3L
    X <- matrix(runif(N * D, -1, 1), nrow = N, ncol = D)
    mu0   <- runif(N, 0.5, 2.0)
    log_f <- 0.6 * sin(pi * X[, 1]) + 0.4 * X[, 2]^2 - 0.5 * X[, 3]
    f     <- exp(log_f)
    mu    <- mu0 * f
    kappa <- 2.5
    y <- rnbinom(N, size = kappa, mu = mu)

    list(
        data = list(N = N, D = D, X = X,
                    y = as.integer(y), mu0 = mu0),
        truth = list(
            # AI's "r" history key is the latent log-multiplier log_f (the
            # genbart_block samples log f given the mu0 offset). The
            # observation model is mu_i = mu0_i exp(log_f_i), so AI's r
            # is directly comparable to the DGP's log_f vector.
            r     = matrix(log_f, nrow = 1L),
            kappa = kappa))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)
