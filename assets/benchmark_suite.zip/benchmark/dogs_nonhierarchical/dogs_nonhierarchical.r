# Data-generating process for the dogs_nonhierarchical benchmark model.
# Extracted from sim1_dogs_nonhierarchical.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

J_TRUE <- 10L
T_TRUE <- 12L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    mu_true    <- rnorm(2, 0, 0.3)
    sigma_true <- abs(rnorm(2, 0, 0.3)) + 0.1
    rho_true   <- runif(1, -0.3, 0.3)
    Sigma <- diag(sigma_true) %*% matrix(c(1, rho_true, rho_true, 1), 2, 2) %*%
             diag(sigma_true)
    L_chol <- t(chol(Sigma))  # lower Cholesky
    y <- matrix(0L, J_TRUE, T_TRUE)
    y[, 1] <- 1L  # first trial always shock per model convention
    for (j in seq_len(J_TRUE)) {
        theta_j <- mu_true + as.numeric(L_chol %*% rnorm(2))
        alpha_j <- plogis(theta_j[1])
        beta_j  <- plogis(theta_j[2])
        s_cum <- 1L; a_cum <- 0L
        for (t in 2:T_TRUE) {
            p <- alpha_j^s_cum * beta_j^a_cum
            y[j, t] <- rbinom(1L, 1L, p)
            if (y[j, t] == 1L) s_cum <- s_cum + 1L else a_cum <- a_cum + 1L
        }
    }
    list(
        data  = list(n_dogs = J_TRUE, n_trials = T_TRUE, y = y),
        truth = list(mu      = matrix(mu_true, nrow = 1L),
                     sigma_1 = sigma_true[1],
                     sigma_2 = sigma_true[2],
                     rho     = rho_true)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("dogs_nonhierarchical.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
