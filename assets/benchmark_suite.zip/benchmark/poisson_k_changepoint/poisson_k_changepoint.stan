data {
  int<lower=1> T;
  int<lower=0, upper=T-1> K_cp;
  array[T] int<lower=0> D;
  vector<lower=0>[K_cp + 1] r;
}

parameters {
  vector<lower=0>[K_cp + 1] lambda;
}

transformed parameters {
  matrix[K_cp + 1, T] cum_lp;   // cumulative log-likelihood per segment/rate
  matrix[K_cp + 1, T] dp;       // dynamic programming table
  real log_prior_cp;
  real log_marginal;

  // Uniform prior over ordered change-point tuples:
  // choose K_cp positions from {2, ..., T}, i.e. T - 1 possible internal boundaries
  log_prior_cp = -lchoose(T - 1, K_cp);

  // Precompute cumulative log-likelihoods
  for (j in 1:(K_cp + 1)) {
    cum_lp[j, 1] = poisson_lpmf(D[1] | lambda[j]);
    for (t in 2:T) {
      cum_lp[j, t] = cum_lp[j, t - 1] + poisson_lpmf(D[t] | lambda[j]);
    }
  }

  // Initialize DP table
  for (j in 1:(K_cp + 1)) {
    for (t in 1:T) {
      dp[j, t] = negative_infinity();
    }
  }

  // First segment: must leave at least K_cp observations for remaining segments
  for (t in 1:(T - K_cp)) {
    dp[1, t] = cum_lp[1, t];
  }

  // Segments 2, ..., K_cp + 1
  for (j in 2:(K_cp + 1)) {
    int t_min;
    int t_max;

    t_min = j; // at least one observation per segment
    t_max = T - ((K_cp + 1) - j); // leave room for remaining segments

    for (t in t_min:t_max) {
      real acc;
      acc = negative_infinity();

      // previous segment ends at u, current one runs from u+1 to t
      for (u in (j - 1):(t - 1)) {
        real interval_lp;
        interval_lp = cum_lp[j, t] - cum_lp[j, u];
        acc = log_sum_exp(acc, dp[j - 1, u] + interval_lp);
      }

      dp[j, t] = acc;
    }
  }

  log_marginal = log_prior_cp + dp[K_cp + 1, T];
}

model {
  lambda ~ exponential(r);
  target += log_marginal;
}

generated quantities {
  real log_lik;
  log_lik = log_marginal;
}