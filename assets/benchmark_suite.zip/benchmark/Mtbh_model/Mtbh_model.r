# Data-generating process for the Mtbh_model benchmark model.
# Extracted from sim1_Mtbh_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

T_TRUE <- 5L
N_TRUE <- 20L  # true population — reduced for eps_raw NUTS speed
M_AUG  <- 40L  # augmented size — eps_raw is M-dim NUTS, dominant cost

simulate_data <- function(seed = 123) {
    set.seed(seed)
    omega_true  <- N_TRUE / M_AUG
    mean_p_true <- runif(T_TRUE, 0.20, 0.55)
    gamma_true  <- runif(1, -1.0, 1.0)
    sigma_true  <- runif(1, 0.4, 1.2)
    eps_t       <- rnorm(N_TRUE, 0, sigma_true)

    y_true_full <- matrix(0L, N_TRUE, T_TRUE)
    alpha <- log(mean_p_true / (1 - mean_p_true))
    for (i in seq_len(N_TRUE)) {
        lp1 <- alpha[1] + eps_t[i]
        y_true_full[i, 1] <- rbinom(1L, 1L, 1 / (1 + exp(-lp1)))
        for (t in 2:T_TRUE) {
            lp <- alpha[t] + eps_t[i] + gamma_true * y_true_full[i, t-1]
            y_true_full[i, t] <- rbinom(1L, 1L, 1 / (1 + exp(-lp)))
        }
    }
    obs_idx <- which(rowSums(y_true_full) > 0)
    C <- length(obs_idx)
    y_full <- matrix(0L, M_AUG, T_TRUE)
    y_full[seq_len(C), ] <- y_true_full[obs_idx, , drop = FALSE]

    list(
        data = list(M = M_AUG, T = T_TRUE, y = y_full),
        truth = list(omega = omega_true,
                     mean_p = matrix(mean_p_true, nrow = 1L),
                     gamma  = gamma_true,
                     sigma  = sigma_true)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("Mtbh_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
