# Data-generating process for the multi_occupancy benchmark model.
# Extracted from sim1_multi_occupancy.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    J <- 6L
    K <- 4L
    S <- 12L
    alpha    <- rcauchy(1, 0, 2.5)
    beta     <- rcauchy(1, 0, 2.5)
    Omega    <- rbeta(1, 2, 2)
    rho_uv   <- runif(1, -0.5, 0.5)
    sigma_uv <- abs(rcauchy(2, 0, 2.5))
    Sigma <- matrix(c(sigma_uv[1]^2,
                      rho_uv * sigma_uv[1] * sigma_uv[2],
                      rho_uv * sigma_uv[1] * sigma_uv[2],
                      sigma_uv[2]^2), 2, 2)
    L  <- chol(Sigma)
    uv <- matrix(rnorm(S * 2), nrow = S, ncol = 2) %*% L
    uv1 <- uv[, 1]
    uv2 <- uv[, 2]
    logit_psi   <- alpha + uv1
    logit_theta <- beta  + uv2
    available <- rbinom(S, 1, Omega)
    Xall <- matrix(0L, nrow = S, ncol = J)
    observed <- logical(S)
    for (i in seq_len(S)) {
        if (available[i] == 1L) {
            occ <- rbinom(J, 1, plogis(logit_psi[i]))
            for (j in seq_len(J)) {
                Xall[i, j] <- if (occ[j] == 1L)
                    rbinom(1, K, plogis(logit_theta[i])) else 0L
            }
            observed[i] <- any(Xall[i, ] > 0L)
        }
    }
    X_obs <- Xall[observed, , drop = FALSE]
    n     <- nrow(X_obs)

    list(
        data = list(
            J     = J,
            K     = K,
            S     = S,
            n     = n,
            X_obs = X_obs,                  # n x J for Stan
            X_full = Xall),                 # S x J for AI
        truth = list(
            alpha     = alpha,
            beta      = beta,
            Omega     = Omega,
            rho_uv    = rho_uv,
            sigma_uv1 = sigma_uv[1],
            sigma_uv2 = sigma_uv[2]))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("multi_occupancy.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
