# Data-generating process for the water_bif benchmark model.
# Returns a list with:
#   $data  : inputs to the fitted model (N, p, r, D, var_names)
#   $truth : ground-truth latent DAG adjacency matrix for recovery / coverage checks.
#
# The underlying Bayesian network — both the DAG structure and the CPT parameter
# values — is FIXED and loaded from a `.bif` network spec (32 nodes, mixed
# cardinalities). Only the sampled categorical data `D` varies between
# replicates; the seed controls the forward sample from the fixed network.
#
# The `.bif` file is auto-downloaded by `download_water_bif()` on first call
# to `simulate_data()` if not already present at `bif_path`.
#
# DEFAULT SAMPLE SIZE: N = 100. At this sample size, the BDeu marginal
# posterior over DAGs has sufficient spread that order MCMC mixes inside
# the canonical 20K-burn + 20K-keep sim1 budget. With larger N (e.g.
# N = 1000), the posterior concentrates too sharply for 40K iterations
# to explore — cross-chain R-hat on CPDAG features stalls > 1.05.

# Auto-download helper: fetches the gzipped .bif from a public Bayesian-network
# repository and decompresses to the requested local path. Idempotent — does
# nothing if the destination file already exists.
download_water_bif <- function(
        dest  = "water.bif",
        url   = "https://www.bnlearn.com/bnrepository/water/water.bif.gz",
        quiet = TRUE) {
    if (file.exists(dest)) return(invisible(dest))

    tmp_gz <- tempfile(fileext = ".bif.gz")
    on.exit(try(file.remove(tmp_gz), silent = TRUE), add = TRUE)

    tryCatch(
        utils::download.file(url, tmp_gz, mode = "wb", quiet = quiet),
        error = function(e) stop(sprintf(
            "Failed to download Bayesian-network spec from %s\nReason: %s\nManually fetch the file and place it at %s.",
            url, conditionMessage(e), dest)))

    # Decompress .gz -> dest using base R.
    con_in  <- gzfile(tmp_gz, "r")
    on.exit(try(close(con_in), silent = TRUE), add = TRUE)
    writeLines(readLines(con_in), dest)
    if (!file.exists(dest))
        stop("Decompression succeeded but destination file is missing: ", dest)

    invisible(dest)
}

simulate_data <- function(seed = 1, N = 100L, bif_path = "water.bif") {
    set.seed(seed)

    if (!requireNamespace("bnlearn", quietly = TRUE))
        stop("Package 'bnlearn' is required: install.packages('bnlearn').")
    if (!file.exists(bif_path)) {
        message("[water_bif] auto-downloading network spec to ", bif_path, " ...")
        download_water_bif(dest = bif_path)
    }

    # ---- Load fixed truth DAG + CPTs from the .bif spec.
    truth_bn  <- bnlearn::read.bif(bif_path)
    var_names <- names(truth_bn)            # node labels (topological order)
    p         <- length(var_names)
    truth_adj <- bnlearn::amat(truth_bn)    # p x p binary; truth_adj[i, j] = 1 iff i -> j

    # ---- Forward-sample N i.i.d. categorical observations from truth_bn.
    D_df  <- bnlearn::rbn(truth_bn, n = as.integer(N))
    D_df  <- D_df[, var_names, drop = FALSE]                 # enforce column order
    cards <- vapply(D_df, function(col) length(levels(col)), integer(1))

    # Convert factor levels to 1-indexed integers; result is N x p integer matrix.
    D <- do.call(cbind, lapply(D_df, as.integer))
    colnames(D) <- var_names
    storage.mode(D) <- "integer"

    list(
        data = list(
            N         = as.integer(N),
            p         = as.integer(p),
            r         = as.integer(cards),
            D         = D,
            var_names = var_names),
        truth = list(adj = truth_adj))
}

# Example usage (skipped gracefully if water.bif is not in the current dir):
sim <- tryCatch(simulate_data(seed = 1),
                error = function(e) { message("[dgp-check] skipped: ", e$message); NULL })
if (!is.null(sim)) {
    str(sim, max.level = 1)
    cat(sprintf("[dgp-check] N = %d, p = %d, sum(truth adj) = %d edges, max(r) = %d\n",
                sim$data$N, sim$data$p, sum(sim$truth$adj), max(sim$data$r)))
}

# To fit the reference order-MCMC model with bnlearn / BiDAG at the canonical
# sim1 budget of 20K burn + 20K keep = 40K total iterations, matching the
# AI-side `order_mcmc_block` chain. With random initialisation (no MAP /
# hill-climb seed — the AI cpp has no equivalent shortcut), the median
# cross-chain max R-hat on CPDAG features over 100 replicates is ~1.009
# under the recommended preprocessing below.
#
# RECOMMENDED preprocessing for the reference fit (drop variables whose
# observed marginal is dominated by one level — they carry no posterior
# variability under the BDeu score):
#
# # Convert integer matrix to factor data.frame, drop singleton-level
# # vars (BiDAG requirement) AND near-singleton vars (dom level > 90%):
# D_obs   <- as.data.frame(lapply(seq_len(sim$data$p), function(j)
#     factor(sim$data$D[, j], levels = unique(sim$data$D[, j]))))
# names(D_obs) <- sim$data$var_names
# obs_lv   <- vapply(D_obs, function(col) length(levels(col)), integer(1))
# dom_frac <- vapply(D_obs, function(col) {
#     tbl <- tabulate(as.integer(col)); max(tbl) / sum(tbl)
# }, numeric(1))
# keep_v <- which(obs_lv >= 2 & dom_frac <= 0.9)
# D_obs <- D_obs[, keep_v, drop = FALSE]
# # Subset truth adjacency to the same variables for coverage analysis:
# truth_adj_eff <- sim$truth$adj[keep_v, keep_v]
#
# # Fit two independent chains for cross-chain R-hat:
# library(BiDAG)
# score <- BiDAG::scoreparameters("bdecat", D_obs,
#                                 bdecatpar = list(chi = 1, edgepf = 1))
# set.seed(1L)
# fit1 <- BiDAG::orderMCMC(score, plus1 = TRUE, hardlimit = 3L, MAP = FALSE,
#                          chainout = TRUE, scoreout = FALSE,
#                          iterations = 40000L)   # = 20K burn + 20K keep
# set.seed(2L)
# fit2 <- BiDAG::orderMCMC(score, plus1 = TRUE, hardlimit = 3L, MAP = FALSE,
#                          chainout = TRUE, scoreout = FALSE,
#                          iterations = 40000L)
# # Posterior edge marginal probability matrix M (p x p) from chain 1:
# M_post <- BiDAG::edgep(fit1, pdag = FALSE, burnin = 0.5)

# To compute cross-implementation R-hat on label-invariant CPDAG features
# (the Bayesian-network analog of Stephens 2000 relabeling for mixture
# models — DAGs in the same Markov equivalence class collapse to the same
# CPDAG, so per-edge metrics on CPDAG features are identification-clean):
#
# library(bnlearn); library(posterior)
# # ai_dags, ref_dags: (n_keep, p, p) binary arrays of posterior DAG samples
# # (from the AI implementation and the reference order MCMC, respectively).
# dag_to_cpdag <- function(adj, var_names) {
#     g <- bnlearn::empty.graph(var_names)
#     bnlearn::amat(g) <- adj
#     bnlearn::amat(bnlearn::cpdag(g))
# }
# extract_cpdag_feats <- function(dags, var_names) {
#     n_keep <- dim(dags)[1L]; p <- dim(dags)[2L]
#     skel <- dir <- array(0L, dim = c(n_keep, p, p))
#     for (s in seq_len(n_keep)) {
#         C <- dag_to_cpdag(dags[s, , ], var_names)
#         skel[s, , ] <- (C | t(C))         # undirected adjacency (symmetric)
#         dir [s, , ] <- (C & !t(C))         # compelled directed edges
#     }
#     list(skel = skel, directed = dir)
# }
# # IMPORTANT: extract features over the SAME `keep_v` subset that the
# # reference fit used (drop singleton + dom > 0.9 variables — see
# # `RECOMMENDED preprocessing` block above). Cross-chain R-hat over the
# # full p = 32 variable set is dominated by the no-signal vars and
# # over-counts degenerate (constant-zero) edge indicators.
# ai_f  <- extract_cpdag_feats(ai_dags,  sim$data$var_names[keep_v])
# ref_f <- extract_cpdag_feats(ref_dags, sim$data$var_names[keep_v])
#
# # Per-pair cross-impl R-hat on skeleton (upper triangle) + directed (all
# # off-diagonal pairs). Each pair gives one indicator series per chain.
# p <- sim$data$p
# rhat_skel <- matrix(NA_real_, p, p)
# rhat_dir  <- matrix(NA_real_, p, p)
# for (i in seq_len(p - 1L)) for (j in (i + 1L):p) {
#     rhat_skel[i, j] <- posterior::rhat(cbind(ai_f$skel[, i, j],
#                                              ref_f$skel[, i, j]))
# }
# for (i in seq_len(p)) for (j in seq_len(p)) if (i != j) {
#     rhat_dir[i, j] <- posterior::rhat(cbind(ai_f$directed[, i, j],
#                                             ref_f$directed[, i, j]))
# }
#
# # Truth CPDAG for coverage against the identifiable structure (use the
# # same `keep_v` subset as the fit):
# truth_cpdag <- dag_to_cpdag(sim$truth$adj[keep_v, keep_v],
#                             sim$data$var_names[keep_v])
