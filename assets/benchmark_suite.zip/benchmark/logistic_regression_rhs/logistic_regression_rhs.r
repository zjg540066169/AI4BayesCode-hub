# Data-generating process for the logistic_regression_rhs benchmark model.
# Extracted from sim1_logistic_regression_rhs.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    n <- 40L; d <- 5L
    x <- matrix(rnorm(n * d), nrow = n, ncol = d)
    scale_icept <- 1.5; scale_global <- 1.0
    nu_global <- 3.0; nu_local <- 3.0
    slab_scale <- 2.0; slab_df <- 4.0

    beta0  <- rnorm(1, 0, scale_icept)
    z      <- rnorm(d)
    lambda <- abs(rt(d, df = nu_local))
    tau    <- abs(rt(1, df = nu_global)) * (2 * scale_global)
    caux   <- 1 / rgamma(1, shape = 0.5 * slab_df, rate = 0.5 * slab_df)
    cc     <- slab_scale * sqrt(caux)
    lambda_tilde <- sqrt(cc^2 * lambda^2 / (cc^2 + tau^2 * lambda^2))
    beta   <- z * lambda_tilde * tau
    eta    <- drop(beta0 + x %*% beta)
    y      <- rbinom(n, 1, plogis(eta))
    list(
        data = list(n = n, d = d, y = as.integer(y), x = x,
                    scale_icept = scale_icept, scale_global = scale_global,
                    nu_global = nu_global, nu_local = nu_local,
                    slab_scale = slab_scale, slab_df = slab_df),
        truth = list(beta0 = beta0, beta = matrix(beta, nrow = 1L))
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("logistic_regression_rhs.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
