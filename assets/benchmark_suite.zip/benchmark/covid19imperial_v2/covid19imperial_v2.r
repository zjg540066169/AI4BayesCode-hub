# Data-generating process for the covid19imperial_v2 benchmark model.
# Extracted from sim1_covid19imperial_v2.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

M_TRUE <- 2L
P_TRUE <- 2L
N2     <- 30L
N0     <- 3L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    mu_true         <- abs(rnorm(M_TRUE, 3.28, 0.3)) + 0.5
    alpha_hier_true <- abs(rnorm(P_TRUE, 0.5, 0.15)) + 0.01
    kappa_true      <- abs(rnorm(1, 0.4, 0.05)) + 0.05
    phi_true        <- abs(rnorm(1, 5.0, 0.5)) + 1.0
    tau_true        <- abs(rnorm(1, 30.0, 3.0)) + 5.0
    y_seed_true     <- abs(rnorm(M_TRUE, 20.0, 3.0)) + 2.0
    ifr_noise_true  <- abs(rnorm(M_TRUE, 1.0, 0.05)) + 0.5

    pop  <- rep(1e6, M_TRUE)
    SI   <- pgamma(1:N2, shape = (6.5/4)^2, rate = 6.5/16) -
            pgamma(0:(N2-1), shape = (6.5/4)^2, rate = 6.5/16)
    SI   <- SI / sum(SI)

    f_pc <- pgamma(1:N2, shape = (17/5)^2, rate = 17/25) -
            pgamma(0:(N2-1), shape = (17/5)^2, rate = 17/25)
    f_pc <- f_pc / sum(f_pc)
    f_mat <- matrix(rep(f_pc, M_TRUE), N2, M_TRUE)

    X_arr <- array(0, c(N2, P_TRUE, M_TRUE))
    int_days <- c(10L, 20L)
    for (m in seq_len(M_TRUE))
        for (p in seq_len(P_TRUE))
            X_arr[int_days[p]:N2, p, m] <- 1

    a_const  <- log(1.05) / 6
    alpha_eff <- alpha_hier_true - a_const
    pred <- matrix(0, N2, M_TRUE)
    E_deaths <- matrix(0, N2, M_TRUE)
    for (m in seq_len(M_TRUE)) {
        Rt <- exp(-(X_arr[, , m] %*% alpha_eff)) * mu_true[m]
        for (t in seq_len(N0)) pred[t, m] <- y_seed_true[m]
        cumm <- N0 * y_seed_true[m]
        for (t in (N0 + 1L):N2) {
            cumm <- cumm + pred[t - 1L, m]
            susc <- max(0, (pop[m] - cumm) / pop[m])
            conv <- sum(pred[1:(t-1), m] * SI[(t-1):1])
            pred[t, m] <- max(0, susc * Rt[t] * conv)
        }
        E_deaths[1, m] <- 1e-15 * pred[1, m]
        for (t in 2:N2) {
            dconv <- sum(pred[1:(t-1), m] * rev(f_mat[1:(t-1), m]))
            E_deaths[t, m] <- ifr_noise_true[m] * dconv
        }
    }

    EpidemicStart <- rep(N0 + 1L, M_TRUE)
    N_per_country <- rep(N2, M_TRUE)
    deaths_mat <- matrix(0L, N2, M_TRUE)
    cases_mat  <- matrix(0L, N2, M_TRUE)
    for (m in seq_len(M_TRUE))
        for (t in EpidemicStart[m]:N_per_country[m]) {
            mu_td <- max(E_deaths[t, m], 1e-10)
            size  <- max(phi_true, 1e-3)
            deaths_mat[t, m] <- rnbinom(1, size = size, mu = mu_td)
            cases_mat[t, m]  <- rpois(1, max(pred[t, m], 1e-8))
        }

    # Pack X as list of M matrices (N2 x P) for Stan; as flat array for AI
    X_list <- lapply(seq_len(M_TRUE), function(m) X_arr[, , m])
    X_flat       <- as.numeric(X_arr)             # col-major: t, p, m
    deaths_flat  <- as.numeric(deaths_mat)         # col-major: t, m
    f_flat       <- as.numeric(f_mat)              # col-major: lag, m

    list(
        data = list(
            M = M_TRUE, P = P_TRUE, N0 = N0,
            N = as.integer(N_per_country), N2 = N2,
            cases = cases_mat, deaths = deaths_mat, f = f_mat,
            X = X_list, EpidemicStart = as.integer(EpidemicStart),
            pop = pop, SI = SI,
            # AI-specific flat packing
            X_flat = X_flat, deaths_flat = deaths_flat, f_flat = f_flat
        ),
        truth = list(
            mu         = matrix(mu_true, nrow = 1L),
            alpha_hier = matrix(alpha_hier_true, nrow = 1L),
            kappa      = kappa_true,
            phi        = phi_true,
            tau        = tau_true,
            y_seed     = matrix(y_seed_true, nrow = 1L),
            ifr_noise  = matrix(ifr_noise_true, nrow = 1L)
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("covid19imperial_v2.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
