# Data-generating process for the soil_incubation benchmark model.
# Extracted from sim1_soil_incubation.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    totalC_t0 <- 100; t0 <- 0
    N_t <- 20L
    ts  <- seq(0.5, 10, length.out = N_t)
    # Benign DGP: original `abs(rnorm)` for alphas allows transfer
    # coefficients > 1, which makes the ODE GAIN mass (alpha is
    # physically in [0,1] -- fraction transferred between pools).
    # When sum(C) > totalC_t0, eCO2_hat < 0, then eCO2mean = rnorm(...)
    # goes very negative, violating Stan's <lower=0> on eCO2mean.
    # Bounded uniform draws keep alpha in valid range and sigma small
    # so eCO2mean stays non-negative.
    k1  <- runif(1, 0.1, 1.0)
    k2  <- runif(1, 0.1, 1.0)
    alpha21 <- runif(1, 0.0, 1.0)
    alpha12 <- runif(1, 0.0, 1.0)
    gamma   <- rbeta(1, 10, 1)
    sigma   <- runif(1, 0.5, 2.0)
    C <- c(gamma * totalC_t0, (1 - gamma) * totalC_t0)
    eCO2_hat <- numeric(N_t)
    t_prev <- t0
    for (n in seq_len(N_t)) {
        dt <- ts[n] - t_prev
        steps <- max(5L, ceiling(dt / 0.05))
        h <- dt / steps
        for (s in seq_len(steps)) {
            d1 <- -k1 * C[1] + alpha12 * k2 * C[2]
            d2 <- -k2 * C[2] + alpha21 * k1 * C[1]
            C <- pmax(0, C + h * c(d1, d2))
        }
        eCO2_hat[n] <- totalC_t0 - sum(C)
        t_prev <- ts[n]
    }
    eCO2mean <- rnorm(N_t, eCO2_hat, sigma)
    list(
        data = list(totalC_t0 = totalC_t0, t0 = t0, N_t = N_t, ts = ts, eCO2mean = eCO2mean),
        truth = list(k_1 = k1, k_2 = k2, alpha_12 = alpha12, alpha_21 = alpha21,
                     gamma = gamma, sigma = sigma)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("soil_incubation.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
