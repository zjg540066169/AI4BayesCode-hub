# Data-generating process for the seeds_stanified_model benchmark model.
# Extracted from sim1_seeds_stanified_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    I <- 21L
    N <- rpois(I, lambda = 20) + 5L
    x1 <- sample(c(-0.5, 0.5), I, replace = TRUE)
    x2 <- sample(c(-0.5, 0.5), I, replace = TRUE)
    x1x2 <- x1 * x2
    alpha0  <- rnorm(1, 0, 1)
    alpha1  <- rnorm(1, 0, 1)
    alpha2  <- rnorm(1, 0, 1)
    alpha12 <- rnorm(1, 0, 1)
    sigma <- abs(rcauchy(1, 0, 1))
    c_raw <- rnorm(I, 0, sigma)
    b <- c_raw - mean(c_raw)
    eta <- alpha0 + alpha1 * x1 + alpha2 * x2 + alpha12 * x1x2 + b
    n   <- rbinom(I, size = N, prob = plogis(eta))
    list(
        data = list(I = I, n = as.integer(n), N = as.integer(N), x1 = x1, x2 = x2),
        truth = list(alpha = matrix(c(alpha0, alpha1, alpha2, alpha12), nrow = 1L),
                     sigma = sigma)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("seeds_stanified_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
