# Data-generating process for the ldaK5 benchmark model.
# Extracted from sim1_ldaK5.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

K_TRUE <- 5L
M_TRUE <- 10L
V_TRUE <- 15L
MEAN_N <- 20L
VK     <- V_TRUE %/% K_TRUE

simulate_data <- function(seed = 123) {
    set.seed(seed)
    phi_true <- matrix(0, K_TRUE, V_TRUE)
    for (k in seq_len(K_TRUE)) {
        block <- ((k - 1L) * VK + 1L):(k * VK)
        phi_true[k, block]  <- 0.85 / VK
        phi_true[k, -block] <- 0.15 / (V_TRUE - VK)
    }
    theta_true <- matrix(0, M_TRUE, K_TRUE)
    for (m in seq_len(M_TRUE)) {
        favored <- sample.int(K_TRUE, 1L)
        theta_true[m, ]        <- 0.05 / (K_TRUE - 1L)
        theta_true[m, favored] <- 0.80
        theta_true[m, ] <- theta_true[m, ] / sum(theta_true[m, ])
    }
    doc <- integer(0); w <- integer(0)
    for (m in seq_len(M_TRUE)) {
        n_m <- max(5L, rpois(1L, MEAN_N))
        zs  <- sample.int(K_TRUE, size = n_m, replace = TRUE, prob = theta_true[m, ])
        for (i in seq_len(n_m)) {
            wv <- sample.int(V_TRUE, size = 1L, prob = phi_true[zs[i], ])
            doc <- c(doc, m); w <- c(w, wv)
        }
    }
    list(
        data = list(w_dbl = as.numeric(w), w_int = as.integer(w),
                    doc_dbl = as.numeric(doc), doc_int = as.integer(doc),
                    M = M_TRUE, V = V_TRUE, N = length(w)),
        truth = list(theta = theta_true, phi = phi_true)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("ldaK5.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
