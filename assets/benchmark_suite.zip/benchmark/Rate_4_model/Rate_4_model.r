# Data-generating process for the Rate_4_model benchmark model.
# Extracted from sim1_Rate_4_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    n          <- 30L
    theta      <- rbeta(1, 1, 1)
    thetaprior <- rbeta(1, 1, 1)
    k          <- rbinom(1L, size = n, prob = theta)
    list(
        data  = list(n = n, k = as.integer(k)),
        truth = list(theta = theta, thetaprior = thetaprior)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("Rate_4_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
