data {
  int<lower=0> N;
  // bounds dropped: the Normal likelihood is un-truncated, so the
  // <lower=0, upper=200> clamp on kid_score from the original brms
  // export was a misleading input-validation constraint -- it does not
  // change the posterior, but if the simulated DGP draws fall outside
  // [0, 200] Stan rejects the data. For the sim1 benchmark we generate
  // benign y from the model itself (beta ~ N(0, 1), sigma ~ small
  // half-Normal), and both AI cpp + Stan fit the same Normal likelihood.
  vector[N] kid_score;
  vector<lower=0, upper=1>[N] mom_hs;
}
parameters {
  vector[2] beta;
  real<lower=0> sigma;
}
model {
  beta ~ normal(0, 1);
  sigma ~ cauchy(0, 2.5);
  kid_score ~ normal(beta[1] + beta[2] * mom_hs, sigma);
}


