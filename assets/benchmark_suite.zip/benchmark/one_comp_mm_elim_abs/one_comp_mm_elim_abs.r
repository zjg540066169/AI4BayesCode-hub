# Data-generating process for the one_comp_mm_elim_abs benchmark model.
# Extracted from sim1_one_comp_mm_elim_abs.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    t0    <- 0
    D     <- 100
    V     <- 10
    N_t   <- 20L
    times <- seq(0.2, 8, length.out = N_t)
    k_a   <- abs(rcauchy(1, 0, 1))
    K_m   <- abs(rcauchy(1, 0, 1))
    V_m   <- abs(rcauchy(1, 0, 1))
    sigma <- abs(rcauchy(1, 0, 1))
    C       <- numeric(N_t)
    conc    <- 0
    t_prev  <- t0
    for (n in seq_len(N_t)) {
        dt    <- times[n] - t_prev
        steps <- max(5L, ceiling(dt / 0.05))
        h     <- dt / steps
        for (s in seq_len(steps)) {
            t_cur <- t_prev + (s - 1L) * h
            dose  <- if (t_cur > 0) exp(-k_a * t_cur) * D * k_a / V else 0
            elim  <- (V_m / V) * conc / (K_m + conc + 1e-8)
            conc  <- max(1e-8, conc + h * (dose - elim))
        }
        C[n]    <- conc
        t_prev  <- times[n]
    }
    C_hat <- rlnorm(N_t, log(C), sigma)
    list(
        data = list(
            t0     = t0,
            D      = D,
            V      = V,
            N_t    = N_t,
            times  = times,
            C_hat  = C_hat),
        truth = list(
            k_a   = k_a,
            K_m   = K_m,
            V_m   = V_m,
            sigma = sigma))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("one_comp_mm_elim_abs.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
