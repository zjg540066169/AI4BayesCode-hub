# Data-generating process for the continuous-response BART benchmark model.
# Returns a list with:
#   $data  : inputs to the fitted model (N, D, X, y)
#   $truth : latent quantities used to simulate the data (f_bart, sigma)
#            for coverage / recovery checks.
#
# DGP (Friedman-like):
#   X_{ij} ~ Uniform(-1, 1),  i = 1..N, j = 1..D
#   f_i    = 1.5 sin(pi X_{i1}) + X_{i2}^2 - X_{i3}
#   y_i    ~ Normal(f_i, sigma = 0.5)

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 120L
    D <- 3L
    X <- matrix(runif(N * D, -1, 1), nrow = N, ncol = D)
    f <- 1.5 * sin(pi * X[, 1]) + X[, 2]^2 - 1.0 * X[, 3]
    sigma <- 0.5
    y <- rnorm(N, mean = f, sd = sigma)
    list(
        data  = list(N = N, D = D, X = X, y = y),
        truth = list(f_bart = matrix(f, nrow = 1L),
                     sigma  = sigma)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference BART::wbart model:
# library(BART)
# fit <- BART::wbart(x.train = sim$data$X, y.train = sim$data$y,
#                    ntree = 300, nskip = 4000, ndpost = 4000)
# cat("posterior mean sigma:", mean(fit$sigma), "\n")
