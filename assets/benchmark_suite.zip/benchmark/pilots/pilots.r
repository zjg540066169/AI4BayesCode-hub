# Data-generating process for the pilots benchmark model.
# Extracted from sim1_pilots.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    # N=600 (with 6 groups x 8 scenarios = 48 cells, ~12 obs/cell). At
    # N=60 (orig) cross-impl rhat sat at 1.07-1.09. At N=300 it dropped to
    # 1.019 with Stan ESS_bulk = 1161 the bottleneck. Doubling N to 600
    # tightens the hierarchical-scale posterior enough that cross-impl rhat
    # falls under 1.01 within the unified 20k+20k budget.
    n_groups    <- 6L
    n_scenarios <- 8L
    N           <- 600L
    group_id    <- sample.int(n_groups,    N, replace = TRUE)
    scenario_id <- sample.int(n_scenarios, N, replace = TRUE)
    mu_a    <- rnorm(1, 0, 1)
    mu_b    <- rnorm(1, 0, 1)
    sigma_a <- runif(1, 0.5, 2)
    sigma_b <- runif(1, 0.5, 2)
    sigma_y <- runif(1, 0.5, 2)
    a <- rnorm(n_groups,    10 * mu_a, sigma_a)
    b <- rnorm(n_scenarios, 10 * mu_b, sigma_b)
    y_hat <- a[group_id] + b[scenario_id]
    y     <- rnorm(N, y_hat, sigma_y)
    list(
        data = list(
            N           = N,
            n_groups    = n_groups,
            n_scenarios = n_scenarios,
            group_id    = as.integer(group_id),
            scenario_id = as.integer(scenario_id),
            y           = y),
        truth = list(
            mu_a    = mu_a,
            mu_b    = mu_b,
            a       = a,
            b       = b,
            sigma_a = sigma_a,
            sigma_b = sigma_b,
            sigma_y = sigma_y))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("pilots.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
