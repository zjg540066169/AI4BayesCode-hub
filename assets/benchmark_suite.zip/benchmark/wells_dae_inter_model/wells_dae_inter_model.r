# Data-generating process for the wells_dae_inter_model benchmark model.
# Extracted from sim1_wells_dae_inter_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N       <- 80L
    dist    <- runif(N, 0, 300)
    arsenic <- runif(N, 0, 10)
    educ    <- sample(0:20, N, replace = TRUE)
    alpha   <- rnorm(1, 0, 1)
    beta    <- rnorm(4, 0, 1)
    dist100   <- dist / 100
    educ4     <- educ / 4
    c_dist100 <- dist100 - mean(dist100)
    c_arsenic <- arsenic - mean(arsenic)
    eta <- alpha
    idx <- 1
    dvar <- c_dist100
    eta  <- eta + beta[idx] * dvar; idx <- idx + 1
    eta  <- eta + beta[idx] * c_arsenic; idx <- idx + 1
    eta  <- eta + beta[idx] * (c_dist100 * c_arsenic); idx <- idx + 1
    eta  <- eta + beta[idx] * educ4
    switched <- rbinom(N, 1, plogis(eta))

    # Map R DGP variables to the model-scale truth (see header note).
    mean_educ4   <- mean(educ) / 4
    alpha_model  <- alpha + beta[4] * mean_educ4
    beta_model   <- c(beta[1],   # c_dist100 main
                      beta[2],   # c_arsenic main
                      beta[4],   # c_educ4   main
                      beta[3],   # da_inter
                      0,         # de_inter (true 0)
                      0)         # ae_inter (true 0)

    list(
        data = list(
            N        = N,
            switched = as.integer(switched),
            dist     = dist,
            arsenic  = arsenic,
            educ     = as.numeric(educ)),
        truth = list(
            alpha = alpha_model,
            beta  = beta_model))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("wells_dae_inter_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
