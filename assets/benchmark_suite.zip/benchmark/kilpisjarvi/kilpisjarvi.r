# Data-generating process for the kilpisjarvi benchmark model.
# Extracted from sim1_kilpisjarvi.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 50L
X_FIXED <- as.numeric(scale(seq_len(N_DATA)))   # standardized predictor

# Effectively non-informative priors (matches runner)
PMUALPHA <- 0.0; PSALPHA <- 1e3
PMUBETA  <- 0.0; PSBETA  <- 1e3

simulate_data <- function(seed = 123) {
    set.seed(seed)
    alpha_true <- rnorm(1, 0, 2)
    beta_true  <- rnorm(1, 0, 1)
    sigma_true <- runif(1, 0.3, 1.5)
    y_obs <- alpha_true + beta_true * X_FIXED + rnorm(N_DATA, 0, sigma_true)

    list(
        data = list(
            N        = N_DATA,
            x        = X_FIXED,
            y        = y_obs,
            xpred    = 0.5,            # required by Stan data; unused in sampling
            pmualpha = PMUALPHA, psalpha = PSALPHA,
            pmubeta  = PMUBETA,  psbeta  = PSBETA
        ),
        truth = list(
            alpha = alpha_true,
            beta  = beta_true,
            sigma = sigma_true
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("kilpisjarvi.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
