# Data-generating process for the hmm_gaussian benchmark model.
# Extracted from sim1_hmm_gaussian.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

K_TRUE <- 2L
# Increased from 150 -> 300: with K=2 sticky transitions ~150 obs per
# state, sigma posterior is tight enough that AI's z-sampling FFBS path
# agrees with Stan's z-marginalized path on the sigma marginal at
# 20k+20k. With T=80-150 the posterior had heavy tails (flat improper
# prior) and cross-impl rhat on sigma spiked to 1.4+ on individual
# reps even though both samplers contained the truth (cov 1.00).
T_DATA <- 300L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    # Well-separated, ordered mus.
    mu_true    <- sort(c(rnorm(1, -2, 0.4), rnorm(1, 2, 0.4)))
    # Forced sigma separation (~1.5-2.5x ratio). Independent U(0.5, 1.0) drew
    # sigma_1 ~ sigma_2 in ~20% of seeds; with mu ordered but sigma unordered,
    # the posterior on (sigma_1, sigma_2) becomes bimodal across the diagonal
    # and Stan HMC blows up with thousands of divergent transitions. Drawing
    # sigma_1 < sigma_2 from disjoint sub-intervals removes the bimodality.
    sigma_true <- c(runif(1, 0.4, 0.6), runif(1, 0.85, 1.1))
    # Sticky transitions
    p11 <- runif(1, 0.7, 0.95); p22 <- runif(1, 0.7, 0.95)
    A_true <- matrix(c(p11, 1-p11, 1-p22, p22), 2, 2, byrow = TRUE)
    pi_true <- c(0.5, 0.5)

    z <- integer(T_DATA)
    z[1] <- sample.int(K_TRUE, 1L, prob = pi_true)
    for (t in 2:T_DATA) z[t] <- sample.int(K_TRUE, 1L, prob = A_true[z[t-1L], ])
    y_obs <- rnorm(T_DATA, mu_true[z], sigma_true[z])

    list(
        data = list(y = y_obs, T = T_DATA, K = K_TRUE),
        truth = list(
            pi    = matrix(pi_true,    nrow = 1L),
            A     = matrix(as.numeric(t(A_true)), nrow = 1L),  # row-major flatten
            mu    = matrix(mu_true,    nrow = 1L),
            sigma = matrix(sigma_true, nrow = 1L)
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("hmm_gaussian.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
