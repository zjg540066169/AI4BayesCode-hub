# Data-generating process for the GLM_Poisson_model benchmark model.
# Extracted from sim1_GLM_Poisson_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_OBS <- 20L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    year  <- seq(-1, 1, length.out = N_OBS)
    alpha <- runif(1, -3, 3)
    beta1 <- runif(1, -1, 1)
    beta2 <- runif(1, -1, 1)
    beta3 <- runif(1, -0.5, 0.5)
    log_lam <- alpha + beta1*year + beta2*year^2 + beta3*year^3
    C <- rpois(N_OBS, exp(log_lam))
    list(
        data  = list(n = N_OBS, C = as.integer(C), year = year),
        truth = list(alpha = alpha,
                     beta1 = matrix(beta1, nrow = 1L),
                     beta2 = matrix(beta2, nrow = 1L),
                     beta3 = matrix(beta3, nrow = 1L))
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("GLM_Poisson_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
