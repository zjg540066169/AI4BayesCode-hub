# Data-generating process for the ldaK2 benchmark model.
# Extracted from sim1_ldaK2.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

K_TRUE <- 2L
M_TRUE <- 8L
V_TRUE <- 12L
MEAN_N <- 15L
VH     <- V_TRUE %/% 2L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    phi_true <- matrix(0, K_TRUE, V_TRUE)
    phi_true[1, 1:VH]            <- 0.85 / VH
    phi_true[1, (VH + 1L):V_TRUE] <- 0.15 / (V_TRUE - VH)
    phi_true[2, 1:VH]            <- 0.15 / VH
    phi_true[2, (VH + 1L):V_TRUE] <- 0.85 / (V_TRUE - VH)
    theta_true <- matrix(0, M_TRUE, K_TRUE)
    for (m in seq_len(M_TRUE)) {
        theta_true[m, ] <- if (m %% 2L == 1L) c(0.8, 0.2) else c(0.2, 0.8)
    }
    doc <- integer(0); w <- integer(0)
    for (m in seq_len(M_TRUE)) {
        n_m <- max(5L, rpois(1L, MEAN_N))
        zs  <- sample.int(K_TRUE, size = n_m, replace = TRUE, prob = theta_true[m, ])
        for (i in seq_len(n_m)) {
            wv <- sample.int(V_TRUE, size = 1L, prob = phi_true[zs[i], ])
            doc <- c(doc, m); w <- c(w, wv)
        }
    }
    list(
        data = list(
            w_dbl = as.numeric(w), w_int = as.integer(w),
            doc_dbl = as.numeric(doc), doc_int = as.integer(doc),
            M = M_TRUE, V = V_TRUE, N = length(w)),
        truth = list(theta = theta_true, phi = phi_true)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("ldaK2.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
