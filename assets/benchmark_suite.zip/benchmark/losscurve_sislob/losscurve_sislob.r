# Data-generating process for the losscurve_sislob benchmark model.
# Extracted from sim1_losscurve_sislob.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    growthmodel_id <- sample(0:1, 1)
    n_time   <- 8L
    n_cohort <- 5L
    t_value  <- seq(1, 8, length.out = n_time)
    cohort_maxtime <- sample(4:8, n_cohort, replace = TRUE)
    premium  <- rgamma(n_cohort, 10, 1)
    omega    <- rlnorm(1, 0, 0.5)
    theta    <- rlnorm(1, 0, 0.5)
    mu_LR    <- rnorm(1, 0, 0.5)
    sd_LR    <- rlnorm(1, 0, 0.5)
    LR       <- rlnorm(n_cohort, mu_LR, sd_LR)
    loss_sd  <- rlnorm(1, 0, 0.7)
    gf <- numeric(n_time)
    for (i in seq_len(n_time)) {
        gf[i] <- if (growthmodel_id == 1L) 1 - exp(-(t_value[i] / theta)^omega)
                 else (t_value[i]^omega) / (t_value[i]^omega + theta^omega)
    }
    cohort_id <- integer(); t_idx <- integer(); loss <- numeric()
    for (c in seq_len(n_cohort)) {
        for (tt in seq_len(cohort_maxtime[c])) {
            cohort_id <- c(cohort_id, c)
            t_idx     <- c(t_idx, tt)
            mu_loss   <- LR[c] * premium[c] * gf[tt]
            loss      <- c(loss, rnorm(1, mu_loss, loss_sd * premium[c]))
        }
    }
    n_data <- length(loss)
    t_per_obs <- t_value[t_idx]
    list(
        data = list(growthmodel_id = as.integer(growthmodel_id),
                    n_data = n_data, n_time = n_time, n_cohort = n_cohort,
                    cohort_id = as.integer(cohort_id),
                    cohort_0idx = as.numeric(cohort_id - 1L),
                    t_idx = as.integer(t_idx), t_value = t_value, t_per_obs = t_per_obs,
                    cohort_maxtime = as.integer(cohort_maxtime),
                    premium = premium, loss = loss),
        truth = list(omega = omega, theta = theta, mu_LR = mu_LR, sd_LR = sd_LR,
                     loss_sd = loss_sd, LR = matrix(LR, nrow = 1L))
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("losscurve_sislob.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
