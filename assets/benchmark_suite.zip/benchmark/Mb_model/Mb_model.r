# Data-generating process for the Mb_model benchmark model.
# Extracted from sim1_Mb_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

T_TRUE <- 5L
N_TRUE <- 50L  # true population
M_AUG  <- 100L # augmented size

simulate_data <- function(seed = 123) {
    set.seed(seed)
    p_true     <- runif(1, 0.20, 0.45)   # capture prob (no prior capture)
    c_true     <- runif(1, 0.50, 0.85)   # recapture prob (after prior capture)
    omega_true <- N_TRUE / M_AUG

    # Generate true capture histories with behavioral effect
    y_true <- matrix(0L, N_TRUE, T_TRUE)
    for (i in seq_len(N_TRUE)) {
        y_true[i, 1] <- rbinom(1L, 1L, p_true)
        for (t in 2:T_TRUE) {
            pp <- if (y_true[i, t-1] == 0L) p_true else c_true
            y_true[i, t] <- rbinom(1L, 1L, pp)
        }
    }
    obs_idx <- which(rowSums(y_true) > 0)
    C <- length(obs_idx)
    y_full <- matrix(0L, M_AUG, T_TRUE)
    y_full[seq_len(C), ] <- y_true[obs_idx, , drop = FALSE]

    list(
        data = list(M = M_AUG, T = T_TRUE, y = y_full),
        truth = list(omega = omega_true, p = p_true, c = c_true)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("Mb_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
