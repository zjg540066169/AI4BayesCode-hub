# Data-generating process for the eight_schools_centered benchmark model.
# Extracted from sim1_eight_schools_centered.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

J_DATA <- 8L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    sigma_obs    <- runif(J_DATA, 5, 15)
    mu           <- rnorm(1, 0, 5)
    tau          <- abs(rcauchy(1, 0, 5))
    theta_trans  <- rnorm(J_DATA, 0, 1)
    theta        <- theta_trans * tau + mu
    y            <- rnorm(J_DATA, theta, sigma_obs)
    list(
        data  = list(J = J_DATA, y = y, sigma_obs = sigma_obs),
        truth = list(theta = matrix(theta, nrow = 1L), mu = mu, tau = tau)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("eight_schools_centered.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
