# Data-generating process for the accel_splines benchmark model.
# Extracted from sim1_accel_splines.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_OBS        <- 40L
KS           <- 2L    # number of linear predictors (mean)
KNOTS_1      <- 6L    # spline knots (mean)
KS_SIGMA     <- 2L    # number of linear predictors (log-sigma)
KNOTS_SIG    <- 6L    # spline knots (log-sigma)

simulate_data <- function(seed = 123) {
    set.seed(seed)
    Xs          <- matrix(rnorm(N_OBS * KS),       N_OBS, KS)
    Zs_1_1      <- matrix(rnorm(N_OBS * KNOTS_1),  N_OBS, KNOTS_1)
    Xs_sigma    <- matrix(rnorm(N_OBS * KS_SIGMA), N_OBS, KS_SIGMA)
    Zs_sig_1_1  <- matrix(rnorm(N_OBS * KNOTS_SIG),N_OBS, KNOTS_SIG)

    # Benign DGP: brms's heavy-tailed Student_t prior on Intercept (and
    # on sds_*) occasionally blows up Y by ~1e26 via exp(sigma_lin),
    # which makes Stan / AI both fail. Use moderate Normal draws so Y
    # stays in single-digit scale and Stan + AI fit cleanly.
    Intercept_true       <- rnorm(1, 0,    2)
    bs_true              <- rnorm(KS, 0, 0.3)
    zs_1_1_true          <- rnorm(KNOTS_1)
    sds_1_1_true         <- abs(rnorm(1, 0, 1.0))
    Intercept_sigma_true <- rnorm(1, 0,    0.5)
    bs_sigma_true        <- rnorm(KS_SIGMA, 0, 0.2)
    zs_sig_1_1_true      <- rnorm(KNOTS_SIG)
    sds_sig_1_1_true     <- abs(rnorm(1, 0, 0.5))

    mu    <- Intercept_true + Xs %*% bs_true +
             sds_1_1_true * (Zs_1_1 %*% zs_1_1_true)
    log_s <- Intercept_sigma_true + Xs_sigma %*% bs_sigma_true +
             sds_sig_1_1_true * (Zs_sig_1_1 %*% zs_sig_1_1_true)
    Y <- rnorm(N_OBS, as.numeric(mu), exp(as.numeric(log_s)))

    list(
        data = list(
            N = N_OBS, Y = Y,
            Ks = KS, Xs = Xs, knots_1 = KNOTS_1, Zs_1_1 = Zs_1_1,
            Ks_sigma = KS_SIGMA, Xs_sigma = Xs_sigma,
            knots_sigma_1 = KNOTS_SIG, Zs_sigma_1_1 = Zs_sig_1_1,
            prior_only = 0L
        ),
        truth = list(
            Intercept       = Intercept_true,
            bs              = matrix(bs_true,          nrow = 1L),
            zs_1_1          = matrix(zs_1_1_true,       nrow = 1L),
            sds_1_1         = sds_1_1_true,
            Intercept_sigma = Intercept_sigma_true,
            bs_sigma        = matrix(bs_sigma_true,     nrow = 1L),
            zs_sigma_1_1    = matrix(zs_sig_1_1_true,   nrow = 1L),
            sds_sigma_1_1   = sds_sig_1_1_true
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("accel_splines.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
