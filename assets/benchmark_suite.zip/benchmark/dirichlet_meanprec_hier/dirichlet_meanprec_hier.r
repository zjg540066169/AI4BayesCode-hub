# Toy data-generating process for the companion hierarchical Dirichlet
# mean-precision model. Returns a data list whose names match what the
# benchmark / model expect:
#   n, P, y (n x P matrix of observed compositions),
#   plus the planted truth (k_true, alpha_true, kappa_true) for scoring.
#
# DGP setup: under the total-concentration parameterization, the shared
# mean k_true is drawn once from a symmetric Dirichlet(kappa_true/P, ...,
# kappa_true/P), so kappa_true is the TOTAL Dirichlet concentration of
# the prior on k. Each row y_i is then drawn from Dirichlet(alpha_true * k_true).
#
# Numerical hygiene (mirrors AI4BayesCode/examples/run_dirichlet_hier.R):
#   * rdirichlet floors gamma draws at 1e-300 so the normalised output is
#     never exactly zero (avoids log(0) downstream in Stan / cpp).
#   * k_true is floored at 1e-6 and renormalised before generating y;
#     this keeps alpha_true * k_true above rgamma's effective precision
#     under sparse priors (small kappa_true/P at large P).

simulate_data <- function(seed = 2026,
                          args = list(n = NULL, P = NULL,
                                      alpha_true = NULL, kappa_true = NULL,
                                      k_true = NULL)) {
  set.seed(seed)
  get_arg <- function(name, default) if (!is.null(args[[name]])) args[[name]] else default

  n          <- get_arg("n", 150L)
  P          <- get_arg("P", 20L)
  alpha_true <- get_arg("alpha_true", 30)
  kappa_true <- get_arg("kappa_true", 4)

  # Robust Dirichlet sampler — floors underflowed gamma draws so the
  # normalised output (and its log) stays finite.
  rdirichlet <- function(n_draw, gamma) {
    G <- matrix(rgamma(n_draw * length(gamma), shape = gamma, rate = 1),
                nrow = n_draw, byrow = TRUE)
    G[G < 1e-300] <- 1e-300
    G / rowSums(G)
  }

  # shared mean composition: one draw from symmetric Dirichlet(kappa_true/P, ...)
  k_true <- get_arg("k_true", as.numeric(rdirichlet(1L, rep(kappa_true / P, P))))
  k_true <- pmax(k_true, 1e-6)
  k_true <- k_true / sum(k_true)
  stopifnot(length(k_true) == P, abs(sum(k_true) - 1) < 1e-8, all(k_true > 0))

  # observed compositions: y_i ~ Dirichlet(alpha_true * k_true)
  y <- rdirichlet(n, alpha_true * k_true)

  list(
    n          = n,
    P          = P,
    y          = y,
    # planted truth (for scoring; not seen by the model):
    k_true     = k_true,
    alpha_true = alpha_true,
    kappa_true = kappa_true
  )
}

# Example usage:
sim <- simulate_data(seed = 2026)
str(sim, max.level = 1)
cat(sprintf("[dgp-check] colMeans(y) = %s\n",
            paste(sprintf("%.3f", colMeans(sim$y)), collapse = ", ")))
cat(sprintf("[dgp-check] k_true      = %s\n",
            paste(sprintf("%.3f", sim$k_true), collapse = ", ")))

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("dirichlet_meanprec_hier.stan")
# fit <- mod$sample(data = list(n = sim$n, P = sim$P, y = sim$y,
#                               a = 2, b = 5),
#                   seed = 2026, chains = 2,
#                   iter_warmup = 1000, iter_sampling = 5000)
# print(fit$summary())
