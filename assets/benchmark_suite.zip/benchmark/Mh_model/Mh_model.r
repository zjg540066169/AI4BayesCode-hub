# Data-generating process for the Mh_model benchmark model.
# Extracted from sim1_Mh_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

T_TRUE <- 5L
N_TRUE <- 20L  # true population
M_AUG  <- 40L  # augmented size — eps_raw is M-dim NUTS, dominant cost

simulate_data <- function(seed = 123) {
    set.seed(seed)
    omega_true  <- N_TRUE / M_AUG
    mean_p_true <- runif(1, 0.25, 0.50)
    sigma_true  <- runif(1, 0.5, 1.5)
    eps_t       <- rnorm(N_TRUE, 0, sigma_true)
    p_i         <- 1 / (1 + exp(-(log(mean_p_true / (1 - mean_p_true)) + eps_t)))

    y_true_full <- matrix(0L, N_TRUE, T_TRUE)
    for (i in seq_len(N_TRUE)) y_true_full[i, ] <- rbinom(T_TRUE, 1L, p_i[i])
    obs_idx <- which(rowSums(y_true_full) > 0)
    C <- length(obs_idx)
    y_mat <- matrix(0L, M_AUG, T_TRUE)
    y_mat[seq_len(C), ] <- y_true_full[obs_idx, , drop = FALSE]
    y_count <- rowSums(y_mat)

    list(
        data = list(M = M_AUG, T = T_TRUE, y_mat = y_mat, y_count = y_count),
        truth = list(omega = omega_true, mean_p = mean_p_true, sigma = sigma_true)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("Mh_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
