# Data-generating process for the kidscore_interaction_c benchmark model.
# Extracted from sim1_kidscore_interaction_c.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 50L
P_DIM  <- 4L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    mom_hs <- rbinom(N_DATA, 1L, 0.7)
    mom_iq <- pmin(pmax(rnorm(N_DATA, 100, 15), 50), 195)
    c_mom_hs <- mom_hs - mean(mom_hs)
    c_mom_iq <- mom_iq - mean(mom_iq)
    inter    <- c_mom_hs * c_mom_iq
    beta1_true <- runif(1, 80, 95)
    beta2_true <- runif(1, 1, 6)
    beta3_true <- runif(1, 0.3, 0.7)
    beta4_true <- runif(1, -0.4, -0.05)
    sigma_true <- runif(1, 15, 22)
    mu <- beta1_true + beta2_true * c_mom_hs + beta3_true * c_mom_iq + beta4_true * inter
    kid_score <- mu + rnorm(N_DATA, 0, sigma_true)
    X <- cbind(1, c_mom_hs, c_mom_iq, inter)
    list(
        data = list(N = N_DATA, kid_score = kid_score, mom_iq = mom_iq,
                    mom_hs = as.numeric(mom_hs), X = X, y = kid_score),
        truth = list(beta = matrix(c(beta1_true, beta2_true, beta3_true, beta4_true), nrow = 1L),
                     sigma = sigma_true)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("kidscore_interaction_c.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
