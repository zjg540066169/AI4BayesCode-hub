# Data-generating process for the prophet benchmark model.
# Extracted from sim1_prophet.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    T_n   <- 60L
    K     <- 3L
    t     <- seq(0, 1, length.out = T_n)
    cap   <- rep(10, T_n)
    S     <- 5L
    t_change <- seq(0.15, 0.75, length.out = S)
    X      <- matrix(rnorm(T_n * K), nrow = T_n, ncol = K)
    sigmas <- rep(1, K)
    tau    <- 0.2
    trend_indicator <- sample(0:1, 1)
    s_a <- c(1, 0, 1)
    s_m <- c(0, 1, 0)
    k_v <- rnorm(1, 0, 5)
    m_v <- rnorm(1, 0, 5)
    rlaplace <- function(n, location = 0, scale = 1) {
        location + rexp(n, 1 / scale) * sample(c(-1, 1), n, replace = TRUE)
    }
    delta     <- rlaplace(S, 0, tau)
    sigma_obs <- abs(rnorm(1, 0, 0.5))
    beta      <- rnorm(K, 0, sigmas)
    A <- matrix(0, nrow = T_n, ncol = S)
    cp_idx <- 1L
    a_row  <- rep(0, S)
    for (i in seq_len(T_n)) {
        while (cp_idx <= S && t[i] >= t_change[cp_idx]) {
            a_row[cp_idx] <- 1
            cp_idx <- cp_idx + 1L
        }
        A[i, ] <- a_row
    }
    if (trend_indicator == 0L) {
        trend <- (k_v + A %*% delta) * t + (m_v + A %*% (-t_change * delta))
    } else {
        k_s   <- c(k_v, k_v + cumsum(delta))
        gamma <- numeric(S)
        m_pr  <- m_v
        for (i in seq_len(S)) {
            gamma[i] <- (t_change[i] - m_pr) * (1 - k_s[i] / k_s[i + 1L])
            m_pr     <- m_pr + gamma[i]
        }
        trend <- cap * plogis((k_v + A %*% delta) * (t - (m_v + A %*% gamma)))
    }
    mu <- as.numeric(trend) * (1 + X %*% (beta * s_m)) + X %*% (beta * s_a)
    y  <- rnorm(T_n, mu, sigma_obs)

    list(
        data = list(
            T              = T_n,
            K              = K,
            t              = t,
            cap            = cap,
            y              = y,
            S              = S,
            t_change       = t_change,
            X              = X,
            sigmas         = sigmas,
            tau            = tau,
            trend_indicator = as.integer(trend_indicator),
            s_a            = s_a,
            s_m            = s_m),
        truth = list(
            k         = k_v,
            m         = m_v,
            delta     = delta,
            beta      = beta,
            sigma_obs = sigma_obs))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("prophet.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
