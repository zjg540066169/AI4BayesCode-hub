# Data-generating process for the logmesquite_logvolume benchmark model.
# Extracted from sim1_logmesquite_logvolume.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 50L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    diam1         <- runif(N_DATA, 0.3, 2.5)
    diam2         <- runif(N_DATA, 0.3, 2.5)
    canopy_height <- runif(N_DATA, 0.5, 3.0)
    log_canopy_volume <- log(diam1 * diam2 * canopy_height)

    beta1_true <- runif(1, 4.0, 8.0)
    beta2_true <- runif(1, 0.7, 1.3)            # log-log canopy volume slope ~ 1
    sigma_true <- runif(1, 0.20, 0.60)
    log_weight <- beta1_true + beta2_true * log_canopy_volume +
                  rnorm(N_DATA, 0, sigma_true)
    weight <- exp(log_weight)

    list(
        data = list(
            N                 = N_DATA,
            weight            = weight,
            diam1             = diam1,
            diam2             = diam2,
            canopy_height     = canopy_height,
            log_weight        = log_weight,        # AI
            log_canopy_volume = log_canopy_volume  # AI
        ),
        truth = list(
            beta  = matrix(c(beta1_true, beta2_true), nrow = 1L),
            sigma = sigma_true
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("logmesquite_logvolume.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
