# Data-generating process for the normal_mixture_k benchmark model.
# Extracted from sim1_normal_mixture_k.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

K_TRUE <- 3L
N_DATA <- 200L

# Small helper: Dirichlet draw via independent Gammas
rdirichlet1 <- function(alpha) {
    g <- rgamma(length(alpha), shape = alpha, rate = 1)
    g / sum(g)
}

simulate_data <- function(seed = 123) {
    set.seed(seed)

    # mu_true: well-separated centers around -3, 0, 3 with mild jitter, then sorted
    mu_raw    <- c(rnorm(1, -3.0, 0.4),
                   rnorm(1,  0.0, 0.4),
                   rnorm(1,  3.0, 0.4))
    sigma_raw <- runif(K_TRUE, 0.5, 1.5)
    theta_raw <- rdirichlet1(rep(2.0, K_TRUE))      # avoids near-zero weights

    # Apply same permutation to all so mu is ordered (matches AI convention)
    ord <- order(mu_raw)
    mu_true    <- mu_raw[ord]
    sigma_true <- sigma_raw[ord]
    theta_true <- theta_raw[ord]

    z_true <- sample(seq_len(K_TRUE), N_DATA, replace = TRUE, prob = theta_true)
    y_obs  <- rnorm(N_DATA, mean = mu_true[z_true], sd = sigma_true[z_true])

    list(
        data = list(
            y     = y_obs,
            K     = K_TRUE,
            N     = N_DATA
        ),
        truth = list(
            mu    = matrix(mu_true,    nrow = 1L),
            sigma = matrix(sigma_true, nrow = 1L),
            theta = matrix(theta_true, nrow = 1L)
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("normal_mixture_k.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
