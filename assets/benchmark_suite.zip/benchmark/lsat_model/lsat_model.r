# Data-generating process for the lsat_model benchmark model.
# Extracted from sim1_lsat_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_TRUE <- 80L
T_TRUE <- 5L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    alpha_true <- rnorm(T_TRUE, 0, 1.5)
    theta_orig <- rnorm(N_TRUE, 0, 1)
    beta_true  <- runif(1, 0.5, 1.2)

    # Generate r_orig (N x T)
    r_orig <- matrix(0L, N_TRUE, T_TRUE)
    for (j in seq_len(N_TRUE)) {
        eta <- beta_true * theta_orig[j] - alpha_true
        r_orig[j, ] <- rbinom(T_TRUE, 1L, 1 / (1 + exp(-eta)))
    }

    # Sort rows by response pattern so identical patterns are contiguous.
    # AI's row j and Stan's internal student j will then both correspond
    # to original student perm[j].
    pattern_keys <- apply(r_orig, 1L, paste, collapse = "")
    perm <- order(pattern_keys)
    r_sorted    <- r_orig[perm, , drop = FALSE]
    theta_true  <- theta_orig[perm]
    keys_sorted <- pattern_keys[perm]

    # Build grouped data for Stan
    rle_pat <- rle(keys_sorted)
    R_count <- length(rle_pat$values)
    culm    <- as.integer(cumsum(rle_pat$lengths))
    # response[i, ] = T-vec binary pattern for group i
    response_mat <- t(sapply(rle_pat$values, function(s)
        as.integer(strsplit(s, "")[[1]])))
    if (R_count == 1L) response_mat <- matrix(response_mat, nrow = 1L)

    list(
        data = list(
            r_AI     = r_sorted,                 # N x T (numeric, AI takes NumericMatrix)
            N        = N_TRUE,
            T_n      = T_TRUE,
            R        = R_count,
            culm     = culm,
            response = response_mat
        ),
        truth = list(
            alpha = matrix(alpha_true, nrow = 1L),
            theta = matrix(theta_true, nrow = 1L),
            beta  = beta_true
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("lsat_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
