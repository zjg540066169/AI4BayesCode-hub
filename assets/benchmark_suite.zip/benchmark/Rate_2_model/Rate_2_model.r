# Data-generating process for the Rate_2_model benchmark model.
# Extracted from sim1_Rate_2_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    n1     <- 30L
    n2     <- 35L
    theta1 <- rbeta(1, 1, 1)
    theta2 <- rbeta(1, 1, 1)
    k1     <- rbinom(1L, size = n1, prob = theta1)
    k2     <- rbinom(1L, size = n2, prob = theta2)
    list(
        data  = list(n1 = n1, n2 = n2, k1 = as.integer(k1), k2 = as.integer(k2)),
        truth = list(theta1 = theta1, theta2 = theta2)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("Rate_2_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
