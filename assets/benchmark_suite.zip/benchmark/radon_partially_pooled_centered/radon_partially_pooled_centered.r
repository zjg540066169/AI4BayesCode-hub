# Data-generating process for the radon_partially_pooled_centered benchmark model.
# Extracted from sim1_radon_partially_pooled_centered.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 80L; J <- 12L
    county_idx <- sample.int(J, N, replace = TRUE)
    mu_alpha    <- rnorm(1, 0, 10)
    sigma_alpha <- abs(rnorm(1, 0, 1))
    sigma_y     <- abs(rnorm(1, 0, 1))
    alpha       <- rnorm(J, mu_alpha, sigma_alpha)
    log_radon   <- rnorm(N, alpha[county_idx], sigma_y)
    list(
        data = list(N = N, J = J, county_idx = as.integer(county_idx), log_radon = log_radon),
        truth = list(alpha = matrix(alpha, nrow = 1L),
                     mu_alpha = mu_alpha, sigma_alpha = sigma_alpha, sigma_y = sigma_y)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("radon_partially_pooled_centered.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
