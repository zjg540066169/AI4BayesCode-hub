# Data-generating process for the irt_2pl benchmark model.
# Extracted from sim1_irt_2pl.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

I_TRUE <- 8L
J_TRUE <- 30L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    sigma_theta_true <- runif(1, 0.6, 1.4)
    sigma_a_true     <- runif(1, 0.3, 0.7)
    mu_b_true        <- runif(1, -0.5, 0.5)
    sigma_b_true     <- runif(1, 0.5, 1.0)

    theta_true <- rnorm(J_TRUE, 0, sigma_theta_true)
    a_true     <- exp(rnorm(I_TRUE, 0, sigma_a_true))
    b_true     <- rnorm(I_TRUE, mu_b_true, sigma_b_true)

    Y <- matrix(0L, I_TRUE, J_TRUE)
    for (i in seq_len(I_TRUE)) {
        eta <- a_true[i] * (theta_true - b_true[i])
        Y[i, ] <- rbinom(J_TRUE, 1L, 1 / (1 + exp(-eta)))
    }

    list(
        data = list(Y = Y, I = I_TRUE, J = J_TRUE),
        truth = list(
            theta       = matrix(theta_true,           nrow = 1L),
            a           = matrix(a_true,               nrow = 1L),
            b           = matrix(b_true,               nrow = 1L),
            mu_b        = mu_b_true,
            sigma_theta = sigma_theta_true,
            sigma_a     = sigma_a_true,
            sigma_b     = sigma_b_true
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("irt_2pl.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
