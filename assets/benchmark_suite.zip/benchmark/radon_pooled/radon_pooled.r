# Data-generating process for the radon_pooled benchmark model.
# Extracted from sim1_radon_pooled.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 80L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    alpha_t <- rnorm(1, 0, 1.5)
    beta_t  <- rnorm(1, 0, 0.6)
    sigma_t <- runif(1, 0.4, 1.0)
    floor_measure <- rbinom(N_DATA, 1L, 0.4)
    log_radon <- alpha_t + beta_t * floor_measure + rnorm(N_DATA, 0, sigma_t)
    list(
        data = list(N = N_DATA, log_radon = log_radon, floor_measure = as.numeric(floor_measure)),
        truth = list(alpha = alpha_t, beta = beta_t, sigma_y = sigma_t)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("radon_pooled.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
