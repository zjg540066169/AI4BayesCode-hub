# Data-generating process for the two_normal_spike_slab_model benchmark model.
# Extracted from sim1_two_normal_spike_slab_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_OBS         <- 100L
P             <- 10L
SIGMA_SPIKE   <- 0.05
SIGMA_SLAB    <- 2.0

simulate_data <- function(seed = 123) {
    set.seed(seed)
    X <- matrix(rnorm(N_OBS * P), nrow = N_OBS, ncol = P)
    X <- scale(X, center = TRUE, scale = TRUE)

    # Benign truth values (avoid extreme tails that would blow up y).
    pi_true    <- rbeta(1, 2, 2)                       # centered ~ 0.5
    sigma_true <- exp(rnorm(1, 0, 0.5))                # ~lognormal around 1
    gamma_true <- rbinom(P, 1L, pi_true)
    # Reject all-zero gamma to keep beta identifiable through likelihood
    # (otherwise y has no signal and pi posterior collapses to 0).
    for (.i in seq_len(50L)) {
        if (sum(gamma_true) >= 1L) break
        gamma_true <- rbinom(P, 1L, pi_true)
    }
    if (sum(gamma_true) < 1L) gamma_true[sample(P, 1L)] <- 1L
    beta_true <- numeric(P)
    for (j in seq_len(P)) {
        if (gamma_true[j] == 0L)
            beta_true[j] <- rnorm(1, 0, SIGMA_SPIKE)
        else
            beta_true[j] <- rnorm(1, 0, SIGMA_SLAB)
    }
    y <- as.numeric(X %*% beta_true + rnorm(N_OBS, 0, sigma_true))

    list(
        data = list(N = N_OBS, p = P, X = X, y = y,
                    sigma_spike = SIGMA_SPIKE, sigma_slab = SIGMA_SLAB),
        truth = list(
            pi    = pi_true,
            sigma = sigma_true,
            beta  = matrix(beta_true,  nrow = 1L),
            gamma = matrix(gamma_true, nrow = 1L)))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("two_normal_spike_slab_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
