# Data-generating process for the kronecker_gp benchmark model.
# Extracted from sim1_kronecker_gp.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    n1     <- 4L
    n2     <- 4L
    x1     <- seq(0, 1, length.out = n2)   # follows .r (uses n2 length)
    var1   <- rlnorm(1, 0, 1)
    bw1    <- abs(rcauchy(1, 0, 2.5))
    sigma1 <- rlnorm(1, 0, 1)
    xd     <- outer(x1, x1, function(a, b) -((a - b)^2))
    Sigma1 <- var1 * exp(xd * bw1)
    diag(Sigma1) <- diag(Sigma1) + 1e-5
    A      <- matrix(rnorm(n2 * n2), nrow = n2)
    Lambda <- cov(A) + diag(0.1, n2)
    L1     <- chol(Sigma1)
    L2     <- chol(Lambda)
    Z      <- matrix(rnorm(n2 * n1), nrow = n2, ncol = n1)
    y      <- L2 %*% Z %*% t(L1) +
              matrix(rnorm(n2 * n1, 0, sigma1), nrow = n2)
    list(
        data = list(
            n1 = n1,
            n2 = n2,
            x1 = x1,
            y  = y),                       # n2 x n1 matrix
        truth = list(
            var1   = var1,
            bw1    = bw1,
            sigma1 = sigma1))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("kronecker_gp.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
