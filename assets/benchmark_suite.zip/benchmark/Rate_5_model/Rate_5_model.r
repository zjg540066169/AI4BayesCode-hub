# Data-generating process for the Rate_5_model benchmark model.
# Extracted from sim1_Rate_5_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    n1    <- 30L
    n2    <- 35L
    theta <- rbeta(1, 1, 1)
    k1    <- rbinom(1L, size = n1, prob = theta)
    k2    <- rbinom(1L, size = n2, prob = theta)
    list(
        data  = list(n1 = n1, n2 = n2, k1 = as.integer(k1), k2 = as.integer(k2)),
        truth = list(theta = theta)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("Rate_5_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
