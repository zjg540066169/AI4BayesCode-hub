# Data-generating process for the Survey_model benchmark model.
# Extracted from sim1_Survey_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    nmax <- 30L; m <- 20L
    theta <- runif(1)
    n_true <- sample(max(1L, ceiling(nmax / 3)):nmax, 1)
    k <- rbinom(m, n_true, theta)
    list(
        data = list(nmax = nmax, m = m, k = as.integer(k)),
        truth = list(theta = theta)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("Survey_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
