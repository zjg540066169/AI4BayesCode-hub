// 3-state Poisson HMM — Stan benchmark for exp4 (pois_hmm_k3_0).
//
// Stan cannot sample the discrete latent states z_t directly, so they are
// MARGINALISED OUT analytically with the forward algorithm (log space). This is
// exact: target += log_sum_exp(logalpha[T]) is the exact marginal likelihood
// p(y | lambda, A, pi). HMC then samples only the continuous parameters.
//
// Identifiability: states are labelled by ascending emission rate via
// positive_ordered[K] lambda, so pi[k] and A[j,k] inherit that ordering and the
// output needs NO post-hoc relabelling (unlike a free-permutation sampler). The
// reference's ordering is lambda_true = 2 < 8 < 25.
//
// The per-timepoint smoothed marginals P(z_t=k | y) and the Viterbi MAP path are
// deterministic functions of (lambda, A, pi); the benchmark recovers them in R
// by forward-backward on the posterior draws (kept out of generated quantities
// to keep the CSV small -- this environment's cmdstanr CSV reader pulls in
// data.table, whose shared library segfaults on load).
data {
  int<lower=1> K;                 // number of states (3)
  int<lower=1> T;                 // length of the count series
  array[T] int<lower=0> y;        // observed Poisson counts
  real<lower=0> lam_a;            // Gamma shape for the lambda prior
  real<lower=0> lam_b;            // Gamma rate  for the lambda prior
}
parameters {
  positive_ordered[K] lambda;     // ascending Poisson rates => identified
  simplex[K] pi;                  // initial-state distribution
  array[K] simplex[K] A;          // transition rows: A[j,k] = P(z_t=k | z_{t-1}=j)
}
model {
  // priors (matched to the hand-coded FFBS Gibbs reference)
  lambda ~ gamma(lam_a, lam_b);             // iid Gamma on the ordered rates
  pi ~ dirichlet(rep_vector(1.0, K));       // Dirichlet(1)
  for (j in 1 : K)
    A[j] ~ dirichlet(rep_vector(1.0, K));   // Dirichlet(1) per row

  // forward algorithm: exact marginal likelihood of the discrete chain
  {
    array[K] real acc;
    array[T, K] real logalpha;
    for (k in 1 : K)
      logalpha[1, k] = log(pi[k]) + poisson_lpmf(y[1] | lambda[k]);
    for (t in 2 : T) {
      for (k in 1 : K) {
        for (j in 1 : K)
          acc[j] = logalpha[t - 1, j] + log(A[j, k]);
        logalpha[t, k] = log_sum_exp(acc) + poisson_lpmf(y[t] | lambda[k]);
      }
    }
    target += log_sum_exp(logalpha[T]);
  }
}
