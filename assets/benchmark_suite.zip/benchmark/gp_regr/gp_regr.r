# Data-generating process for the gp_regr benchmark model.
# Extracted from sim1_gp_regr.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N      <- 30L
    x      <- sort(runif(N, -2, 2))
    rho    <- rgamma(1, shape = 25, rate = 4)
    alpha  <- abs(rnorm(1, 0, 2))
    d2     <- outer(x, x, function(a, b) (a - b)^2)
    K      <- alpha^2 * exp(-d2 / (2 * rho^2))
    diag(K) <- diag(K) + 1e-10
    L      <- chol(K)
    f_tilde <- rnorm(N)
    f      <- as.numeric(drop(t(L) %*% f_tilde))    # intermediate (unused)
    sigma  <- abs(rnorm(1, 0, 1))
    # Replace 1e-10 jitter with sigma nugget for the actual data draw.
    diag(K) <- diag(K) - 1e-10 + sigma
    L      <- chol(K)
    y      <- as.numeric(drop(t(L) %*% rnorm(N)))
    list(
        data = list(
            N = N,
            x = x,
            y = y,
            X = matrix(x, ncol = 1L)),
        truth = list(
            alpha = alpha,
            rho   = rho,
            sigma = sigma))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("gp_regr.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
