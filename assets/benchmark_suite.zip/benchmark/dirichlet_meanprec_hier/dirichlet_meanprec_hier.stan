// Hierarchical Dirichlet mean-precision model (Stan).
//
//   y_i | alpha, k    ~ Dirichlet(alpha * k)                i = 1..n
//   k   | kappa       ~ Dirichlet(kappa/P, ..., kappa/P)    (symmetric, P entries)
//   alpha             ~ Gamma(1, 1)
//   kappa/(kappa+P)   ~ Beta(a, b)                           (proper prior; non-conjugate)
//
// Notes
//   * The Beta prior is placed on u = kappa/(kappa+P), so the implied
//     density on kappa includes the change-of-variables Jacobian
//     |du/dkappa| = P/(kappa+P)^2, which we add via
//     `+ log(P) - 2*log(kappa + P)`. Stan's automatic +log(kappa) Jacobian
//     from the <lower=0> log-transform is added independently.
//   * y is declared as `array[n] vector[P]` (not `simplex[P]`) to avoid
//     strict sum-to-1 tolerance failures when y is passed in via JSON;
//     dirichlet_lpdf below validates positivity and effectively requires
//     normalisation up to the lpdf's own tolerance.
//   * Hyperparameters a, b are passed as data (defaults a=2, b=5).

data {
  int<lower=1> n;
  int<lower=2> P;
  array[n] vector<lower=0>[P] y;
  real<lower=0> a;
  real<lower=0> b;
}
parameters {
  simplex[P] k;
  real<lower=0> alpha;
  real<lower=0> kappa;
}
model {
  // Hyperpriors
  alpha ~ gamma(1, 1);
  // Beta(a, b) on u = kappa/(kappa+P), with Jacobian P/(kappa+P)^2.
  target += beta_lpdf(kappa / (kappa + P) | a, b)
            + log(P) - 2 * log(kappa + P);
  // Layer-1 prior on shared mean
  k ~ dirichlet(rep_vector(kappa / P, P));
  // Likelihood
  for (i in 1:n) {
    y[i] ~ dirichlet(alpha * k);
  }
}
