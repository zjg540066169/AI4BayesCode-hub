data {
  int<lower=0> N;
  array[N] int<lower=0, upper=1> switched;
  vector[N] dist;
}
transformed data {
  // rescaling
  vector[N] dist100 = dist / 100.0;
  matrix[N, 1] x = [dist100']';
}
parameters {
  real alpha;
  vector[1] beta;
}
model {
  alpha ~ normal(0, 1);
  beta ~ normal(0, 1);
  switched ~ bernoulli_logit_glm(x, alpha, beta);
}


