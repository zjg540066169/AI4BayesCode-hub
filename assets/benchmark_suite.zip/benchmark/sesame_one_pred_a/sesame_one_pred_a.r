# Data-generating process for the sesame_one_pred_a benchmark model.
# Extracted from sim1_sesame_one_pred_a.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 40L
    encouraged <- rnorm(N)
    beta <- rnorm(2, 0, 1)
    sigma <- abs(rnorm(1, 0, 1))
    watched <- rnorm(N, beta[1] + beta[2] * encouraged, sigma)
    list(
        data = list(N = N, encouraged = encouraged, watched = watched),
        truth = list(beta = matrix(beta, nrow = 1L), sigma = sigma)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("sesame_one_pred_a.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
