# Data-generating process for the radon_county benchmark model.
# Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data, for
#            coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 80L
    J <- 12L
    county  <- sample.int(J, N, replace = TRUE)
    mu_a    <- rnorm(1, 0, 1)
    sigma_a <- abs(rnorm(1, 0, 1))
    sigma_y <- abs(rnorm(1, 0, 1))
    a <- rnorm(J, mu_a, sigma_a)
    y <- rnorm(N, a[county], sigma_y)
    list(
        data = list(N = N, J = J, county = as.integer(county), y = y),
        truth = list(
            a       = matrix(a, nrow = 1L),
            mu_a    = mu_a,
            sigma_a = sigma_a,
            sigma_y = sigma_y
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("radon_county.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
