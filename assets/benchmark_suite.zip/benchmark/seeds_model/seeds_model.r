# Data-generating process for the seeds_model benchmark model.
# Extracted from sim1_seeds_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    # I bumped 21 -> 60 and alpha drawn from a narrow range so logit(p_i)
    # stays in (-5, 5) where the binomial likelihood is informative. Original
    # alpha ~ N(0, 1000) drove logit to +/- 2000 -> plogis = 0 or 1 -> data
    # is uninformative -> posterior dominated by N(0, 1000) prior with huge
    # variance. Both Stan and AI would have nominal posteriors but cross-impl
    # rhat would be unreliable. Truth alphas in (-1.5, 1.5) are well within
    # the prior's support and give p_i in [~0.05, ~0.95] for typical x1, x2.
    I <- 60L
    N <- rpois(I, lambda = 20) + 5L
    x1 <- sample(c(-0.5, 0.5), I, replace = TRUE)
    x2 <- sample(c(-0.5, 0.5), I, replace = TRUE)
    x1x2 <- x1 * x2
    alpha0  <- runif(1, -1.5, 1.5)
    alpha1  <- runif(1, -1.5, 1.5)
    alpha2  <- runif(1, -1.5, 1.5)
    alpha12 <- runif(1, -1.5, 1.5)
    sigma <- runif(1, 0.3, 0.8)   # within HalfNormal(0, 1) prior support
    tau   <- 1 / sigma^2
    b <- rnorm(I, 0, sigma)
    eta <- alpha0 + alpha1 * x1 + alpha2 * x2 + alpha12 * x1x2 + b
    n   <- rbinom(I, size = N, prob = plogis(eta))
    list(
        data = list(I = I, n = as.integer(n), N = as.integer(N), x1 = x1, x2 = x2),
        truth = list(alpha = matrix(c(alpha0, alpha1, alpha2, alpha12), nrow = 1L),
                     sigma = sigma, b = matrix(b, nrow = 1L))
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("seeds_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
