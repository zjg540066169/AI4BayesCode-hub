# Data-generating process for the dogs_hierarchical benchmark model.
# Extracted from sim1_dogs_hierarchical.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DOGS   <- 8L
N_TRIALS <- 12L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    a <- runif(1, 0, 1)
    b <- runif(1, 0, 1)
    y <- matrix(0L, nrow = N_DOGS, ncol = N_TRIALS)
    for (j in seq_len(N_DOGS)) {
        prev_shock <- 0; prev_avoid <- 0
        for (t in seq_len(N_TRIALS)) {
            p <- a^prev_shock * b^prev_avoid
            y[j, t] <- rbinom(1, 1, p)
            prev_shock <- prev_shock + y[j, t]
            prev_avoid <- prev_avoid + 1L - y[j, t]
        }
    }
    list(
        data  = list(n_dogs = N_DOGS, n_trials = N_TRIALS, y = y),
        truth = list(a = a, b = b)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("dogs_hierarchical.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
