# Data-generating process for the radon_variable_slope_noncentered benchmark model.
# Extracted from sim1_radon_variable_slope_noncentered.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 80L
J_TRUE <- 8L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    alpha_t       <- rnorm(1, 0, 1.5)
    mu_beta_t     <- rnorm(1, 0, 0.6)
    sigma_beta_t  <- abs(rnorm(1, 0, 0.4)) + 0.15
    sigma_y_t     <- runif(1, 0.4, 1.0)
    beta_t        <- rnorm(J_TRUE, mu_beta_t, sigma_beta_t)
    county_idx    <- sample.int(J_TRUE, N_DATA, replace = TRUE)
    floor_measure <- rbinom(N_DATA, 1L, 0.4)
    log_radon     <- alpha_t + beta_t[county_idx] * floor_measure +
                     rnorm(N_DATA, 0, sigma_y_t)
    list(
        data = list(N = N_DATA, J = J_TRUE,
                    log_radon = log_radon,
                    floor_measure = as.numeric(floor_measure),
                    county_idx = as.integer(county_idx)),
        truth = list(
            alpha       = alpha_t,
            beta        = matrix(beta_t, nrow = 1L),
            mu_beta     = mu_beta_t,
            sigma_beta  = sigma_beta_t,
            sigma_y     = sigma_y_t
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("radon_variable_slope_noncentered.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
