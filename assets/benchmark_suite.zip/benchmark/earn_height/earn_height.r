# Data-generating process for the earn_height benchmark model.
# Extracted from sim1_earn_height.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 80L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    height <- rnorm(N_DATA, 66, 4)
    sigma  <- runif(1, 0.1, 1)
    beta   <- rnorm(2, 0, 1)
    mu     <- beta[1] + beta[2] * height
    earn   <- rnorm(N_DATA, mu, sigma)
    list(
        data  = list(N = N_DATA, earn = earn, height = height),
        truth = list(beta = matrix(beta, nrow = 1L), sigma = sigma)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("earn_height.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
