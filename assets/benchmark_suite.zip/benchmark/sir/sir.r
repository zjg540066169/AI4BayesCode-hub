# Data-generating process for the sir benchmark model.
# Extracted from sim1_sir.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N_t <- 20L
    t   <- seq(0.5, 10, length.out = N_t)
    y0  <- c(1000, 10, 0, 5)
    # Benign DGP: prompt's half-Cauchy priors are heavy-tailed and
    # routinely produce extreme truth (beta > 50, xi > 100) that make
    # the ODE numerically stiff -> rk45 step size collapses to ~1e-9 ->
    # one posterior eval costs minutes -> a 20k+20k rep takes hours.
    # Bounded uniform draws keep the ODE well-conditioned so rk45 runs
    # at default tolerance and reps finish in minutes. truth values
    # still cover an epidemiologically reasonable region.
    beta  <- runif(1, 0.5, 2.0)
    gamma <- runif(1, 0.2, 1.0)
    xi    <- runif(1, 5,   25)
    delta <- runif(1, 0.2, 1.0)
    kappa <- 1000000
    y_state <- matrix(0, nrow = N_t, ncol = 4)
    state <- y0
    t_prev <- 0
    for (n in seq_len(N_t)) {
        dt <- t[n] - t_prev
        steps <- max(5L, ceiling(dt / 0.05))
        h <- dt / steps
        for (s in seq_len(steps)) {
            inf_rate <- beta * state[4] / (state[4] + kappa) * state[1]
            dydt <- c(-inf_rate, inf_rate - gamma * state[2], gamma * state[2], xi * state[2] - delta * state[4])
            # No pmax clamp: with bounded benign params the ODE stays
            # non-negative naturally. A clamp would inject DGP-vs-model
            # misspec (model fits un-clamped ODE).
            state <- state + h * dydt
        }
        y_state[n, ] <- state
        t_prev <- t[n]
    }
    stoi_hat <- integer(N_t)
    stoi_hat[1] <- rpois(1, max(y0[1] - y_state[1, 1], 1e-6))
    if (N_t > 1L) {
        for (n in 2:N_t) stoi_hat[n] <- rpois(1, max(y_state[n - 1L, 1] - y_state[n, 1], 1e-6))
    }
    B_hat <- rlnorm(N_t, log(y_state[, 4]), 0.15)
    list(
        data = list(N_t = N_t, t = t, y0 = y0,
                    stoi_hat = as.integer(stoi_hat), B_hat = B_hat,
                    kappa = kappa),
        truth = list(theta_phys = matrix(c(beta, gamma, xi, delta), nrow = 1L))
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("sir.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
