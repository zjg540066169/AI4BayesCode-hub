# Data-generating process for the wells_dae_model benchmark model.
# Extracted from sim1_wells_dae_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    # N bumped to 1000: regen cpp uses Polya-Gamma augmentation which is
    # numerically unstable at small N (chain gets stuck at extreme beta);
    # at N>=1000 the posterior is sharp enough for stable sampling.
    N <- 1000L
    dist <- runif(N, 0, 300); arsenic <- runif(N, 0, 10)
    educ <- sample(0:20, N, replace = TRUE)
    alpha <- rnorm(1, 0, 1)
    beta  <- rnorm(3, 0, 1)
    dist100 <- dist / 100; educ4 <- educ / 4
    eta <- alpha + beta[1]*dist100 + beta[2]*arsenic + beta[3]*educ4
    switched <- rbinom(N, 1, plogis(eta))
    # Regen cpp uses Polya-Gamma + augmented X (alpha as intercept column),
    # so X must be 4-col: [intercept, dist100, arsenic, educ4].
    X <- cbind(1, dist100, arsenic, educ4)
    list(
        data = list(N = N, switched = as.integer(switched),
                    dist = dist, arsenic = arsenic, educ = as.numeric(educ),
                    X = X, y = as.numeric(switched)),
        truth = list(alpha = alpha, beta = matrix(beta, nrow = 1L))
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("wells_dae_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
