# Data-generating process for the diamonds benchmark model.
# Extracted from sim1_diamonds.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_OBS <- 60L
K     <- 4L     # K predictors; Stan uses Kc = K-1 centered predictors

simulate_data <- function(seed = 123) {
    set.seed(seed)
    X <- cbind(1, matrix(rnorm(N_OBS * (K - 1L)), N_OBS, K - 1L))
    b_true         <- rnorm(K - 1L, 0, 0.5)
    Intercept_true <- 8 + rt(1, 3) * 2
    sigma_true     <- abs(rt(1, 3)) + 0.5
    means_X <- colMeans(X[, -1, drop = FALSE])
    Xc      <- sweep(X[, -1, drop = FALSE], 2, means_X, "-")
    mu_true <- as.numeric(Intercept_true + Xc %*% b_true)
    Y <- rnorm(N_OBS, mu_true, sigma_true)
    list(
        data  = list(N = N_OBS, Y = Y, K = K, X = X, prior_only = 0L),
        truth = list(Intercept = Intercept_true,
                     b = matrix(b_true, nrow = 1L),
                     sigma = sigma_true)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("diamonds.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
