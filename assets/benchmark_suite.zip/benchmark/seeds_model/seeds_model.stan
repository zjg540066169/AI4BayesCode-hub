data {
  int<lower=0> I;
  array[I] int<lower=0> n;
  array[I] int<lower=0> N;
  vector[I] x1;
  vector[I] x2;
}
transformed data {
  vector[I] x1x2;
  x1x2 = x1 .* x2;
}
parameters {
  real alpha0;
  real alpha1;
  real alpha12;
  real alpha2;
  real<lower=0> tau;
  vector[I] b;
}
transformed parameters {
  real<lower=0> sigma;
  sigma = 1.0 / sqrt(tau);
}
model {
  alpha0 ~ normal(0.0, 1.0E3);
  alpha1 ~ normal(0.0, 1.0E3);
  alpha2 ~ normal(0.0, 1.0E3);
  alpha12 ~ normal(0.0, 1.0E3);
  // HalfNormal(0, 1) on sigma = 1/sqrt(tau); tau is the parameter so add Jacobian.
  sigma ~ normal(0, 1);
  target += -1.5 * log(tau);   // |d sigma / d tau| = 0.5 * tau^(-1.5)
  
  b ~ normal(0.0, sigma);
  n ~ binomial_logit(N,
                     alpha0 + alpha1 * x1 + alpha2 * x2 + alpha12 * x1x2 + b);
}


