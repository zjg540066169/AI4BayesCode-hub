# Data-generating process for the hmm_drive_1 benchmark model.
# Extracted from sim1_hmm_drive_1.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

K_TRUE <- 2L
N_DATA <- 200L  # bivariate -> 400 obs total -> tau/rho identified well

simulate_data <- function(seed = 123) {
    set.seed(seed)
    # Two transition rows from Dirichlet(1, 1).
    th1 <- as.numeric(rgamma(K_TRUE, 1, 1)); th1 <- th1 / sum(th1)
    th2 <- as.numeric(rgamma(K_TRUE, 1, 1)); th2 <- th2 / sum(th2)
    A <- rbind(th1, th2)

    # phi, lambda from prompt-spec priors restricted to ordered support
    # AND a minimum 1.5-unit separation between states. Reason: the cpp's
    # init clusters obs by u-median and uses the v cluster mean as
    # lambda_init. When phi states are close (relative to tau) the u-
    # clustering does not match the underlying z; v cluster means become
    # mixed averages; lambda_init lands at a degenerate point and NUTS
    # warmup adapts step-size to ~0 -> lambda chain is FROZEN for the
    # entire run. Same for closely-spaced lambda states blocking the v-
    # cluster check that the cpp uses for its z init. Forcing a 1.5+
    # separation in BOTH phi and lambda keeps u/v/z all consistent.
    repeat {
        p1 <- rnorm(1, 0, 1); p2 <- rnorm(1, 3, 1)
        if (p2 - p1 > 1.5) break
    }
    repeat {
        l1 <- rnorm(1, 0, 1); l2 <- rnorm(1, 3, 1)
        if (l2 - l1 > 1.5) break
    }
    phi    <- c(p1, p2)
    lambda <- c(l1, l2)

    # Tighter tau, rho: keeps obs noise small relative to state spread,
    # so u-clustering and v-clustering both reliably match the true z.
    # Was exp(runif(log(0.3), log(1.5))) = [0.3, 1.5]; now [0.2, 0.6].
    tau <- runif(1, 0.2, 0.6)
    rho <- runif(1, 0.2, 0.6)

    # Markov chain.
    z <- integer(N_DATA)
    z[1] <- sample.int(K_TRUE, 1L)
    for (t in 2:N_DATA) z[t] <- sample.int(K_TRUE, 1L, prob = A[z[t-1L], ])
    u <- rnorm(N_DATA, phi[z],    tau)
    v <- rnorm(N_DATA, lambda[z], rho)

    list(
        data = list(N = N_DATA, K = K_TRUE,
                    u = u, v = v,
                    alpha = matrix(1, K_TRUE, K_TRUE)),  # uniform Dir prior
        truth = list(
            phi     = matrix(phi,     nrow = 1L),
            lambda  = matrix(lambda,  nrow = 1L),
            tau     = tau,
            rho     = rho,
            theta_1 = matrix(th1, nrow = 1L),
            theta_2 = matrix(th2, nrow = 1L)))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("hmm_drive_1.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
