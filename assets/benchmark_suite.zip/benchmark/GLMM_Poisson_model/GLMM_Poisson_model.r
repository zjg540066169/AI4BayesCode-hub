# Data-generating process for the GLMM_Poisson_model benchmark model.
# Extracted from sim1_GLMM_Poisson_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_OBS <- 20L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    year        <- seq(-1, 1, length.out = N_OBS)
    alpha_true  <- runif(1, -3, 3)
    beta_true   <- runif(3, -1, 1)
    sigma_true  <- runif(1, 0.1, 0.5)
    eps_true    <- rnorm(N_OBS, 0, sigma_true)
    eta         <- alpha_true + beta_true[1]*year + beta_true[2]*year^2 +
                   beta_true[3]*year^3 + eps_true
    C <- rpois(N_OBS, exp(eta))
    list(
        data  = list(n = N_OBS, C = as.integer(C), year = year),
        truth = list(alpha = alpha_true,
                     beta1 = matrix(beta_true[1], nrow = 1L),
                     beta2 = matrix(beta_true[2], nrow = 1L),
                     beta3 = matrix(beta_true[3], nrow = 1L),
                     sigma = sigma_true,
                     eps   = matrix(eps_true, nrow = 1L))
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("GLMM_Poisson_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
