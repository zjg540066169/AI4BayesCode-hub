# Data-generating process for the low_dim_gauss_mix benchmark model.
# Extracted from sim1_low_dim_gauss_mix.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 150L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    # Well-separated, ordered mu
    mu_true <- sort(c(rnorm(1, -1.5, 0.4), rnorm(1, 1.5, 0.4)))
    sigma_true <- abs(rnorm(2, 0, 0.8)) + 0.3
    theta_true <- rbeta(1, 5, 5)

    z <- rbinom(N_DATA, 1L, 1 - theta_true) + 1L  # 1 with prob theta, 2 with prob 1-theta
    y_obs <- rnorm(N_DATA, mu_true[z], sigma_true[z])

    list(
        data = list(N = N_DATA, y = y_obs),
        truth = list(
            mu    = matrix(mu_true,    nrow = 1L),
            sigma = matrix(sigma_true, nrow = 1L),
            theta = theta_true
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("low_dim_gauss_mix.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
