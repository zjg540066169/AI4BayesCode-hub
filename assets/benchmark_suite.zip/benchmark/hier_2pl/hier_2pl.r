# Data-generating process for the hier_2pl benchmark model.
# Extracted from sim1_hier_2pl.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

J_N <- 30L
I_N <- 12L
N_OBS <- I_N * J_N

II_VEC <- as.integer(rep(seq_len(I_N), times = J_N))
JJ_VEC <- as.integer(rep(seq_len(J_N), each  = I_N))

simulate_data <- function(seed = 123) {
    set.seed(seed)

    # Hyperparameters within prior support (Stan: mu[1]~N(0,1), mu[2]~N(0,5),
    # tau~Exp(0.1), L_Omega~LKJ(4), theta~N(0,1)).
    mu_true  <- c(rnorm(1, 0.2, 0.3), rnorm(1, 0.0, 0.5))
    tau_true <- c(runif(1, 0.3, 1.2), runif(1, 0.4, 1.5))
    rho_true <- runif(1, -0.5, 0.5)

    Omega    <- matrix(c(1, rho_true, rho_true, 1), 2, 2)
    Sigma    <- diag(tau_true) %*% Omega %*% diag(tau_true)
    L_chol   <- chol(Sigma)
    ab_raw   <- matrix(rnorm(2 * I_N), I_N, 2)
    ab_true  <- ab_raw %*% L_chol
    ab_true  <- sweep(ab_true, 2L, mu_true, "+")
    log_alpha_true <- ab_true[, 1]
    beta_true      <- ab_true[, 2]

    theta_true <- rnorm(J_N, 0, 1)

    eta <- exp(log_alpha_true[II_VEC]) *
           (theta_true[JJ_VEC] - beta_true[II_VEC])
    p_obs  <- 1 / (1 + exp(-eta))
    y_obs  <- rbinom(N_OBS, 1L, p_obs)

    list(
        data = list(
            y_dbl = as.numeric(y_obs),
            y_int = as.integer(y_obs),
            ii    = II_VEC,
            jj    = JJ_VEC,
            I_n   = I_N, J_n = J_N, N_obs = N_OBS
        ),
        truth = list(
            theta     = matrix(theta_true,     nrow = 1L),
            log_alpha = matrix(log_alpha_true, nrow = 1L),
            beta      = matrix(beta_true,      nrow = 1L),
            mu        = matrix(mu_true,        nrow = 1L),
            tau       = matrix(tau_true,       nrow = 1L),
            rho       = rho_true
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("hier_2pl.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
