# Data-generating process for the bones_model benchmark model.
# Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data, for
#            coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    nChild <- 30L
    nInd   <- 6L
    ncat   <- sample(3:5, nInd, replace = TRUE)
    gamma  <- matrix(-1, nrow = nInd, ncol = 4)
    for (j in seq_len(nInd)) {
        if (ncat[j] > 1L) {
            cuts <- sort(rnorm(ncat[j] - 1L))
            gamma[j, seq_len(ncat[j] - 1L)] <- cuts
        }
    }
    delta <- runif(nInd, 0.5, 2)
    theta <- rnorm(nChild, 0, 6)
    grade <- matrix(-1L, nrow = nChild, ncol = nInd)
    for (i in seq_len(nChild)) {
        for (j in seq_len(nInd)) {
            if (runif(1) < 0.9) {
                Q <- plogis(delta[j] * (theta[i] - gamma[j, seq_len(ncat[j] - 1L)]))
                p <- numeric(ncat[j])
                p[1] <- 1 - Q[1]
                if (ncat[j] > 2L) {
                    for (k in 2:(ncat[j] - 1L)) p[k] <- Q[k - 1L] - Q[k]
                }
                p[ncat[j]] <- Q[ncat[j] - 1L]
                p <- p / sum(p)
                grade[i, j] <- sample.int(ncat[j], 1, prob = p)
            }
        }
    }
    list(
        data = list(
            nChild = nChild,
            nInd   = nInd,
            gamma  = gamma,
            delta  = delta,
            ncat   = as.integer(ncat),
            grade  = grade
        ),
        truth = list(theta = matrix(theta, nrow = 1L))
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("bones_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
