# Data-generating process for the garch11 benchmark model.
# Extracted from sim1_garch11.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    T_n    <- 50L
    sigma1 <- 1
    mu     <- rnorm(1, 0, 1)
    alpha0 <- rexp(1, rate = 10)
    alpha1 <- runif(1, 0, 1)
    beta1  <- runif(1, 0, 1 - alpha1)
    sigma  <- numeric(T_n)
    y      <- numeric(T_n)
    sigma[1] <- sigma1
    y[1]     <- rnorm(1, mu, sigma[1])
    for (t in 2:T_n) {
        sigma[t] <- sqrt(alpha0 + alpha1 * (y[t - 1L] - mu)^2 + beta1 * sigma[t - 1L]^2)
        y[t]     <- rnorm(1, mu, sigma[t])
    }
    list(
        data = list(T = T_n, y = y, sigma1 = sigma1),
        truth = list(mu = mu, alpha0 = alpha0, alpha1 = alpha1, beta1 = beta1))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("garch11.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
