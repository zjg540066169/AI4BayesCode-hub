# Data-generating process for the dogs benchmark model.
# Extracted from sim1_dogs.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    n_dogs   <- 8L
    n_trials <- 12L
    beta     <- rnorm(3, 0, 100)         # Normal(0, sd = 100), per dogs.txt
    y        <- matrix(0L, nrow = n_dogs, ncol = n_trials)
    A        <- matrix(0,  nrow = n_dogs, ncol = n_trials)
    S        <- matrix(0,  nrow = n_dogs, ncol = n_trials)
    for (j in seq_len(n_dogs)) {
        n_avoid <- 0
        n_shock <- 0
        for (t in seq_len(n_trials)) {
            A[j, t] <- n_avoid
            S[j, t] <- n_shock
            p       <- plogis(beta[1] + beta[2] * n_avoid + beta[3] * n_shock)
            y[j, t] <- rbinom(1, 1, p)
            n_avoid <- n_avoid + 1L - y[j, t]
            n_shock <- n_shock + y[j, t]
        }
    }
    # Dog-major flat (rows j = 1..n_dogs, then trials t = 1..n_trials within each row)
    y_flat <- as.vector(t(y))
    A_flat <- as.vector(t(A))
    S_flat <- as.vector(t(S))
    list(
        data = list(
            n_dogs   = n_dogs,
            n_trials = n_trials,
            y        = y,           # 2D matrix for Stan
            y_flat   = y_flat,      # length-N flat for AI
            A_flat   = A_flat,      # length-N flat for AI
            S_flat   = S_flat),
        truth = list(beta = beta))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("dogs.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
