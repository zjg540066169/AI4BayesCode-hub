# Data-generating process for the radon_variable_slope_centered benchmark model.
# Extracted from sim1_radon_variable_slope_centered.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 100L; J <- 12L
    county_idx <- sample.int(J, N, replace = TRUE)
    floor_measure <- rbinom(N, 1, 0.4)
    alpha       <- rnorm(1, 0, 10)
    sigma_y     <- abs(rnorm(1, 0, 1))
    sigma_beta  <- abs(rnorm(1, 0, 1))
    mu_beta     <- rnorm(1, 0, 10)
    beta        <- rnorm(J, mu_beta, sigma_beta)
    mu          <- alpha + floor_measure * beta[county_idx]
    log_radon   <- rnorm(N, mu, sigma_y)
    list(
        data = list(N = N, J = J, county_idx = as.integer(county_idx),
                    floor_measure = as.numeric(floor_measure), log_radon = log_radon),
        truth = list(alpha = alpha, beta = matrix(beta, nrow = 1L),
                     mu_beta = mu_beta, sigma_beta = sigma_beta, sigma_y = sigma_y)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("radon_variable_slope_centered.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
