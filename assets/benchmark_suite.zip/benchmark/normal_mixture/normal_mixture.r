# Data-generating process for the normal_mixture benchmark model.
# Extracted from sim1_normal_mixture.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N     <- 60L
    theta <- runif(1, 0, 1)
    mu    <- rnorm(2, 0, 10)
    z     <- rbinom(N, 1, theta) + 1L
    y     <- rnorm(N, mean = mu[z], sd = 1)
    # Sort mu ascending to match AI ordering; adjust theta to be weight of smaller-mean component
    if (mu[1] > mu[2]) {
        mu    <- rev(mu)
        theta <- 1 - theta
    }
    list(
        data  = list(N = N, y = y),
        truth = list(mu = mu, theta = theta)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("normal_mixture.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
