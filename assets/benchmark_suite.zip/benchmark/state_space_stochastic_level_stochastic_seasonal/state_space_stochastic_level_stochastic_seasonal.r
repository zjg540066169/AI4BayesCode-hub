# Data-generating process for the state_space_stochastic_level_stochastic_seasonal
# benchmark model.
# Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data, for
#            coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    n <- 36L
    x <- rnorm(n)
    w <- rnorm(n)
    beta     <- rnorm(1, 0, 1)
    lambda   <- rnorm(1, 0, 1)
    sigma    <- sort(abs(rt(3, df = 4)))
    mu       <- numeric(n)
    seasonal <- numeric(n)
    mu[1]    <- rnorm(1, 0, 1)
    if (n >= 11L) seasonal[1:11] <- rnorm(11, 0, 0.1)
    for (t in 2:n) {
        mu[t] <- rnorm(1, mu[t - 1L], sigma[2])
    }
    if (n >= 12L) {
        for (t in 12:n) {
            seasonal[t] <- rnorm(1, -sum(seasonal[(t - 11L):(t - 1L)]), sigma[1])
        }
    }
    yhat <- mu + beta * x + lambda * w
    y    <- rnorm(n, yhat + seasonal, sigma[3])
    list(
        data = list(n = n, y = y, x = x, w = w),
        truth = list(
            mu       = matrix(mu,       nrow = 1L),
            seasonal = matrix(seasonal, nrow = 1L),
            beta     = beta,
            lambda   = lambda,
            sigma    = matrix(sigma,    nrow = 1L)
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("state_space_stochastic_level_stochastic_seasonal.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
