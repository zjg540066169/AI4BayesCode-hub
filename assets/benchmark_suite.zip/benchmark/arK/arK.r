# Data-generating process for the AR(K) benchmark model.
# Returns a list with:
#   $data  : inputs to the fitted model (K, T, y)
#   $truth : latent parameter values used to simulate the data (alpha,
#            beta, sigma), for coverage / recovery checks.

K_TRUE <- 2L
T_OBS  <- 40L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    alpha <- rnorm(1, 0, 10)
    beta  <- rnorm(K_TRUE, 0, 0.3)
    sigma <- abs(rcauchy(1, 0, 2.5))
    y <- numeric(T_OBS)
    y[1:K_TRUE] <- rnorm(K_TRUE, alpha, sigma)
    for (t in (K_TRUE + 1L):T_OBS) {
        mu_t <- alpha + sum(beta * rev(y[(t - K_TRUE):(t - 1L)]))
        y[t] <- rnorm(1, mu_t, sigma)
    }
    list(
        data  = list(K = K_TRUE, T = T_OBS, y = y),
        truth = list(alpha = alpha,
                     beta  = matrix(beta, nrow = 1L),
                     sigma = sigma)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("arK.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2, iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
