# Data-generating process for the hmm_drive_0 benchmark model.
# Extracted from sim1_hmm_drive_0.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

K_TRUE <- 2L
N_DATA <- 200L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    # Well-separated rates so label-switching is unlikely
    phi_raw    <- c(runif(1, 0.3, 0.8), runif(1, 2.5, 3.5))
    lambda_raw <- c(runif(1, 0.3, 0.8), runif(1, 2.5, 3.5))
    # Sticky transition matrix (each state self-transitions with high prob)
    p11 <- runif(1, 0.7, 0.95); p22 <- runif(1, 0.7, 0.95)
    A_true <- matrix(c(p11, 1 - p11,
                       1 - p22, p22), nrow = K_TRUE, ncol = K_TRUE, byrow = TRUE)

    # Sort by phi (state 1 = small phi) — matches relabel convention
    ord <- order(phi_raw)
    phi_true    <- phi_raw[ord]
    lambda_true <- lambda_raw[ord]
    A_true      <- A_true[ord, ord, drop = FALSE]

    pi_init <- c(0.5, 0.5)
    z <- integer(N_DATA)
    z[1] <- sample.int(K_TRUE, 1L, prob = pi_init)
    for (t in 2:N_DATA) {
        z[t] <- sample.int(K_TRUE, 1L, prob = A_true[z[t - 1L], ])
    }
    u_obs <- rexp(N_DATA, rate = phi_true[z])
    v_obs <- rexp(N_DATA, rate = lambda_true[z])

    list(
        data = list(
            u = u_obs, v = v_obs, N = N_DATA, K = K_TRUE,
            alpha = matrix(1.0, K_TRUE, K_TRUE)   # Dirichlet(1,1) — match AI hardcode
        ),
        truth = list(
            theta_1 = matrix(A_true[1, ], nrow = 1L),   # 1 x K
            theta_2 = matrix(A_true[2, ], nrow = 1L),
            phi     = matrix(phi_true,    nrow = 1L),
            lambda  = matrix(lambda_true, nrow = 1L)
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("hmm_drive_0.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
