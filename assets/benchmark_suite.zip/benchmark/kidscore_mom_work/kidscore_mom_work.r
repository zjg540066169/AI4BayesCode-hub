# Data-generating process for the kidscore_mom_work benchmark model.
# Extracted from sim1_kidscore_mom_work.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 50L
P_DIM  <- 4L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    mom_work <- sample.int(4L, N_DATA, replace = TRUE,
                           prob = c(0.3, 0.25, 0.2, 0.25))
    work2 <- as.numeric(mom_work == 2L)
    work3 <- as.numeric(mom_work == 3L)
    work4 <- as.numeric(mom_work == 4L)
    beta1_true <- runif(1, 75, 95)
    beta2_true <- runif(1, -8, 8)
    beta3_true <- runif(1, -8, 8)
    beta4_true <- runif(1, -8, 8)
    sigma_true <- runif(1, 17, 23)
    mu <- beta1_true + beta2_true * work2 + beta3_true * work3 + beta4_true * work4
    kid_score <- mu + rnorm(N_DATA, 0, sigma_true)
    X <- cbind(1, work2, work3, work4)
    list(
        data = list(N = N_DATA, kid_score = kid_score,
                    mom_work = as.integer(mom_work),
                    X = X, y = kid_score),
        truth = list(beta = matrix(c(beta1_true, beta2_true, beta3_true, beta4_true), nrow = 1L),
                     sigma = sigma_true)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("kidscore_mom_work.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
