"""
Dirac-spike, Normal-slab variable-selection prior for a Gaussian linear
regression, implemented in PyMC.

Prior:
    pi          ~ Beta(1, 1)                          (== Uniform(0, 1))
    sigma       ~ Jeffreys,  p(sigma)      prop 1/sigma       (improper)
    sigma_slab  ~ Jeffreys,  p(sigma_slab) prop 1/sigma_slab  (improper)
    gamma_j     ~ Bernoulli(pi)                              j = 1, ..., p
    beta_j | gamma_j = 0                                = 0
    beta_j | gamma_j = 1, sigma, sigma_slab             ~ Normal(0, sigma * sigma_slab)

Equivalently:

    beta_j ~ (1 - gamma_j) * delta_0 + gamma_j * Normal(0, sigma * sigma_slab)

Likelihood:

    y_i ~ Normal(x_i^T beta, sigma),    i = 1, ..., N

PyMC encoding (no reversible jump)
----------------------------------
PyMC's gradient-based samplers (NUTS, HMC) require a fixed-dimension
continuous parameter space, so we cannot literally implement reversible
jump. The standard fixed-dim equivalent introduces a latent slab draw

    beta_slab_j  ~  Normal(0, sigma * sigma_slab)        for every j

and defines the effective coefficient as a deterministic mask

    beta_j  :=  gamma_j * beta_slab_j

so that beta_j == 0 exactly when gamma_j = 0 (Dirac spike) and
beta_j == beta_slab_j ~ Normal(0, sigma * sigma_slab) when gamma_j = 1
(slab).

Improper priors p(sigma) prop 1/sigma and p(sigma_slab) prop 1/sigma_slab
are encoded via pm.Flat on log_sigma / log_sigma_slab: pm.Flat is improper
uniform on the unconstrained scale, and the auto-Jacobian
d sigma / d log_sigma = sigma yields the implied Jeffreys
p(sigma) prop 1/sigma on the natural scale. The posterior is proper given
the likelihood.

Compound step:

    BinaryGibbsMetropolis  ->  gamma                                  (discrete)
    NUTS                   ->  pi, log_sigma, log_sigma_slab, beta_slab  (cont.)

Inference is reported on the deterministic `beta`, NOT `beta_slab`:
when gamma_j = 0, beta_slab_j receives no likelihood signal and just
samples from its Normal(0, sigma * sigma_slab) prior, so its diagnostics
are not posterior-meaningful; the deterministic beta_j is exactly 0 and
that is what matters.

Run:
    pip install pymc arviz numpy
    python Dirac_Spike_normal_model.py
"""

from __future__ import annotations

import numpy as np
import pymc as pm
import pytensor.tensor as pt
import arviz as az


# DGP fixed values for the residual + slab scales. The fit_spike_normal
# model treats sigma and sigma_slab as free parameters with improper
# Jeffreys priors (pm.Flat on the log scale), but the data-generating
# values are held CONSTANT across replicates so coverage on these two
# scalars is a meaningful frequentist point-coverage diagnostic.
SIGMA_DGP, SIGMA_SLAB_DGP = 1.0, 1.0


# ----------------------------------------------------------------------------
# Synthetic data: linear regression with sparse coefficients.
# Samples (pi, gamma, beta_slab) from the same joint prior the model uses
# (with sigma and sigma_slab held fixed at SIGMA_DGP / SIGMA_SLAB_DGP),
# then y from the likelihood.
# ----------------------------------------------------------------------------
def simulate_data(n: int = 200, p: int = 12,
                  seed: int = 2026
                  ) -> tuple[np.ndarray, np.ndarray, dict]:
    """
    Returns (y, X, truth) where truth is a dict of the latent parameters
    used to simulate the data:
        truth["pi"]         scalar, drawn from Beta(1, 1)
        truth["sigma"]      scalar = SIGMA_DGP      (held fixed across replicates)
        truth["sigma_slab"] scalar = SIGMA_SLAB_DGP (held fixed across replicates)
        truth["gamma"]      (p,) 0/1, rejection-sampled to ensure sum(gamma) >= 1
        truth["beta_slab"]  (p,) drawn from Normal(0, sigma * sigma_slab) per coord
        truth["beta"]       (p,) = gamma * beta_slab
    """
    rng = np.random.default_rng(seed)

    # X: standard normal columns then column-standardized.
    X = rng.standard_normal((n, p))
    X = (X - X.mean(0)) / X.std(0, ddof=0)

    # sigma and sigma_slab are held FIXED at the DGP values. pi is drawn
    # from its Beta(1, 1) prior; gamma | pi is rejection-sampled to ensure
    # at least one inclusion (sum(gamma) >= 1) so sigma_slab is always
    # likelihood-identifiable.
    sigma      = SIGMA_DGP
    sigma_slab = SIGMA_SLAB_DGP
    pi         = rng.beta(1.0, 1.0)

    for _ in range(10_000):
        gamma = rng.binomial(1, pi, size=p)
        if int(gamma.sum()) >= 1:
            break
    else:
        gamma[rng.integers(0, p)] = 1

    # Slab scale = sigma * sigma_slab (sigma-scaled / Ishwaran-Rao 2005)
    # per the prompt: beta_j | gamma_j = 1, sigma, sigma_slab
    #                 ~ Normal(0, (sigma * sigma_slab)^2).
    beta_slab = rng.normal(loc=0.0, scale=sigma * sigma_slab, size=p)
    beta      = gamma * beta_slab

    y = X @ beta + rng.normal(0.0, sigma, size=n)

    truth = dict(pi=pi, sigma=sigma, sigma_slab=sigma_slab,
                 gamma=gamma, beta_slab=beta_slab, beta=beta)
    return y, X, truth


# ----------------------------------------------------------------------------
# Model: y_i ~ N(x_i^T beta, sigma);
#        beta_j ~ (1 - gamma_j) delta_0 + gamma_j N(0, sigma * sigma_slab)
# ----------------------------------------------------------------------------
def fit_spike_normal(y: np.ndarray, X: np.ndarray,
                     draws: int = 2000,
                     tune: int = 2000,
                     chains: int = 4,
                     cores: int = 4,
                     seed: int = 42) -> az.InferenceData:
    """
    Fit y = X @ beta + eps with a Dirac-spike Normal-slab prior on beta.
    Hyperparameters pi, sigma, sigma_slab are sampled from their priors
    (Beta(1,1), Jeffreys, Jeffreys respectively).
    """
    n, p = X.shape

    with pm.Model() as model:

        # ----- inclusion-probability hyperprior -----
        # pi ~ Beta(1, 1)
        pi = pm.Beta("pi", alpha=1.0, beta=1.0)

        # ----- residual-scale hyperprior -----
        # sigma ~ improper Jeffreys p(sigma) prop 1/sigma. pm.Flat on the
        # unconstrained log scale gives uniform on log_sigma (improper),
        # which transforms via the auto-Jacobian to 1/sigma on the natural
        # scale.
        log_sigma = pm.Flat("log_sigma")
        sigma     = pm.Deterministic("sigma", pt.exp(log_sigma))

        # ----- slab-scale hyperprior -----
        # Same: improper Jeffreys p(sigma_slab) prop 1/sigma_slab.
        log_sigma_slab = pm.Flat("log_sigma_slab")
        sigma_slab     = pm.Deterministic("sigma_slab", pt.exp(log_sigma_slab))

        # ----- inclusion indicators -----
        gamma = pm.Bernoulli("gamma", p=pi, shape=p)

        # ----- slab values -----
        # Slab scale = sigma * sigma_slab (sigma-scaled) per the prompt:
        #   beta_j | gamma_j = 1, sigma, sigma_slab
        #     ~ N(0, (sigma * sigma_slab)^2).
        beta_slab = pm.Normal("beta_slab", mu=0.0,
                              sigma=sigma * sigma_slab, shape=p)

        # ----- mixture form of the prior -----
        # beta_j = gamma_j * beta_slab_j
        #   beta_j == 0           when gamma_j = 0  (delta_0)
        #   beta_j == beta_slab_j when gamma_j = 1  (Normal slab)
        beta = pm.Deterministic("beta", gamma * beta_slab)

        # ----- likelihood -----
        pm.Normal("y_obs", mu=pt.dot(X, beta), sigma=sigma, observed=y)

        # ----- compound step -----
        # gamma is the only discrete block; everything continuous goes to
        # NUTS so PyMC samples it together by default. Naming the steps
        # explicitly is just for clarity.
        step_disc = pm.BinaryGibbsMetropolis([gamma])
        step_cont = pm.NUTS([pi, log_sigma, log_sigma_slab, beta_slab])

        idata = pm.sample(
            draws=draws,
            tune=tune,
            chains=chains,
            cores=cores,
            step=[step_disc, step_cont],
            random_seed=seed,
            progressbar=False,
            return_inferencedata=True,
        )

    return idata


if __name__ == "__main__":
    # Example: draw one DGP replicate.
    y, X, truth = simulate_data(n=200, p=12, seed=2026)
    print(f"y shape: {y.shape}, X shape: {X.shape}, "
          f"k_true = {int(truth['gamma'].sum())}")
    print(f"truth: pi={truth['pi']:.3f}, sigma={truth['sigma']:.3f}, "
          f"sigma_slab={truth['sigma_slab']:.3f}")

    # To fit the reference PyMC model:
    # idata = fit_spike_normal(y, X, draws=2000, tune=2000, chains=4, cores=4, seed=42)
