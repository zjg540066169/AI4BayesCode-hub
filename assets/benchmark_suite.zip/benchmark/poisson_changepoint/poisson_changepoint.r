# Data-generating process for the poisson_changepoint benchmark model.
# Extracted from sim1_poisson_changepoint.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    T   <- 20L
    r_e <- 1.0
    r_l <- 1.0
    e   <- rexp(1, rate = r_e)
    l   <- rexp(1, rate = r_l)
    s   <- sample.int(T, 1L)
    D   <- rpois(T, lambda = ifelse(seq_len(T) < s, e, l))
    list(
        data  = list(T = T, r_e = r_e, r_l = r_l, D = D),
        truth = list(e = e, l = l, s = s)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("poisson_changepoint.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
