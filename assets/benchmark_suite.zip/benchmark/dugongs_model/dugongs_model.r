# Data-generating process for the dugongs_model benchmark model.
# Extracted from sim1_dugongs_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 27L
X_FIXED <- seq(1, 27, length.out = N_DATA)

simulate_data <- function(seed = 123) {
    set.seed(seed)
    alpha  <- runif(1, 1.5, 3.5)
    beta   <- runif(1, 0.3, 2.0)
    lambda <- runif(1, 0.6, 0.95)
    sigma  <- runif(1, 0.05, 0.3)
    tau    <- 1 / sigma^2
    m      <- alpha - beta * lambda^X_FIXED
    Y      <- rnorm(N_DATA, m, sigma)
    list(
        data  = list(N = N_DATA, x = X_FIXED, Y = Y),
        truth = list(alpha = alpha, beta = beta, lambda = lambda, tau = tau)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("dugongs_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
