# Data-generating process for the election88_full benchmark model.
# Extracted from sim1_election88_full.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N             <- 120L
    n_age         <- 4L
    n_edu         <- 4L
    n_age_edu     <- as.integer(n_age * n_edu)
    n_region_full <- 4L
    n_state       <- 8L
    age         <- sample.int(n_age,         N, replace = TRUE)
    edu         <- sample.int(n_edu,         N, replace = TRUE)
    age_edu     <- (age - 1L) * n_edu + edu
    black       <- rbinom(N, 1, 0.2)
    female      <- rbinom(N, 1, 0.5)
    region_full <- sample.int(n_region_full, N, replace = TRUE)
    state       <- sample.int(n_state,       N, replace = TRUE)
    v_prev_full <- rnorm(N)
    sigma_a <- runif(1, 0.2, 1)
    sigma_b <- runif(1, 0.2, 1)
    sigma_c <- runif(1, 0.2, 1)
    sigma_d <- runif(1, 0.2, 1)
    sigma_e <- runif(1, 0.2, 1)
    a <- rnorm(n_age,         0, sigma_a)
    b <- rnorm(n_edu,         0, sigma_b)
    c <- rnorm(n_age_edu,     0, sigma_c)
    d <- rnorm(n_state,       0, sigma_d)
    e <- rnorm(n_region_full, 0, sigma_e)
    beta <- rnorm(5, 0, 100)
    y_hat <- beta[1] + beta[2] * black + beta[3] * female +
        beta[5] * female * black + beta[4] * v_prev_full +
        a[age] + b[edu] + c[age_edu] + d[state] + e[region_full]
    y <- rbinom(N, 1, plogis(y_hat))

    # AI design matrix [intercept, black, female, v_prev, female*black]
    X <- cbind(rep(1.0, N), as.numeric(black), as.numeric(female),
               v_prev_full, as.numeric(female) * as.numeric(black))

    list(
        data = list(
            N             = N,
            n_age         = n_age,
            n_edu         = n_edu,
            n_age_edu     = n_age_edu,
            n_region_full = n_region_full,
            n_state       = n_state,
            age           = as.integer(age),
            edu           = as.integer(edu),
            age_edu       = as.integer(age_edu),
            state         = as.integer(state),
            region_full   = as.integer(region_full),
            black         = as.numeric(black),
            female        = as.numeric(female),
            v_prev_full   = v_prev_full,
            y             = as.integer(y),
            X             = X),
        truth = list(
            beta    = beta,
            a       = a,
            b       = b,
            c       = c,
            d       = d,
            e       = e,
            sigma_a = sigma_a,
            sigma_b = sigma_b,
            sigma_c = sigma_c,
            sigma_d = sigma_d,
            sigma_e = sigma_e))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("election88_full.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
