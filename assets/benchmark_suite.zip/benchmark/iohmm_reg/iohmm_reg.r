# Data-generating process for the iohmm_reg benchmark model.
# Extracted from sim1_iohmm_reg.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

K_TRUE <- 2L
M_TRUE <- 2L
T_DATA <- 80L   # reduced from 120 for speed (FFBS is O(T*K^2) per sweep)

simulate_data <- function(seed = 123) {
    set.seed(seed)
    # u_t = (1, x_t)
    u_mat <- cbind(1.0, rnorm(T_DATA, 0, 1))     # T x M
    # State regressors w_k: M-vec each. State 1 ~ baseline, state 2 different
    w_raw <- rbind(c(rnorm(1, 0, 0.3), rnorm(1, -0.5, 0.3)),
                   c(rnorm(1, 0, 0.3), rnorm(1,  0.5, 0.3)))
    # Emission regressors b_k: kept WITHIN the Normal(0, 1) prior support
    # (truth |b| <= ~1.8). Pushing |b| to 3.5 caused severe prior-data
    # conflict -> Stan posterior collapsed to swapped/degenerate sigma mode
    # even though the model "could" recover truth structurally.
    b_raw <- rbind(c(rnorm(1, -1.5, 0.3), rnorm(1,  0.5, 0.3)),
                   c(rnorm(1,  1.5, 0.3), rnorm(1, -0.5, 0.3)))
    # State separation comes from sigma ratio (3-5x) rather than b magnitude.
    sigma_raw <- c(runif(1, 0.3, 0.5), runif(1, 1.4, 1.8))
    pi1_raw   <- c(0.5, 0.5)

    # Sort by sigma ascending — matches the relabel convention
    ord <- order(sigma_raw)
    sigma_true <- sigma_raw[ord]
    w_true     <- w_raw[ord, , drop = FALSE]
    b_true     <- b_raw[ord, , drop = FALSE]
    pi1_true   <- pi1_raw[ord]

    # Forward simulate: transitions depend on u_t' w
    z <- integer(T_DATA)
    z[1] <- sample.int(K_TRUE, 1L, prob = pi1_true)
    for (t in 2:T_DATA) {
        unA <- as.numeric(u_mat[t, ] %*% t(w_true))   # K-vec
        p   <- exp(unA - max(unA)); p <- p / sum(p)
        z[t] <- sample.int(K_TRUE, 1L, prob = p)
    }
    mu_obs <- as.numeric(rowSums(u_mat * b_true[z, ]))   # T-vec
    y_obs  <- mu_obs + sigma_true[z] * rnorm(T_DATA)

    list(
        data = list(
            y = y_obs, u = u_mat, T = T_DATA, K = K_TRUE, M = M_TRUE
        ),
        truth = list(
            pi_1  = matrix(pi1_true,            nrow = 1L),
            w     = matrix(as.numeric(w_true),  nrow = 1L),   # row-major K*M
            b     = matrix(as.numeric(b_true),  nrow = 1L),
            sigma = matrix(sigma_true,          nrow = 1L)
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("iohmm_reg.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
