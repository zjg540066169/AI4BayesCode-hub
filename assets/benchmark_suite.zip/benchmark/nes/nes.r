# Data-generating process for the nes benchmark model.
# Extracted from sim1_nes.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N           <- 60L
    real_ideo   <- rnorm(N)
    race_adj    <- as.numeric(rbinom(N, 1, 0.3))
    educ1       <- rnorm(N)
    gender      <- as.numeric(rbinom(N, 1, 0.5))
    income      <- rnorm(N)
    age_discrete <- sample(1:4, N, replace = TRUE)
    age30_44    <- as.numeric(age_discrete == 2L)
    age45_64    <- as.numeric(age_discrete == 3L)
    age65up     <- as.numeric(age_discrete == 4L)
    beta        <- rnorm(9, 0, 1)
    sigma       <- runif(1, 0.5, 2)
    mu          <- beta[1] + beta[2] * real_ideo + beta[3] * race_adj +
                   beta[4] * age30_44 + beta[5] * age45_64 + beta[6] * age65up +
                   beta[7] * educ1 + beta[8] * gender + beta[9] * income
    partyid7    <- rnorm(N, mu, sigma)
    list(
        data = list(
            N            = N,
            partyid7     = partyid7,
            real_ideo    = real_ideo,
            race_adj     = race_adj,
            educ1        = educ1,
            gender       = gender,
            income       = income,
            age_discrete = as.integer(age_discrete),
            # X matrix for AI constructor (col order per runner: real_ideo, race_adj,
            # age30_44, age45_64, age65up, educ1, gender, income)
            X_mat        = {
                X <- cbind(real_ideo, race_adj, age30_44, age45_64, age65up,
                           educ1, gender, income)
                storage.mode(X) <- "double"
                X
            }
        ),
        truth = list(beta = beta, sigma = sigma)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("nes.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
