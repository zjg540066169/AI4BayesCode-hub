# Data-generating process for the hmm_example benchmark model.
# Extracted from sim1_hmm_example.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

K_TRUE <- 2L
N_DATA <- 100L  # increased from auto-gen default 30 to give better posterior
                # identification for sim1 cross-impl rhat.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    # Per-row Dirichlet(1, 1) transition rows.
    theta1 <- as.numeric(rgamma(K_TRUE, 1, 1)); theta1 <- theta1 / sum(theta1)
    theta2 <- as.numeric(rgamma(K_TRUE, 1, 1)); theta2 <- theta2 / sum(theta2)
    A <- rbind(theta1, theta2)

    # mu draws under the prompt's prior: mu_1 ~ N(3,1), mu_2 ~ N(10,1),
    # then enforce 0 < mu_1 < mu_2 (positive-ordered support). With
    # priors well-separated by 7 sigma, sort almost always preserves the
    # natural draw order; rejection samples on the rare swap so the
    # truth is from the proper restricted prior.
    repeat {
        m1 <- rnorm(1, 3, 1)
        m2 <- rnorm(1, 10, 1)
        if (m1 > 0 && m1 < m2) break
    }
    mu_true <- c(m1, m2)

    # Markov chain emission.
    z <- integer(N_DATA)
    z[1] <- sample.int(K_TRUE, 1L)   # implicit uniform pi_1
    for (t in 2:N_DATA) z[t] <- sample.int(K_TRUE, 1L, prob = A[z[t-1L], ])
    y <- rnorm(N_DATA, mu_true[z], 1)

    list(
        data = list(y = y, N = N_DATA, K = K_TRUE),
        truth = list(
            mu     = matrix(mu_true, nrow = 1L),
            theta1 = matrix(theta1,  nrow = 1L),
            theta2 = matrix(theta2,  nrow = 1L)))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("hmm_example.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
