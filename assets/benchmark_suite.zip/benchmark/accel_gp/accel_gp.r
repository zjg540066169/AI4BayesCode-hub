# Data-generating process for the accel_gp benchmark model.
# Extracted from sim1_accel_gp.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N            <- 50L
    Kgp_1        <- 1L
    Dgp_1        <- 1L
    NBgp_1       <- 8L
    Xgp_1        <- matrix(rnorm(N * NBgp_1), nrow = N, ncol = NBgp_1)
    slambda_1    <- lapply(seq_len(NBgp_1),
                           function(i) c(i / NBgp_1))
    Kgp_sigma_1  <- 1L
    Dgp_sigma_1  <- 1L
    NBgp_sigma_1 <- 8L
    Xgp_sigma_1  <- matrix(rnorm(N * NBgp_sigma_1),
                            nrow = N, ncol = NBgp_sigma_1)
    slambda_sigma_1 <- lapply(seq_len(NBgp_sigma_1),
                               function(i) c(i / NBgp_sigma_1))
    prior_only <- 0L

    # Benign DGP: brms's default Student_t(3, -13, 36) prior on Intercept
    # has heavy tails that occasionally produce |Y| ~ 1e26 (sigma_lin
    # blows up via exp). Use moderate truncated-normal draws so that Y
    # stays in a sensible range and both Stan and AI cpp can fit cleanly.
    # Values still cover the practical scale for accel-style data
    # (single-digit intercept, single-digit sdgp / lscale).
    Intercept       <- rnorm(1, 0,    2)
    Intercept_sigma <- rnorm(1, 0,    0.5)
    sdgp_1          <- abs(rnorm(1, 0, 1.5))
    lscale_1        <- exp(rnorm(1, 0, 0.5))   # log-scale prior
    sdgp_sigma_1    <- abs(rnorm(1, 0, 0.6))
    lscale_sigma_1  <- exp(rnorm(1, 0, 0.5))
    zgp_1           <- rnorm(NBgp_1)
    zgp_sigma_1     <- rnorm(NBgp_sigma_1)

    mu        <- Intercept +
        Xgp_1 %*% (sqrt(sdgp_1^2 * sqrt(2 * pi) * lscale_1 *
                        exp(-0.5 * lscale_1^2 *
                            sapply(slambda_1, function(v) sum(v^2)))) * zgp_1)
    sigma_lin <- Intercept_sigma +
        Xgp_sigma_1 %*% (sqrt(sdgp_sigma_1^2 * sqrt(2 * pi) * lscale_sigma_1 *
                              exp(-0.5 * lscale_sigma_1^2 *
                                  sapply(slambda_sigma_1, function(v) sum(v^2)))) *
                          zgp_sigma_1)
    sigma <- exp(sigma_lin)
    Y <- rnorm(N, as.numeric(mu), as.numeric(sigma))

    list(
        data = list(
            N = N,
            Y = Y,
            Kgp_1 = Kgp_1, Dgp_1 = Dgp_1, NBgp_1 = NBgp_1,
            Xgp_1 = Xgp_1, slambda_1 = slambda_1,
            Kgp_sigma_1 = Kgp_sigma_1, Dgp_sigma_1 = Dgp_sigma_1,
            NBgp_sigma_1 = NBgp_sigma_1,
            Xgp_sigma_1 = Xgp_sigma_1, slambda_sigma_1 = slambda_sigma_1,
            prior_only = prior_only),
        truth = list(
            Intercept       = Intercept,
            Intercept_sigma = Intercept_sigma,
            sdgp_1          = sdgp_1,
            lscale_1        = lscale_1,
            sdgp_sigma_1    = sdgp_sigma_1,
            lscale_sigma_1  = lscale_sigma_1,
            zgp_1           = matrix(zgp_1,        nrow = 1L),
            zgp_sigma_1     = matrix(zgp_sigma_1,  nrow = 1L)))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("accel_gp.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
