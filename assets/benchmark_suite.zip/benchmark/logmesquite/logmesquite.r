# Data-generating process for the logmesquite benchmark model.
# Extracted from sim1_logmesquite.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

P_DIM <- 7L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 80L
    diam1 <- runif(N, 1, 20)
    diam2 <- runif(N, 1, 20)
    canopy_height <- runif(N, 1, 15)
    total_height <- runif(N, 2, 25)
    density <- runif(N, 0.1, 5)
    group <- rbinom(N, 1, 0.5)
    sigma <- runif(1, 0.1, 1)
    beta <- rnorm(7, 0, 1)
    log_diam1 <- log(diam1); log_diam2 <- log(diam2); log_canopy_height <- log(canopy_height)
    log_total_height <- log(total_height); log_density <- log(density)
    mu <- beta[1] + beta[2]*log_diam1 + beta[3]*log_diam2 + beta[4]*log_canopy_height +
          beta[5]*log_total_height + beta[6]*log_density + beta[7]*group
    log_weight <- rnorm(N, mu, sigma)
    weight <- exp(log_weight)

    X_log <- cbind(1, log_diam1, log_diam2, log_canopy_height, log_total_height, log_density, as.numeric(group))

    list(
        data = list(N = N, weight = as.numeric(weight),
                    diam1 = as.numeric(diam1), diam2 = as.numeric(diam2),
                    canopy_height = as.numeric(canopy_height), total_height = as.numeric(total_height),
                    density = as.numeric(density), group = as.numeric(group),
                    log_weight = log_weight, X = X_log),
        truth = list(beta = matrix(beta, nrow = 1L), sigma = sigma)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("logmesquite.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
