# Data-generating process for the Poisson BART benchmark model.
# Returns a list with:
#   $data  : inputs to the fitted model (N, D, X, y, mu0)
#   $truth : latent log-rate offset r = log_f (length-N vector), for
#            coverage / recovery checks.
#
# DGP:
#   X_{ij}   ~ Uniform(-1, 1),  i = 1..N, j = 1..D
#   mu0_i    ~ Uniform(0.5, 2)
#   log_f_i  = 0.5 sin(pi X_{i1}) + 0.3 X_{i2}^2 - 0.4 X_{i3}
#   lambda_i = mu0_i * exp(log_f_i)
#   y_i      ~ Poisson(lambda_i)
#
# Reference: NONE. The BART R package has wbart (Gaussian) and pbart
# (probit) but no Poisson-BART fitter, and no other CRAN package
# implements Poisson BART in the generalized-BART (Linero 2022) sense.
# This benchmark provides only the DGP; the AI4BayesCode implementation
# is the first published Poisson-BART sampler.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 120L
    D <- 3L
    X      <- matrix(runif(N * D, -1, 1), nrow = N, ncol = D)
    mu0    <- runif(N, 0.5, 2.0)
    log_f  <- 0.5 * sin(pi * X[, 1]) + 0.3 * X[, 2]^2 - 0.4 * X[, 3]
    lambda <- mu0 * exp(log_f)
    y      <- rpois(N, lambda = lambda)
    list(
        data  = list(N = N, D = D, X = X, y = as.integer(y), mu0 = mu0),
        truth = list(r = matrix(log_f, nrow = 1L))
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)
