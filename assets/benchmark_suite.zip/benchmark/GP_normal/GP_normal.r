# Data-generating process for the GP_normal benchmark model.
# Extracted from sim1_GP_normal.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 30L
    x <- sort(runif(N, -2, 2))
    rho   <- 1 / rgamma(1, shape = 5, rate = 5)
    alpha <- abs(rnorm(1, 0, 1))
    sigma <- abs(rnorm(1, 0, 1))
    d2 <- outer(x, x, function(a, b) (a - b)^2)
    K <- alpha^2 * exp(-d2 / (2 * rho^2))
    diag(K) <- diag(K) + sigma^2 + 1e-9
    L <- chol(K)
    y <- as.numeric(drop(t(L) %*% rnorm(N)))
    list(
        data = list(N = N, x = x, y = y, X = matrix(x, ncol = 1L)),
        truth = list(rho = rho, alpha = alpha, sigma = sigma)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("GP_normal.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
