# Data-generating process for the pois_hmm_k3_0 benchmark model.
# Extracted from sim1_pois_hmm_k3_0.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.
#
# Markov chain over K=3 states with ascending Poisson rates (well separated
# for identifiability); sticky transition matrix (high self-persistence).

simulate_data <- function(seed = 4) {
    set.seed(seed)
    Tn     <- 600L
    K      <- 3L
    lambda <- c(2, 8, 25)                          # ascending => identified
    A      <- matrix(c(0.90, 0.07, 0.03,
                       0.05, 0.90, 0.05,
                       0.04, 0.06, 0.90), K, K, byrow = TRUE)
    pivec  <- c(0.6, 0.3, 0.1)

    z <- integer(Tn)
    z[1] <- sample.int(K, 1, prob = pivec)
    for (t in 2:Tn) z[t] <- sample.int(K, 1, prob = A[z[t - 1L], ])
    y <- rpois(Tn, lambda[z])

    list(
        data  = list(T = Tn, K = K, y = y),
        truth = list(lambda = lambda, A = A, pi = pivec, z = z)
    )
}

# Example usage:
sim <- simulate_data(seed = 4)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("pois_hmm_k3_0.stan")
# fit <- mod$sample(data = sim$data, seed = 4, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
