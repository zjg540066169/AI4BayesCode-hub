# Data-generating process for the covid19imperial_v3 benchmark model.
# Extracted from sim1_covid19imperial_v3.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

M_TRUE <- 3L
P_TRUE <- 2L
N2     <- 30L
N0     <- 6L
SHIFT  <- log(1.05) / 6

# Fixed design: two binary interventions starting at different days
make_x_arr <- function() {
    x_arr <- array(0, dim = c(N2, M_TRUE, P_TRUE))
    for (m in seq_len(M_TRUE)) {
        x_arr[15:N2, m, 1L] <- 1.0   # intervention 1: starts day 15
        x_arr[20:N2, m, 2L] <- 1.0   # intervention 2: starts day 20
    }
    x_arr
}
X_ARR <- make_x_arr()

# Serial interval and infection-to-death kernel (fixed across replicates)
SI_FULL   <- exp(-(1:N2) / 4);       SI_FULL  <- SI_FULL / sum(SI_FULL[1:(N2-1)])
SI_SHORT  <- SI_FULL[1:(N2 - 1L)]    # length N2-1 for AI
SI_STAN   <- c(SI_SHORT, 0.0)         # length N2 for Stan (last entry unused)
F1_RAW    <- exp(-(1:(N2 - 1L)) / 7); F1_RAW <- F1_RAW / sum(F1_RAW)
IFR_BASE  <- 0.01
F1        <- F1_RAW * IFR_BASE        # length N2-1

simulate_data <- function(seed = 123) {
    set.seed(seed)

    tau_true        <- abs(rnorm(1,  30.0, 3.0))  + 5.0
    y_true          <- abs(rnorm(M_TRUE, 15.0, 3.0)) + 2.0
    phi_true        <- abs(rnorm(1,   5.0, 0.5))  + 1.0
    kappa_true      <- abs(rnorm(1,   0.5, 0.05)) + 0.05
    mu_true         <- abs(rnorm(M_TRUE, 3.28, 0.3)) + 0.3
    alpha_hier_true <- abs(rnorm(P_TRUE, 0.4, 0.1))  + 0.05
    ifr_noise_true  <- abs(rnorm(M_TRUE, 1.0, 0.05)) + 0.5

    pop <- rep(1e6, M_TRUE)
    EpStart <- as.integer(rep(N0 + 2L, M_TRUE))
    N_obs   <- as.integer(rep(N2, M_TRUE))

    # Forward simulate infections and deaths
    deaths_mat <- matrix(0L, N2, M_TRUE)
    pred_mat   <- matrix(0.0, N2, M_TRUE)

    for (m in seq_len(M_TRUE)) {
        c_arr <- rep(0.0, N2)
        c_arr[1:N0] <- y_true[m]

        for (t in (N0 + 1L):N2) {
            S_t <- max(0.0, (pop[m] - sum(c_arr[1:(t-1)])) / pop[m])
            xt  <- X_ARR[t, m, ]
            R_t <- mu_true[m] * exp(-sum(xt * (alpha_hier_true - SHIFT)))
            conv_t <- sum(c_arr[1:(t-1)] * SI_SHORT[(t-1):1])
            c_arr[t] <- max(0.0, S_t * R_t * conv_t)
        }
        pred_mat[, m] <- c_arr

        for (t in 2:N2) {
            convd <- sum(c_arr[1:(t-1)] * F1[(t-1):1])
            ed_t  <- ifr_noise_true[m] * convd
            if (t >= EpStart[m] && t <= N_obs[m] && ed_t > 0.0) {
                lam <- rgamma(1L, shape = phi_true, scale = ed_t / phi_true)
                deaths_mat[t, m] <- rpois(1L, lam)
            }
        }
    }

    # Stan needs `cases` (declared but unused in model block) — pass prediction
    cases_mat <- matrix(rpois(N2 * M_TRUE, pmax(pred_mat, 1e-8)), N2, M_TRUE)

    # f matrix for Stan: N2×M, rows 1..N2-1 = F1, row N2 = 0
    f_stan <- rbind(matrix(rep(F1, M_TRUE), nrow = N2 - 1L, ncol = M_TRUE), 0.0)

    # Flat packing for AI constructor
    deaths_flat <- as.numeric(deaths_mat)              # col-major: t fastest
    f_kernel    <- as.numeric(matrix(F1, nrow = N2-1L, ncol = M_TRUE))  # (N2-1)*M
    x_cov       <- as.numeric(X_ARR)                  # col-major (t,m,p) ordering

    # Stan X: list of M matrices, each N2×P
    X_list <- lapply(seq_len(M_TRUE), function(m) X_ARR[, m, ])

    list(
        data = list(
            M = M_TRUE, P = P_TRUE, N0 = N0,
            N = N_obs, N2 = N2,
            cases = cases_mat, deaths = deaths_mat,
            f = f_stan,
            X = X_list,
            EpidemicStart = EpStart,
            pop = pop,
            SI = SI_STAN,
            # AI-specific
            deaths_flat = deaths_flat,
            f_kernel    = f_kernel,
            x_cov       = x_cov,
            N_obs       = N_obs,
            EpStart     = EpStart
        ),
        truth = list(
            tau        = tau_true,
            y          = matrix(y_true,          nrow = 1L),
            phi        = phi_true,
            kappa      = kappa_true,
            mu         = matrix(mu_true,          nrow = 1L),
            alpha_hier = matrix(alpha_hier_true,  nrow = 1L),
            ifr_noise  = matrix(ifr_noise_true,   nrow = 1L)
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("covid19imperial_v3.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
