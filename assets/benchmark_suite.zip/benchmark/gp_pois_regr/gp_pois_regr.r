# Data-generating process for the gp_pois_regr benchmark model.
# Extracted from sim1_gp_pois_regr.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N      <- 30L
    x      <- sort(runif(N, -2, 2))
    rho    <- rgamma(1, shape = 25, rate = 4)
    alpha  <- abs(rnorm(1, 0, 2))
    d2     <- outer(x, x, function(a, b) (a - b)^2)
    K      <- alpha^2 * exp(-d2 / (2 * rho^2))
    diag(K) <- diag(K) + 1e-10
    L_chol  <- chol(K)              # upper-tri; lower = t(L_chol)
    f_tilde <- rnorm(N)
    f       <- as.numeric(drop(t(L_chol) %*% f_tilde))
    k       <- rpois(N, lambda = exp(f))
    list(
        data = list(
            N = N,
            x = x,
            k = k,
            X = matrix(x, ncol = 1L)),    # AI takes X as N x 1
        truth = list(
            alpha = alpha,
            rho   = rho))
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("gp_pois_regr.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
