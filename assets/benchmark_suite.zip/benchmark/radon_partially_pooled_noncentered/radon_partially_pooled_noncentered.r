# Data-generating process for the radon_partially_pooled_noncentered benchmark model.
# Extracted from sim1_radon_partially_pooled_noncentered.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

N_DATA <- 80L
J_TRUE <- 8L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    mu_alpha_t   <- rnorm(1, 0, 2.0)
    sigma_alpha_t <- abs(rnorm(1, 0, 0.5)) + 0.2
    sigma_y_t    <- runif(1, 0.4, 1.0)
    alpha_t      <- rnorm(J_TRUE, mu_alpha_t, sigma_alpha_t)
    county_idx   <- sample.int(J_TRUE, N_DATA, replace = TRUE)
    log_radon    <- alpha_t[county_idx] + rnorm(N_DATA, 0, sigma_y_t)
    list(
        data = list(N = N_DATA, J = J_TRUE,
                    log_radon = log_radon,
                    county_idx = as.integer(county_idx)),
        truth = list(
            alpha       = matrix(alpha_t, nrow = 1L),
            mu_alpha    = mu_alpha_t,
            sigma_alpha = sigma_alpha_t,
            sigma_y     = sigma_y_t
        )
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("radon_partially_pooled_noncentered.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
