# Data-generating process for the arma11 benchmark model.
# Extracted from sim1_arma11.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

T_OBS <- 40L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    mu    <- rnorm(1, 0, 10)
    phi   <- rnorm(1, 0, 0.4)
    theta <- rnorm(1, 0, 0.4)
    sigma <- abs(rcauchy(1, 0, 2.5))
    e <- numeric(T_OBS)
    y <- numeric(T_OBS)
    y[1] <- rnorm(1, mu + phi * mu, sigma)
    e[1] <- y[1] - (mu + phi * mu)
    for (t in 2:T_OBS) {
        nu <- mu + phi * y[t - 1L] + theta * e[t - 1L]
        e[t] <- rnorm(1, 0, sigma)
        y[t] <- nu + e[t]
    }
    list(
        data  = list(T = T_OBS, y = y),
        truth = list(mu = mu, phi = phi, theta = theta, sigma = sigma)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("arma11.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
