# Data-generating process for the logmesquite_logvash benchmark model.
# Extracted from sim1_logmesquite_logvash.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

P_DIM <- 6L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    N <- 80L
    diam1 <- runif(N, 1, 20); diam2 <- runif(N, 1, 20)
    canopy_height <- runif(N, 1, 15); total_height <- runif(N, 2, 25)
    group <- rbinom(N, 1, 0.5)
    sigma <- runif(1, 0.1, 1); beta <- rnorm(6, 0, 1)
    log_canopy_volume <- log(diam1 * diam2 * canopy_height)
    log_canopy_area   <- log(diam1 * diam2)
    log_canopy_shape  <- log(diam1 / diam2)
    log_total_height  <- log(total_height)
    mu <- beta[1] + beta[2]*log_canopy_volume + beta[3]*log_canopy_area +
          beta[4]*log_canopy_shape + beta[5]*log_total_height + beta[6]*group
    log_weight <- rnorm(N, mu, sigma); weight <- exp(log_weight)
    X_log <- cbind(1, log_canopy_volume, log_canopy_area, log_canopy_shape, log_total_height, as.numeric(group))
    list(
        data = list(N = N, weight = as.numeric(weight),
                    diam1 = as.numeric(diam1), diam2 = as.numeric(diam2),
                    canopy_height = as.numeric(canopy_height),
                    total_height = as.numeric(total_height), group = as.numeric(group),
                    log_weight = log_weight, X = X_log),
        truth = list(beta = matrix(beta, nrow = 1L), sigma = sigma)
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("logmesquite_logvash.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
