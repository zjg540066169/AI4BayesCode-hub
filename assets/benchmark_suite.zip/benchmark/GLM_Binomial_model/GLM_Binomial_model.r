# Data-generating process for the GLM_Binomial_model benchmark model.
# Extracted from sim1_GLM_Binomial_model.R. Returns a list with:
#   $data  : inputs to the fitted model
#   $truth : latent parameter values used to simulate the data,
#            for coverage / recovery checks.

NYEARS <- 15L

simulate_data <- function(seed = 123) {
    set.seed(seed)
    year  <- seq(-1, 1, length.out = NYEARS)
    alpha <- rnorm(1, 0, 2)
    beta1 <- rnorm(1, 0, 1)
    beta2 <- rnorm(1, 0, 1)
    N_obs <- rpois(NYEARS, 20) + 1L
    C_obs <- rbinom(NYEARS, N_obs, plogis(alpha + beta1*year + beta2*year^2))
    list(
        data  = list(nyears = NYEARS, C = as.integer(C_obs),
                     N = as.integer(N_obs), year = year),
        truth = list(alpha = alpha,
                     beta1 = matrix(beta1, nrow = 1L),
                     beta2 = matrix(beta2, nrow = 1L))
    )
}

# Example usage:
sim <- simulate_data(seed = 123)
str(sim)

# To fit the reference Stan model:
# library(cmdstanr)
# mod <- cmdstan_model("GLM_Binomial_model.stan")
# fit <- mod$sample(data = sim$data, seed = 123, chains = 2,
#                   iter_warmup = 250, iter_sampling = 250)
# print(fit$summary())
